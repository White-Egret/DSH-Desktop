# dsh-kb

DSH 本地知识库插件：把 Obsidian 仓库变成 Agent 可读写、可溯源、防覆盖的结构化知识层。确定性规则，不调用任何 LLM；插件运行时零第三方依赖（SQLite 走 `node:sqlite`）。

## 安装

```powershell
dsh plugin add file:<dsh-kb-0.4.x.tgz>
```

## 工具

| 工具 | 作用 |
|---|---|
| `kb_scan` | 扫描 `00_Inbox_Raw/`，按 sha256 指纹报新增/变更；索引缺失时自动从磁盘重建页面记录 |
| `kb_extract` | 把原始文件逐字抽取到 `materials/`（不摘要不改写）；PDF/docx 走同目录 `.md` 转换产物 |
| `kb_write` | 唯一写入口：frontmatter/source 溯源/覆盖守卫逐条校验后落盘 `notes/`、`digests/` |
| `kb_search` | tag / title / fulltext 三种检索，一轮 3 次预算 |
| `kb_status` | 总览：抽取与编译对账、孤儿两桶、`[[链接]]` 死链与反向链接（`links: true`） |
| `dict_lookup` | 词典查词：按 `dictPriority` 下探，primary 全文 + 断代线索 + 缩略语展开（仅当 `.kb/dictionaries.db` 存在时注册） |
| `dict_search` | 词典释义全文检索（英文概念 → 拉丁词），与 `kb_search` 共享预算 |

## 词典入库

```powershell
python tools/ingest.py slice   --dict old --source <原件.pdf> --pages 21-40
# 按 slice 打印的指令调 convert_file_to_markdown（prefer='layout', max_chars=0）
python tools/ingest.py commit  --dict old --md <切片.md> --pages 21-40
python tools/ingest.py mark-ready --dict old
```

细节见 `tools/ingest.py --help`；真实件样例与解析规则记录在 `DELIVERY.md`。

## 测试与门禁

```powershell
npm.cmd run check    # typecheck + build + Node 测试 + Python 测试 + verify 门禁
node tools/kb-inspect.mjs --vault <vaultRoot>   # 独立自检（不 import 插件本体）
```

交付历史与每轮差异说明：[DELIVERY.md](./DELIVERY.md)。
