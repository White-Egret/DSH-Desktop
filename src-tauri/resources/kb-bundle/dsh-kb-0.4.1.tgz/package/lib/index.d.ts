/**
 * dsh-kb —— DSH 本地知识库插件。
 *
 * 设计约束（与 dsh-memory2skill / dsh-github 对齐）：
 *   - 导出 { name, inject, Config, apply }
 *   - 包级 import 只做 `import type`：编译后零运行时依赖，安装时不碰 npm
 *   - node:fs / node:crypto 走模块顶层 import（Node 内建，不是裸包）
 *   - 工具注册用 ctx.effect 包起来，插件卸载时自动注销
 *   - 所有工具只做确定性的事，绝不调用 LLM
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "kb";
export declare const inject: string[];
export interface Config {
    /** Obsidian Vault 根目录（绝对路径）。必填。 */
    vaultRoot: string;
    /** 三级受控词表（决策 7 / delta #1）：大类 → 子类 → 体裁列表。省略用默认词表。 */
    topics?: Record<string, Record<string, string[]>>;
    /** 原始资料目录名，相对 vaultRoot。 */
    rawSubdir?: string;
    /** 逐字正文目录名。 */
    materialsSubdir?: string;
    /** 摘要卡目录名。 */
    notesSubdir?: string;
    /** 详解目录名。 */
    digestsSubdir?: string;
    /** 超过多少字符标记为超大文件、不自动抽取。默认 200000。 */
    maxExtractChars?: number;
    /** 单次返回给 Agent 的正文字符上限。默认 40000。 */
    maxReturnChars?: number;
    /** 是否向 Agent 注入使用说明。默认 true。 */
    announceToAgent?: boolean;
    /**
     * 词典库路径。省略 = <vaultRoot>/.kb/dictionaries.db；文件存在时才注册
     * dict_lookup / dict_search 与词典 GUIDANCE 段落（设计 1：没建词典的用户
     * 不为用不到的工具付上下文成本）。
     */
    dictPath?: string;
    /**
     * 词典摄取的构建目录（切片 PDF 与转换产物落这里）。省略 =
     * <DSH_HOME>/dsh-kb/dict-build（DSH_HOME 解析与 dsh-memory2skill 同一约定）。
     * 插件运行时不使用它——它是 tools/ingest.py 的默认工作区。
     */
    dictBuildDir?: string;
    /**
     * 按语种的词典咨询次序（如 { la: ['old', 'ls'] }）。只存次序，不存进
     * dictionaries.db——改次序不许要求重新入库（设计 3）。没列出的词典排在
     * 已列出的之后（按 id 字典序），仍可查。
     */
    dictPriority?: Record<string, string[]>;
    /** 设为 false 可以临时关掉整个插件。 */
    enabled?: boolean;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export { DEFAULT_TOPICS } from './topics.js';
export * from './vault.js';
export * from './topics.js';
export * from './frontmatter.js';
export { kbExtractTool, kbScanTool, kbStatusTool, kbWriteTool } from './tools.js';
export { kbSearchTool, createSearchCounter } from './search.js';
export { dictLookupTool, dictSearchTool, DICT_GUIDANCE } from './dict/tools.js';
export { foldLatin } from './dict/fold.js';
export { extractWikiLinks, scanPageGraph, graphReportLines } from './links.js';
export type { ToolDeps } from './tools.js';
export type { DictLookupDeps } from './dict/lookup.js';
export type { DeadLink, PageGraph } from './links.js';
