/**
 * 词典库（dictionaries.db）的只读打开与元信息读取。
 *
 * 插件侧对词典库**只读**（硬约束 9）：写入只在摄取脚本（tools/ingest.py，
 * Python）侧发生。两边并发靠 WAL（建库时开）+ 本侧 readOnly 打开——
 * 读不阻塞写、写不阻塞读。
 *
 * 打开即校验 schema：文件存在但不是本插件的词典库（缺 dictionaries/entries
 * 表）时显式报 unavailable，而不是让后续 SQL 半路炸出难懂的 sqlite 异常。
 */
import { DatabaseSync } from 'node:sqlite';
export interface DictMeta {
    id: string;
    name: string;
    lang: string;
    /** 覆盖时代描述（如 "≤ 200 A.D."），断代线索的数据源。 */
    coverage: string | null;
    /** 'high' = 结构化录入；'medium' = OCR 草稿。必须透出到工具返回值。 */
    quality: string | null;
    entryCount: number | null;
    /** 'ingesting' = 录入中（查询忽略）；'ready' = 可用。 */
    status: string;
}
export declare class DictDbError extends Error {
    readonly kind: 'not-sqlite' | 'not-dict-db' | 'open-failed';
    constructor(kind: 'not-sqlite' | 'not-dict-db' | 'open-failed', message: string);
}
export interface DictDb {
    db: DatabaseSync;
    metas: DictMeta[];
    /** 库级元信息（P3-E2）：schema_version / fold_version / parser_version / created_at。 */
    meta: Record<string, string>;
}
/** 只读打开词典库；文件损坏 / 不是词典库时抛 DictDbError（调用方转 unavailable）。 */
export declare function openDictDb(path: string): DictDb;
/** 便捷包装：执行完回调后关闭连接。词典查询是短生命周期操作，每次调用独立开合。 */
export declare function withDictDb<T>(path: string, fn: (opened: DictDb) => T): T;
