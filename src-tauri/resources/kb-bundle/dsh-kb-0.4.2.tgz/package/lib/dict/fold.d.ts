/**
 * 拉丁文词条归一化（查询键）：入库（Python tools/fold.py）与查询（本文件）
 * 必须逐字符一致 —— 两边算法漂移的症状是「库里有这个词、查不到」，不报错、
 * 不崩溃，只有共享测试向量（test/fixtures/fold-vectors.json）能拦住它。
 *
 * 步骤与 tools/fold.py 逐条对应（P3-E1 起为六步，方案 7.6）：
 *   0. NFKC 兼容分解（全角 `ｖｉｔａ` → `vita`；连字 ﬀ → ff）
 *   1. NFD 分解 + 去掉组合变音符（\p{M}）
 *   2. 小写化
 *   3. 显式映射 æ→ae、œ→oe、ß→ss（无规范分解，NFD 拆不掉；必须在**小写之后**做，
 *      否则 Æ（大写）映射不到 —— 向量 Æneas→aeneas 专门钉住这一条）
 *   4. 长音符翻译表（预组合字符兜底，NFD 未必拆得掉）
 *   5. j→i、v→u（拉丁语原文这两组字母不分）
 *
 * 关于第 0 步：NFKC 放最前面，因为它会把全角/连字形式折成常规字符，后面的
 * 去音符与大小写才有统一的输入。它对纯拉丁词典查询几乎无影响（拉丁词条不用
 * 全角），但 memory2skill 侧要处理中文与德文输入——宽度折叠与 ß 都用得上，
 * 而「共用一个 fold」本来就是方案 6.5 #29 的要求。
 *
 * 版本：改了任何一步都要抬 FOLD_VERSION 并同步 fold.py 的 _FOLD_VERSION，
 * 库里 meta.fold_version 对不上时查询层报 unavailable（否则新规则会拿旧键查，
 * 结果同样是「查不到」）。
 */
export declare const FOLD_VERSION = 2;
export declare function foldLatin(input: string): string;
