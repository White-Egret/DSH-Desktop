/**
 * 词典查询的下探链（consult chain）与全文检索。
 *
 * 三条纪律在这里落地：
 *   · 优先次序只读 config（dictPriority），不读数据库——改次序不许重新入库；
 *   · 没列进 dictPriority 的词典排在已列出的之后（按 id 字典序），仍可查；
 *   · dictionaries.quality 一路透出到返回值——OCR 草稿（medium）必须让
 *     模型看见「这条该不该复核原件」，不许静默。
 *
 * 断代线索是优先链最大的价值：primary（链上第一本）没收录、后面的词典
 * 收录了 → hint 把「缺词」翻译成时代判断（确定性规则，零成本）。
 */
import type { JsonValue } from '@deepseek-ai/dsh-session';
import { DictDbError } from './db.js';
import type { DictMeta } from './db.js';
/** 单次返回正文上限（决策 5：大文件不进上下文；超出走 chunks 分段取）。 */
export declare const DICT_BODY_CAP = 2000;
/**
 * dict_search 的延迟预算（P3-F4 / 方案 #51）。
 *
 * 1200ms 那条死线是给**注入**用的，管不到查询，所以这里单独立一个。取值依据：
 * 真库 5 条词条 → 单位数毫秒，看不出上限；4 万词条的 OLD 全量还没跑过，
 * 所以这个数是**保守上界而非实测最优**——超过它说明这次查询在真数据上可能
 * 已经开始难受，于是返回结果同时标 `degraded: true`（方案 #51：前提不成立时
 * 显式 degraded，不假装保证成立）。全量录入后用实测数据回来修正它。
 */
export declare const DICT_SEARCH_BUDGET_MS = 400;
export interface DictLookupDeps {
    dictDbPath: string;
    dictPriority: Record<string, string[]>;
}
export type DictEntryRef = {
    id: number;
    lemma: string;
    pos: string | null;
    chars: number;
    doubtful: number;
    reconstructed: number;
};
export type DictPrimaryHit = {
    source: string;
    name: string;
    coverage: string | null;
    quality: string | null;
    /** 前 DICT_BODY_CAP 字；超出时 truncated: true，用 entryId + offset 分段取。 */
    body: string;
    chars: number;
    truncated: boolean;
    /** 同一 fold 命中的全部条目（同形词 ā¹/ā² 等），按 lemma 排序。 */
    entries: DictEntryRef[];
};
export type DictAlsoIn = {
    source: string;
    name: string;
    coverage: string | null;
    quality: string | null;
    chars: number;
    preview: string;
    entries: DictEntryRef[];
};
export type DictLangGroup = {
    lang: string;
    consultOrder: string[];
    primary: DictPrimaryHit | null;
    alsoIn: DictAlsoIn[];
    hint: string;
    /** expand: true 时附带——只含本组返回正文里实际出现的缩写（B5③），按词典 id 分组。 */
    abbreviations?: Record<string, Record<string, string>>;
};
export type DictConsulted = {
    source: string;
    name: string;
    coverage: string | null;
};
export type DictLookupResult = JsonValue;
/**
 * 某一语种的咨询次序：config.dictPriority[lang] 里列出的在前（保持用户给的
 * 顺序），ready 状态但没列出的词典按 id 字典序排在最后——忘排 = 排最后，
 * 不是查不到（硬约束 6）。
 */
export declare function consultOrder(lang: string, priority: Record<string, string[]>, metas: DictMeta[]): string[];
/** 缩略语展开的上限：500 条全表会把上下文吃光（B5③），只返回命中的、封顶。 */
export declare const EXPAND_CAP = 40;
export interface DictLookupOptions {
    word?: string;
    source?: string;
    lang?: string;
    entryId?: number;
    offset?: number;
    /** 展开本次返回正文里实际出现的文献缩写（B5③ / 验收 27）。 */
    expand?: boolean;
}
/**
 * dict_lookup 的执行体。三种模式：
 *   · entryId 给定 → 单条目分段取（超大词条的后续页，从 chunks 表读）；
 *   · source 给定 → 跳过优先链，只查这一本（仍要求 status='ready'）；
 *   · 默认 → 按 dictPriority 下探。
 * lang 省略时查全部语种并按语言分组（groups 形状）；给定则返回扁平形状。
 */
export declare function lookupWord(deps: DictLookupDeps, opts: DictLookupOptions): DictLookupResult;
export interface DictSearchOptions {
    query: string;
    limit?: number;
    lang?: string;
}
export type DictSearchResult = JsonValue;
/**
 * dict_search 的执行体：entries_fts 全文检索（反向查：英文概念 → 拉丁词）。
 * 排序 = config 词典次序在前、BM25 在后（输出按词典分组呈现）。
 * FTS5 用普通表（非 external-content）：P0 在 contentless 表上踩过
 * 「跨连接复用 schema 与影子表耦合、重开库后索引全空」的坑（见
 * dsh-memory2skill store.ts 的注释），只读复用场景不冒这个险。
 *
 * P3-F4 的三处实现修正（方案 #51）：
 *   1. **逐 token 加引号**而不是整句包成一个短语：`courage greed` 从「必须
 *      相邻」放宽成「都要出现、位置不限」，同时仍然挡住 FTS 运算符注入。
 *   2. **去掉 N+1**：一条 `WHERE id IN (…)` 取回全部命中的 entries，
 *      metas 建成 Map，prepare 提到循环外。
 *   3. **不再单独跑第三遍 count(*) 全量扫描**：用 LIMIT limit+1 探测是否还有
 *      更多；`total` 因此是「至少这么多」，返回里明说它是估算（`totalIsEstimate`）。
 */
export declare function searchEntries(deps: DictLookupDeps, opts: DictSearchOptions): DictSearchResult;
export { DictDbError };
