/**
 * dict_lookup / dict_search —— 词典查询工具（阶段 A）。
 *
 * 注册纪律（设计 1）：只有 <vaultRoot>/.kb/dictionaries.db 存在时才注册——
 * 工具 schema 每次 API 调用全量发送（方案 6.4.7 的工具门槛），没建词典的
 * 用户不该为两个用不到的工具付上下文成本。GUIDANCE 同理：DICT_GUIDANCE 是
 * 第二个**模块级常量**段落（order 155），库存在才注入——决策 6 禁的是
 * 「会话中途改变文本」，段落数随环境在会话之间变化是允许的。
 *
 * 调用上限（方案 #38）：dict_search 是探索性检索，与 kb_search 共享同一个
 * 每轮 3 次预算（apply 传同一个 counter 实例）；dict_lookup 是精确键查找
 * （一次调用一次答案，方案 7.5），不设上限。
 */
import { createSearchCounter } from '../search.js';
import type { DictLookupDeps } from './lookup.js';
/** 词典段的说明：常量字符串（决策 6），只描述用法与纪律，不带任何动态统计。 */
export declare const DICT_GUIDANCE: string;
export declare function dictLookupTool(deps: DictLookupDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function dictSearchTool(deps: DictLookupDeps, counter: ReturnType<typeof createSearchCounter>): import("@deepseek-ai/dsh-tools").ToolDefinition;
