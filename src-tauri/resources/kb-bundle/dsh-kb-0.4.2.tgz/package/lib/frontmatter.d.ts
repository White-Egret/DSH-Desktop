/**
 * 零依赖 YAML frontmatter 子集：解析与安全序列化。
 *
 * 只认 kb_write 需要的形状——`key: scalar`、`key:\n  - item`、带引号或不带
 * 引号的字符串——不追求 YAML 全兼容。不用 gray-matter 的理由见方案坑 3：
 * 运行时依赖在 profile 安装态会 ERR_MODULE_NOT_FOUND，开发机永远发现不了。
 */
/** 解析后的 frontmatter：值为字符串或字符串数组。 */
export type Frontmatter = Record<string, string | string[]>;
/** 解析失败的原因，供 kb_write 原样退回给 Agent。 */
export declare class FrontmatterError extends Error {
}
/**
 * 从 Markdown 文本里切出 YAML frontmatter 与正文。
 * 不接受任何前置内容——文件必须以 `---` 开头。
 */
export declare function parseFrontmatter(markdown: string): {
    data: Frontmatter;
    body: string;
};
/** 把一个标量安全地写成 YAML 单行值。 */
export declare function quoteScalar(value: string): string;
