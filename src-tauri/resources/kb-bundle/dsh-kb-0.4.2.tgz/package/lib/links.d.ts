/**
 * 页面图谱（P2-C）：[[链接]] 死链校验 + 反向链接。纯读操作。
 *
 * 范围与简化（方案 C1 明说的口径）：
 *   · 扫描对象 = notes/ 与 digests/ 下的 .md（知识页面）。materials/ 是逐字
 *     原文抽取物，不是页面，既不算链接目标也不产生链接（材料里引用别的页
 *     没有导航意义）。
 *   · 解析规则：Obsidian 按**文件名**（不含路径、不含扩展名）解析 [[...]]；
 *     本插件简化成「全库文件名唯一匹配」。同名页面在多处 → 报「歧义」，
 *     不随便挑一个（C1）。歧义链接不产生反向链接边——宁可少算，不发明边。
 *   · [[目标#节]] 取目标段；[[#节]] 是页内锚点，目标为空，跳过。
 *   · 别名段（[[目标|别名]]）只取目标段。
 *
 * 不写任何文件（不改用户的笔记）：结果只进 kb_status 的返回值。
 */
export declare function extractWikiLinks(markdown: string): string[];
export type DeadLink = {
    /** 引用方：相对 vault 根的 POSIX 路径。 */
    from: string;
    /** 链接目标段（[[...]] 里 # 之前的部分）。 */
    target: string;
    /** 目标同名页面在多处 → 歧义，不算死链（candidates 给出全部位置）。 */
    ambiguous?: boolean;
    candidates?: string[];
};
export type PageGraph = {
    /** 参与图谱的页面数（notes/ + digests/ 的 .md）。 */
    pages: number;
    /** 去重后的引用边数（from → target 唯一）。 */
    linksTotal: number;
    deadLinks: DeadLink[];
    /** 键/值都是相对 vault 根的 POSIX 路径：谁被哪些页面引用。 */
    backlinks: Record<string, string[]>;
};
export interface LinksDeps {
    vaultRoot: string;
    notesDir: string;
    digestsDir: string;
}
/**
 * 页面图谱扫描。遍历走 vault.ts 的 walkPages——与索引重建（P3-D4）共用同一次
 * 遍历语义，不再各写一份 readdir 递归（两份迟早会漂移出不同的过滤规则）。
 */
export declare function scanPageGraph(deps: LinksDeps): Promise<PageGraph>;
/** 报告文本里的图谱段（kb_status 用；空图谱只给一行）。 */
export declare function graphReportLines(graph: PageGraph): string[];
