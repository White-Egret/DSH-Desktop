/**
 * kb_search：tag / title / fulltext 三种确定性检索 + 一轮调用上限（方案 #38）。
 *
 * 全部现扫、不建索引：`.kb/index.json` 是派生摘要，只存哈希与路径（硬约束 7），
 * fulltext 必须读磁盘文件。线性扫描对几百页够用；大库换 SQLite FTS5 是 P2 的事，
 * 不在本档引入。工具只读不改任何文件（硬约束 9）。
 */
import type { ToolDeps } from './tools.js';
/**
 * 返回形状用 type 别名而不是 interface：dsh-tools 的 execute 要求返回
 * JsonValue（递归索引签名），interface 没有隐式索引签名过不了检查
 * （tools.ts 顶部注释记过同一个坑）。
 */
/** 一轮 3 次用完后的返回：提示而非报错（方案 #38）。 */
export type SearchRateLimited = {
    hits: [];
    status: 'rate-limited';
    hint: string;
};
/** 索引损坏时显式报 unavailable；「没查成」不能折叠成「查了没有」（方案 #26）。 */
export type SearchUnavailable = {
    hits: [];
    status: 'unavailable';
    reason: string;
};
/** 查过了、确实没有。与 unavailable 必须可区分，否则 Agent 会去补一份其实有的资料。 */
export type SearchNotFound = {
    hits: [];
    status: 'not-found';
};
/** 至少一条命中（或全空但已查过且带统计的常规返回）。 */
export type SearchHits = {
    hits: Array<{
        id: string;
        title: string;
        tags: string[];
        source: string;
        mode: 'tag' | 'title' | 'fulltext';
        score: number;
        snippet: string;
        pagePath: string;
    }>;
    total: number;
    truncated: boolean;
};
export type KbSearchResult = SearchUnavailable | SearchNotFound | SearchRateLimited | SearchHits;
/**
 * 一轮内的调用计数（方案 #38）：user/message 到来时清零。
 *
 * 按会话分桶——同一进程可能同时服务多个会话，全局计数会把别的会话的搜索
 * 算到本会话头上。超限返回提示而不是报错（任务验收 #8）。
 */
export declare function createSearchCounter(): {
    take: (sessionId: string) => boolean;
    reset: (sessionId: string) => void;
};
/** 从工具执行上下文里找会话标识；宿主不保证 agent 字段存在（同 memory2skill 的容错）。
 *  导出给 dict 工具复用——kb_search 与 dict_search 共享每轮预算，会话键必须一致。 */
export declare function sessionKey(exec: unknown): string;
/** kb_search 主工具；counter 由 apply 注入，与 user/message 清零监听共享。 */
export declare function kbSearchTool(deps: ToolDeps, counter: ReturnType<typeof createSearchCounter>): import("@deepseek-ai/dsh-tools").ToolDefinition;
