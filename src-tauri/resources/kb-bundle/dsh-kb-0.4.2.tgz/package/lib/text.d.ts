/**
 * 文本边界的两个纯函数（P3-D1 / 方案 #43）。
 *
 * 为什么需要它（rofm v1.4.4 的真实事故链）：孤立代理项（lone surrogate）被
 * `JSON.stringify` 转义成 `\ud83e` 这类半截转义 → Messages 接口 400
 * `unexpected end of hex escape` → **请求在模型回合开始前就失败**，而工具结果
 * 每轮都要过这条路。rofm 那条是「每轮都 400 → 会话永久卡死、重启不恢复」。
 *
 * 我们的暴露面：拉丁文与希腊文都在 BMP、不会触发；但 kb_search 扫的是中文
 * 笔记与详解，CJK 扩展 B（"𠮷" 一类）与 emoji 正是方案 6.5 #40 点名的用例。
 *
 * 不变量（硬约束 10）：**所有模型可见的字符串截断必须代理对安全**。
 * 新代码里的裸 `.slice()` 一旦用于返回给模型的字符串，就破坏了这条不变量。
 *
 * 为什么不直接用 String.prototype.toWellFormed：它属于 ES2024，而 tsconfig 的
 * target/lib 是 ES2022（`engines` 要求的 Node ≥22.6 确实提供该运行时方法，
 * 但类型层面拿不到）。为两个函数抬整个项目的 lib 不值当，手写版本 O(n) 且
 * 零依赖——与 dsh-rofm 的选择一致。
 */
/**
 * 截断到 max 个 UTF-16 码元，但截点落在代理对中间时**整体让出该对**
 * （结果可能比 max 少 1 个码元）。
 *
 * max 为负数或 0 时返回空串；max ≥ 长度时原样返回（不做无谓拷贝）。
 */
export declare function safeSlice(text: string, max: number): string;
/**
 * 孤立代理项 → U+FFFD（替换字符）。合法的代理对原样保留。
 *
 * O(n)，只在「即将进请求体」的边界调用——不要放进热循环。
 */
export declare function toWellFormed(text: string): string;
