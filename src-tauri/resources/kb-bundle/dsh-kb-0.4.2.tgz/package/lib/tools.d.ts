/**
 * dsh-kb 的四个工具（方案 4.5 基线 + delta #3/#4/#5 的主题轴改动）。
 *
 * 全部是确定性规则：抽取不改一字、写入必过守卫、归属逐段校验。
 * 工具不调用任何 LLM——Agent 本身就是 LLM，插件只提供事实与闸门。
 */
/**
 * 背压阈值（P3-F5 / 方案 #52）：已抽取但未编译的原始文件超过这个数，
 * kb_status 就在报告头部警告「先清账再继续抽取」。
 *
 * 取值理由：一次正常的工作循环是「抽 1 篇 → 写 1 页」，积压 5 条意味着
 * 已经连续 5 次只抽不写——那是「忘了写」或者「写不进去」的确定信号，
 * 而不是正常节奏。阈值不能太大：rofm 的教训正是让积压涨到 393 条才发现。
 */
export declare const PENDING_COMPILE_WARN = 5;
/** 插件运行时依赖的最小上下文。 */
export interface ToolDeps {
    vaultRoot: string;
    rawDir: string;
    materialsDir: string;
    notesDir: string;
    digestsDir: string;
    indexPath: string;
    logPath: string;
    /** 超过这个字符数就标 deferred，不自动抽取。 */
    maxExtractChars: number;
    /** Agent 单次能看到的正文上限。 */
    maxReturnChars: number;
    /** 三级受控词表（delta #1）；Agent 无权扩表，改词表只能由人改 config。 */
    topics: Record<string, Record<string, string[]>>;
}
/** 该文件是否是「经转换才可抽取」的原始格式。 */
export declare function isConversionSource(file: string): boolean;
export declare function kbScanTool(deps: ToolDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function kbExtractTool(deps: ToolDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function kbWriteTool(deps: ToolDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;
export declare function kbStatusTool(deps: ToolDeps): import("@deepseek-ai/dsh-tools").ToolDefinition;
