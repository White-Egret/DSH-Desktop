/**
 * 三级受控主题词表（决策 7）与逐段校验。
 *
 * 这一层是两件事的同一道闸：
 *   · 分类规则——所有可落盘的主题组合都来自 config 里的嵌套映射；
 *   · 路径安全边界——topic 来自模型输出，未校验就 join() 有 ../ 越界风险。
 * 因此校验必须在拼路径之前完成（硬约束 4），通过后返回的 parts 才允许进 join()。
 */
/**
 * 默认词表。第二级随大类而变：语言按语种切，其余按文化圈切。
 * 第三级也随大类而变：语言是文选/通论，史文哲是原著/论述，宗教与其他是古文/今文。
 */
export declare const DEFAULT_TOPICS: Record<string, Record<string, string[]>>;
/** 段数上限：1–3 段合法（体裁可省），超了直接拒绝。 */
export declare const TOPIC_MAX_SEGMENTS = 3;
export interface TopicValidation {
    ok: boolean;
    /** 校验通过后的各段（未通过时为空数组）；只有它允许被 join 进路径。 */
    parts: string[];
    /** 不合法时给 Agent 的错误与全部合法组合。 */
    error?: string;
    details?: string[];
}
/** 列出词表里全部合法组合（含省略体裁的 1–2 段形式），用于拒绝时给 Agent 指路。 */
export declare function listValidTopics(topics: Record<string, Record<string, string[]>>): string[];
/**
 * 逐段校验 topic：大类 → 子类 → 体裁，段数上限 3。
 *
 * 每一段还要求匹配 SEGMENT_RE——词表查不到已经能拦下任意串，但显式
 * 拒绝 `../`、空白段这类输入能让错误信息说清是「不合法」而不是「不在词表」。
 */
export declare function validateTopic(topic: string, topics?: Record<string, Record<string, string[]>>): TopicValidation;
/** 校验通过后拼主题目录段；除 validateTopic 返回的 parts 外不得传入其他值。 */
export declare function topicDirSegments(parts: string[]): string[];
