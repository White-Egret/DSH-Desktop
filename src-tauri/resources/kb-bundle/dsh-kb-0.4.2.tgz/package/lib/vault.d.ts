/**
 * Vault 侧的基础设施：路径、扫描、哈希、守卫写入、索引读写。
 *
 * 索引是派生数据：任何时候 `.kb/index.json` 删掉都必须能从磁盘重建，
 * 所以这里只存指纹与摘要，绝不存正文（方案 6.4.4.2 / 6.4.8）。
 */
/** 索引里一条材料记录。 */
export interface MaterialEntry {
    /** 相对 00_Inbox_Raw 的 POSIX 路径（delta #2：不再是裸文件名）。 */
    rawFile: string;
    /**
     * 变更检测指纹：scan 每次重算并与它比，决定 new/changed/unchanged。
     * 文本文件 = 内容哈希；二进制原件 = 原件**全文件**哈希。
     * `kb_scan` 与 `kb_extract` 必须用同一个算法算它（`rawFingerprint`），
     * 否则同一个文件两边算出不同的值，会互相判为「已变更」。
     */
    rawHash: string;
    /**
     * 抽取源文本的哈希，`kb_write` 的 `source_hash` 与孤儿检测都用它。
     * verbatim = 该文本文件的内容；conversion = 同目录转换产物（.md）的文本。
     *
     * 与 `rawHash` 分开是必须的：conversion 类的 rawHash 是**原件二进制**的
     * 指纹，而页面溯源要指向**转换产物文本**——两者不是一回事，混用一个字段
     * 会让 scan 的 refresh 把页面溯源基准冲掉（假孤儿）。
     */
    sourceTextHash: string;
    /** materials/ 下的相对路径（相对 vaultRoot，POSIX）。 */
    materialPath: string;
    /** 抽取正文的字符长度。 */
    chars: number;
    /** 是否因过大而延迟抽取。 */
    deferred: boolean;
    /** 来源性质：verbatim = 原件即纯文本；conversion = PDF/docx 转换产物（决策 3）。 */
    origin: 'verbatim' | 'conversion' | '';
    /** 原始二进制按字节的 sha256 前 16 位；只有 conversion 类有（决策 3）。 */
    sourceSha256: string;
    /** 页面的主主题；1–3 段，随抽取落盘回填。 */
    topic: string;
    /** ISO 时间戳（抽取完成时刻）。 */
    extractedAt: string;
}
/** 索引里一条页面记录。 */
export interface PageEntry {
    /** 相对 vaultRoot 的 POSIX 路径。 */
    pagePath: string;
    title: string;
    tags: string[];
    /** 相对 00_Inbox_Raw 的 POSIX 源文件路径。 */
    source: string;
    /** 抽取源文本的哈希（守卫用，与 MaterialEntry.sourceTextHash 同值）。 */
    sourceHash: string;
    /** 写入时的内容 sha256；用于守卫，人改过就对不上。 */
    contentHash: string;
    /** 主主题（与 kb_write 的 topic 参数一致，插件回填进 frontmatter）。 */
    topic: string;
    updatedAt: string;
    /**
     * 这条记录是从磁盘 frontmatter 重建来的（P3-D4），不是 kb_write 当时写的。
     * 重建能恢复的只是**文件里带着的事实**：contentHash 按当前字节算，
     * sourceHash 取 frontmatter 的 `source_hash`——若原页面没写这个字段，
     * 重建值就是空串（不猜），守卫会退化成「文件存在但源不可核」。
     */
    rebuilt?: boolean;
}
export interface KbIndex {
    /**
     * v2：materials 的 key 与 source 改为相对 00_Inbox_Raw 的 POSIX 路径。
     * 遇到 v1 直接返回空索引触发重建——索引是派生数据，写迁移脚本
     * 反而要为「裸文件名 → 相对路径」维护映射，不值得。
     */
    version: 2;
    materials: Record<string, MaterialEntry>;
    pages: Record<string, PageEntry>;
}
export declare const EMPTY_INDEX: KbIndex;
export declare function isTextFile(file: string): boolean;
/** 计算内容的短指纹（按 utf8 字符串算）：覆盖守卫与溯源共用。 */
export declare function hashContent(content: string): string;
/**
 * 按字节算哈希：给原始二进制（PDF/docx 原件）打指纹。
 *
 * 与 hashContent 刻意分开：转换产物按字符算（守卫比对的两侧都是字符串），
 * 原件按字节算（同一份 PDF 重存一次字节就变，指纹必须反映这个事实）。
 * 混用会让「原件没变、转换器变了」与「原件变了」无法区分（决策 3）。
 */
export declare function hashFile(buffer: Buffer): string;
/**
 * 流式读整个文件算指纹：给原始二进制（PDF/docx 原件）打指纹。
 *
 * 用流而不是 `readFile` + `hashFile`：几十 MB 的 PDF 整读进内存只为算一个
 * 指纹不划算。流式是 O(1) 内存，266 MB 约 0.3 秒（实测 SHA-256 吞吐），
 * 且每次 read 都让出事件循环，不阻塞。
 *
 * 为什么不用头部指纹：第 4096 字节之后的内容变了就检测不到，原件悄悄换了
 * 而 material 不重抽——那是静默错误。溯源用的指纹必须覆盖整个文件。
 */
export declare function hashFileStream(path: string): Promise<string>;
/**
 * 原始文件的变更检测指纹（`rawHash` 的唯一算法）。
 *
 * `kb_scan` 与 `kb_extract` **必须都用这个函数**：两边只要有一个换了算法，
 * 同一个文件就会互相判为「已变更」——scan 报 changed、extract 又写回另一个值，
 * 来回震荡。文本按内容算（调用方通常已经读过，直接传进来避免重读）；
 * 二进制流式全文件算。
 */
export declare function rawFingerprint(path: string, text: string | null): Promise<string>;
/**
 * 把任意字符串变成安全的文件名。
 *
 * 四条来自同类插件的硬化（dsh-library 的 sanitizeName）：
 *   · 剥控制字符：模型给的 title 里带一个 NUL 就产出一个 Windows 上写不出来的
 *     路径（`writeFile` 直接 EINVAL），而错误信息完全指不到「title 里有控制符」；
 *   · 折叠空白 + 限长 120（原有行为，保留）——限长用 `safeSlice` 而不是裸
 *     `slice`（P3.1-R3）：文件名会进工具返回值，D1 的不变量「所有模型可见的
 *     字符串截断必须代理对安全」在这里同样适用，title 含 emoji / CJK 扩展 B
 *     时裸 slice 会在边界切出孤立代理；
 *   · Windows 保留设备名（CON/NUL/COM1…）：即便当文件名用，`CON.md` 这类仍会被
 *     设备解析劫持——加一条下划线前缀兜底，不做复杂转义。
 */
export declare function safeFileName(name: string): string;
/** 确保目录存在。 */
export declare function ensureDir(dir: string): Promise<void>;
/**
 * 索引的读取状态（P3-D2 / 方案 #44）。
 *
 * 旧实现把「文件不存在」「JSON 坏了」「version 不是 2」全部折叠成空索引，
 * 于是调用方为了知道「到底可读不可读」各自又裸读一次文件——同一个判断写了
 * 两遍，第三、第四个调用点还会再写。状态显式化之后，`'missing'`（查过，没有）
 * 与 `'corrupt'`（有，但读不出来）是两件事：前者可以放心初始化，
 * 后者必须先备份再动（硬约束 8：任何「读不出来就当成空的」的代码都是 bug）。
 */
export type IndexStatus = 'ok' | 'missing' | 'corrupt' | 'stale-version';
export interface IndexReadResult {
    index: KbIndex;
    status: IndexStatus;
    /** 读 primary 失败的原因（status 非 ok 时给出，供报告与 warn 用）。 */
    reason?: string;
    /** 内容是从 backup 回退来的（primary 坏了但 backup 可读）。 */
    fromBackup?: boolean;
}
/** 备份文件名：与 primary 同目录，`index.json` → `index.backup.json`。 */
export declare function backupPathOf(indexPath: string): string;
/** 损坏快照文件名：`index.json` → `index.corrupt-<YYYY-MM-DD>.json`（本地时区）。 */
export declare function corruptPathOf(indexPath: string, d?: Date): string;
/**
 * 读索引，带状态与 backup 回退（P3-D2/D3 / 方案 #44 #45）。
 *
 * primary 读不出来时按 backup → 空索引的次序回退；`status` 仍然报真实原因
 * （`'corrupt'` / `'stale-version'`），`fromBackup` 指出内容来自备份——调用方
 * 据此决定「先备份再初始化」还是「直接可用」。
 *
 * `loadIndex` 保留为薄壳（少改调用点），**新代码一律用 `readIndex`**。
 */
export declare function readIndex(indexPath: string): Promise<IndexReadResult>;
/**
 * 读取索引；不存在、损坏或版本过旧时返回空索引。
 *
 * @deprecated 新代码用 `readIndex`——它给出状态，能区分「没有」与「读不出来」。
 *   这个薄壳只为少改既有调用点而保留（P3-D2）。
 */
export declare function loadIndex(indexPath: string): Promise<KbIndex>;
/**
 * 原子写索引：先写临时文件再改名，避免写一半留下坏 JSON。
 *
 * 两件硬化（P3-D3 / 方案 #45 #47）：
 *   · 覆盖前把现有 primary 抄成 `index.backup.json`（首次写入无文件则跳过）；
 *   · 写失败时删掉 tmp——旧实现在 `.kb/` 里留下 `index.json.tmp-<pid>-<ts>`
 *     垃圾，且 tmp 名没有随机段，同毫秒两次写会撞名。
 */
export declare function saveIndex(indexPath: string, index: KbIndex): Promise<void>;
/**
 * 追加一行日志。
 *
 * 日志写不进去不该阻断知识库操作，但要留下理由 —— 完全静默的 catch 会让
 * 「为什么没有日志」变成一个查不动的问题。
 */
export declare function appendLog(logPath: string, entry: Record<string, unknown>): Promise<void>;
/**
 * 递归列出 raw 目录下所有候选文件（delta #2）。
 *
 * 递归是因为产物按 `<大类>/<子类>/<体裁>/` 落在三级目录下，转换后的 .md
 * 会放回 inbox 的子目录里；name 是相对 rawDir 的 POSIX 路径，同时充当
 * index.materials 的 key（跨主题同名材料不能再共用一个裸文件名槽位）。
 */
export declare function listRawFiles(rawDir: string): Promise<Array<{
    name: string;
    size: number;
}>>;
/** 一个磁盘上的页面文件：绝对路径、相对 vaultRoot 的 POSIX 路径、正文。 */
export interface DiskPage {
    abs: string;
    /** 相对 vaultRoot 的 POSIX 路径（与 index.pages 的 key 同一口径）。 */
    rel: string;
    text: string;
    /** 文件 mtime（ISO），重建时当 updatedAt。 */
    mtimeMs: number;
}
/**
 * 递归遍历一组页面根目录，逐个读出正文（P3-D4 / 方案 #46）。
 *
 * 抽出来的理由：`links.ts` 的图谱扫描与索引重建**必须共用同一次遍历**
 * ——两处各扫一遍盘是纯浪费，而且两份遍历迟早会漂移出不同的过滤规则。
 * 读不出来的文件静默跳过（调用方要的是「能用的页面」，不是一份错误清单）。
 */
export declare function walkPages(vaultRoot: string, dirs: string[]): AsyncGenerator<DiskPage>;
/**
 * 按字符区间切一段正文，并在两端对齐到行边界。
 * 用于大型文件只取一部分喂给 Agent。
 */
export declare function sliceByLines(content: string, offset: number, maxChars: number): {
    text: string;
    from: number;
    to: number;
    total: number;
};
/**
 * 按本地时区把 Date 格式化成 YYYY-MM-DD。
 *
 * 直接用 `toISOString().slice(0, 10)` 是错的：那是 UTC 日期，
 * 本地 8 月 1 日 07:00（UTC+8）会被记成 7 月 31 日。
 * 时间戳错一天，将来按日期检索、按日归档全会跟着偏。
 */
export declare function localDateStamp(d: Date): string;
/** 相对路径统一成正斜杠，便于跨平台比对与展示（硬约束 11）。 */
export declare function relPosix(from: string, to: string): string;
/** 重建索引时的单个页面重建结果（P3-D4）。 */
export interface RebuildReport {
    /** 成功重建的页面数。 */
    rebuilt: number;
    /** frontmatter 缺字段或解析失败的页面——**不丢**，逐个报出原因。 */
    unparsed: Array<{
        path: string;
        reason: string;
    }>;
    /** 重建出的页面记录（key = 相对 vaultRoot 的 POSIX 路径）。 */
    pages: Record<string, PageEntry>;
}
/**
 * 从磁盘 frontmatter 重建 `index.pages`（P3-D4 / 方案 #46 / 硬约束 8）。
 *
 * 为什么必须有：`index.pages` 全仓只有 `kb_write` 写过，`kb_scan` 重建得了
 * `materials`（它遍历 `00_Inbox_Raw`）却重建不了 `pages`。后果链是——索引一丢，
 * 覆盖守卫退化成「目标文件已存在，但它不是本插件写的」（`guardWrite` 找不到
 * `contentHash`），必须 `force:true` 才能更新；`kb_search` 的 tag/title 模式
 * 全空；`kb_status` 报 0 页。而「索引是派生数据、可以弃」这句话，
 * **前提正是它能从权威侧重建**——这条函数就是补那个前提。
 *
 * 两条边界（「我没看到 ≠ 我没有」）：
 *   · frontmatter 坏掉的页面**不静默跳过**，进 `unparsed` 并带原因；
 *   · `source_hash` 缺失时留空串而不是编一个——空串在守卫里是「未知」，
 *     编出来的值会假装「已核实」。
 */
export declare function rebuildPagesFromDisk(vaultRoot: string, dirs: string[], parse: (markdown: string) => {
    data: Record<string, string | string[]>;
    body: string;
}): Promise<RebuildReport>;
export interface WriteGuardResult {
    ok: boolean;
    reason?: string;
    existed: boolean;
}
/**
 * 守卫：写入前检查目标文件是否被人改动过。
 *
 * 判定依据是索引里记的 contentHash 与磁盘当前内容的哈希。
 * 二者不一致 = 人动过 = 拒绝覆盖（除非 force）。新建文件永远允许。
 */
export declare function guardWrite(targetPath: string, index: KbIndex, force: boolean): Promise<WriteGuardResult>;
