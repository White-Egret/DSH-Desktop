# -*- coding: utf-8 -*-
"""
拉丁文词条归一化（查询键）——与 src/dict/fold.ts 逐条对应（硬约束 4）。

入库（本文件，写入时算 lemma_fold）与查询（Node fold.ts，WHERE lemma_fold = fold(?)）
必须逐字符一致——算法漂移的症状是「库里有这个词、查不到」，不报错、不崩溃，
只有共享测试向量（test/fixtures/fold-vectors.json，tools/test_ingest.py 读）能拦住它。

步骤（P3-E1 起六步，方案 7.6）：
  0. NFKC 兼容分解（全角 ｖｉｔａ → vita；连字 ﬀ → ff）
  1. NFD 分解 + 去掉组合变音符
  2. 小写化
  3. 显式映射 æ→ae、œ→oe、ß→ss（无规范分解，NFD 拆不掉；必须在**小写之后**做，
     否则 Æ（大写）映射不到——向量 Æneas→aeneas 专门钉住这一条）
  4. 长音符翻译表（预组合字符兜底，NFD 未必拆得掉）
  5. j→i、v→u（拉丁语原文这两组字母不分）

改了任何一步都要抬 _FOLD_VERSION 并同步 src/dict/fold.ts 的 FOLD_VERSION；
库里 meta.fold_version 对不上时查询层报 unavailable（否则新规则拿旧键查，
症状还是「查不到」）。
"""
import unicodedata

# 与 src/dict/fold.ts 的 FOLD_VERSION 必须逐值相同（测试会比对）
_FOLD_VERSION = 2

_ACCENT_SRC = "āēīōūûăĕĭŏŭãẽĩõũ"
_ACCENT_DST = "aeiou" "u" "aeiou" "aeiou"
_ACCENT_TABLE = str.maketrans(_ACCENT_SRC, _ACCENT_DST)


def fold_version():
    return _FOLD_VERSION


def fold(s):
    out = unicodedata.normalize("NFKC", s)
    out = unicodedata.normalize("NFD", out)
    out = "".join(ch for ch in out if not unicodedata.category(ch).startswith("M"))
    out = out.lower()
    out = out.replace("æ", "ae").replace("œ", "oe").replace("ß", "ss")
    out = out.translate(_ACCENT_TABLE)
    out = out.replace("j", "i").replace("v", "u")
    return out