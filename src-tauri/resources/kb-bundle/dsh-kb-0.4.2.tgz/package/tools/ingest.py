#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ingest.py —— 词典区间摄取（P2-B，离线，两段式）。

分工（方案①，已核实 dsh_bridge 由桥接运行时注入、脚本无法独立 import）：
  · 本脚本负责：校验区间 → 切片（pypdf）→ 打印转换指令 → 切词条
    （tools/parsers）→ 入库（sqlite3，同一事务「删旧 + 插新」）。
  · Agent 编排：拿到切片后调用 DSH 的 convert_file_to_markdown 工具
    （prefer='layout'、max_chars=0，这两个参数是硬要求，见 B2），把产出的
    .md 路径喂给 commit / abbrev 子命令。

刻意不做（B0）：批调度器、断点状态机、一次性吞全书的自动重试——真实用法
是「用户说处理 21–40 页，Agent 跑一次，看结果，再下一段」。限流了自己停
一下，这比任何重试逻辑都可靠。状态只有两处：manifest.json（覆盖区间）
与 dictionaries.status（'ingesting' / 'ready'，查询只认 ready，见设计 5）。

子命令：
  slice       校验区间 → 切片 PDF → 打印 convert_file_to_markdown 指令
  commit      切词条 → 同一事务「删旧区间 + 插新」→ 更新 manifest
  abbrev      把缩略语表页（slice --skip-pages 切出的 front 切片）存入 abbreviations
  mark-ready  摄取完成后把词典标为 ready（查询只认 ready；有词条才允许）
  status      打印各词典的已覆盖 / 未覆盖区间与词条数（--dict 可选）

幂等（B4）：同一区间重跑 = 先删该区间完全覆盖的旧条目再插入，同一事务；
跑坏了重跑一遍即可。已知限制：切片在页边界切断跨页词条——区间首部的
续文会被 latin_ocr 标 page_boundary_risk，见到时用略重叠的区间复跑。
"""
import argparse
import hashlib
import json
import os
import sqlite3
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from fold import fold, fold_version  # noqa: E402
from parsers import latin_html, latin_ocr  # noqa: E402

# 与 src/dict/lookup.ts 的 DICT_BODY_CAP 一致（BMP 内 Node 的 .length 与
# Python 的 len 同为码元计数；词典正文不出 BMP，跨端一致）。
CHUNK_SIZE = 2000
MAX_PAGES_PER_SLICE = 20  # convert_file_to_markdown 单次 ≤20 页（B2），超了让人拆

# 库级版本指纹（P3-E2）。parser_version 改动 = 切词条规则变了，旧区间可能要重跑；
# fold_version 必须与 src/dict/fold.ts 的 FOLD_VERSION、tools/fold.py 的
# _FOLD_VERSION 三者相同——Node 侧打开库先比对 fold_version，不匹配报 unavailable。
SCHEMA_VERSION = 2
PARSER_VERSION = "latin_ocr/3"

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS dictionaries (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  lang        TEXT NOT NULL,
  coverage    TEXT,
  quality     TEXT,
  entry_count INTEGER,
  imported_at TEXT,
  status      TEXT NOT NULL DEFAULT 'ingesting'
);
CREATE TABLE IF NOT EXISTS entries (
  id            INTEGER PRIMARY KEY,
  lemma         TEXT NOT NULL,
  lemma_fold    TEXT NOT NULL,
  pos           TEXT,
  body          TEXT NOT NULL,
  source        TEXT NOT NULL REFERENCES dictionaries(id),
  page_from     INTEGER,
  page_to       INTEGER,
  quality       TEXT,
  doubtful      INTEGER DEFAULT 0,
  reconstructed INTEGER DEFAULT 0,
  pos_source    TEXT,
  chars         INTEGER
);
CREATE INDEX IF NOT EXISTS idx_lemma_fold ON entries (lemma_fold, source);
CREATE INDEX IF NOT EXISTS idx_lemma ON entries (lemma, source);
CREATE VIRTUAL TABLE IF NOT EXISTS entries_fts USING fts5(body, tokenize='unicode61');
CREATE TABLE IF NOT EXISTS chunks (
  entry_id INTEGER NOT NULL,
  seq      INTEGER NOT NULL,
  body     TEXT NOT NULL,
  PRIMARY KEY (entry_id, seq)
);
CREATE TABLE IF NOT EXISTS abbreviations (
  dict_id   TEXT NOT NULL REFERENCES dictionaries(id),
  abbr      TEXT NOT NULL,
  expansion TEXT NOT NULL,
  kind      TEXT,
  PRIMARY KEY (dict_id, abbr)
);

-- P3-E2（方案 7.6）：ranges 一次承担三件事——commit point（先写词条、最后写这张
-- 表）、幂等的可见边界、每区间的质量信号。ranges 里有这一行，才代表这一段真的
-- 跑完了；没有就是没跑过（中途失败整体回滚）。
CREATE TABLE IF NOT EXISTS ranges (
  dict_id        TEXT NOT NULL REFERENCES dictionaries(id),
  page_from      INTEGER NOT NULL,
  page_to        INTEGER NOT NULL,
  entries        INTEGER NOT NULL DEFAULT 0,
  merged         INTEGER NOT NULL DEFAULT 0,  -- 未构成词头、并入上一条的行数（漏检下界）
  fp_suspect     INTEGER,                     -- lemma 撞 siglum 表的条数（NULL = 没测过）
  boundary_risk  INTEGER NOT NULL DEFAULT 0,  -- 区间首尾疑似跨页续文的条数
  parser_version TEXT,
  fold_version   INTEGER,
  committed_at   TEXT,
  PRIMARY KEY (dict_id, page_from, page_to)
);

-- 库级元信息（P3-E2）：fold 规则版本与 schema 版本。Node 打开库先比对 fold_version，
-- 不匹配就报 unavailable——否则新规则拿旧键查，症状还是「查不到」。
CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT
);
"""


def out_utf8():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass


def die(msg: str, code: int = 2):
    print(f"错误：{msg}", file=sys.stderr)
    sys.exit(code)


def warn(msg: str):
    print(f"警告：{msg}")


def parse_range(s: str, what: str = "--pages"):
    """'21-40' / '5' → (from, to)。非法直接退出。"""
    import re as _re

    s = (s or "").strip()
    m = _re.fullmatch(r"(\d+)(?:\s*-\s*(\d+))?", s)
    if not m:
        die(f"{what} 格式不对：{s!r}（应为 '21-40' 或 '5'）")
    f = int(m.group(1))
    t = int(m.group(2)) if m.group(2) else f
    if f < 1:
        die(f"{what} 起点必须 ≥ 1：{s}")
    if f > t:
        die(f"{what} 起点大于终点：{s}（from ≤ to）")
    if t - f + 1 > MAX_PAGES_PER_SLICE:
        die(f"{what} 跨 {t - f + 1} 页，超过单次 {MAX_PAGES_PER_SLICE} 页上限（convert_file_to_markdown 限制），请拆成 ≤{MAX_PAGES_PER_SLICE} 页的小区间")
    return f, t


def dsh_home() -> str:
    env = os.environ.get("DSH_HOME", "").strip()
    if env:
        return env
    return os.path.join(os.environ.get("USERPROFILE") or os.path.expanduser("~"), ".dsh")


def default_build_dir(dict_id: str) -> str:
    return os.path.join(dsh_home(), "dsh-kb", "dict-build", dict_id)


def resolve_build(args, dict_id: str) -> str:
    return args.build_dir or default_build_dir(dict_id)


def resolve_db(args) -> str:
    if args.db:
        return args.db
    vault = getattr(args, "vault", None) or os.environ.get("DSH_KB_VAULT", "").strip()
    if vault:
        return os.path.join(vault, ".kb", "dictionaries.db")
    die("需要 --db <dictionaries.db 路径> 或 --vault <vaultRoot>（或环境变量 DSH_KB_VAULT）")


def local_stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def manifest_path(build_dir: str) -> str:
    return os.path.join(build_dir, "manifest.json")


def load_manifest(build_dir: str) -> dict:
    p = manifest_path(build_dir)
    if os.path.exists(p):
        with open(p, encoding="utf-8") as fh:
            return json.load(fh)
    return {"source": None, "sha256": None, "total_pages": None, "ranges_done": [], "updated_at": None}


def save_manifest(build_dir: str, data: dict):
    data["updated_at"] = local_stamp()
    os.makedirs(build_dir, exist_ok=True)  # commit 可能先于 slice 被调用（真件就遇到过）
    with open(manifest_path(build_dir), "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, indent=2)


def ensure_db(db_path: str) -> sqlite3.Connection:
    """打开（或新建）词典库并确保 schema。

    P3.1-R2 的不变量：**status='ready' 的成品库，任何子命令跑完之后都必须是
    journal_mode=delete、目录无 -wal/-shm**（E5 定的）。所以 WAL 只在**新建库**
    时设置（录入期 Python 写、Node 可能同时读）；已存在的库保留它当前的
    journal_mode——mark-ready 之后是 delete，后续 abbrev/commit 维护不翻回去。
    想给继续录入的成品库重新启用 WAL，手动 `PRAGMA journal_mode=WAL`。
    （修法 A：比「每个子命令结尾都调 _finalize_if_ready」少一个隐式行为。）
    """
    os.makedirs(os.path.dirname(os.path.abspath(db_path)), exist_ok=True)
    is_new = not os.path.exists(db_path)
    conn = sqlite3.connect(db_path)
    if is_new:
        conn.execute("PRAGMA journal_mode=WAL")  # 设计 5：读不阻塞写、写不阻塞读
    conn.executescript(SCHEMA_SQL)
    _write_meta(conn)
    return conn


def _write_meta(conn):
    """写库级元信息（缺失才写；已存在的不覆盖——created_at 要保真）。"""
    now = local_stamp()
    for key, value in (
        ("schema_version", str(SCHEMA_VERSION)),
        ("fold_version", str(fold_version())),
        ("parser_version", PARSER_VERSION),
        ("created_at", now),
    ):
        conn.execute("INSERT OR IGNORE INTO meta (key, value) VALUES (?, ?)", (key, value))
    conn.commit()


def read_meta(conn) -> dict:
    return {row[0]: row[1] for row in conn.execute("SELECT key, value FROM meta").fetchall()}


def sigla_of(conn, dict_id: str):
    """该词典已知 siglum 的归一化集合（E3 引文否决用）。

    表里还没有任何缩略语（第一个区间）时返回 None——调用方据此把 fp_suspect
    记成 NULL（「没测过」），而不是 0（「测了，没有」）。这两种状态必须能区分。
    """
    rows = conn.execute("SELECT abbr FROM abbreviations WHERE dict_id = ?", (dict_id,)).fetchall()
    if not rows:
        return None
    return {latin_ocr._siglum_key(r[0]) for r in rows if r[0] and latin_ocr._siglum_key(r[0])}


def count_fp_suspect(entries, sigla):
    """lemma 撞上 siglum 表的条数（E3 的误切嫌疑信号）。sigla 为 None 时返回 None。"""
    if sigla is None:
        return None
    return sum(1 for e in entries if e["lemma"] and latin_ocr._siglum_key(e["lemma"]) in sigla)


def merge_ranges(ranges):
    rs = sorted([list(r) for r in ranges])
    out = []
    for f, t in rs:
        if out and f <= out[-1][1] + 1:
            out[-1][1] = max(out[-1][1], t)
        else:
            out.append([f, t])
    return out


# ── slice ────────────────────────────────────────────────────────────────────

def cmd_slice(args):
    from pypdf import PdfReader, PdfWriter

    src = args.source
    if not os.path.exists(src):
        die(f"源文件不存在：{src}")
    f, t = parse_range(args.pages)
    reader = PdfReader(src)
    total = len(reader.pages)
    if t > total:
        die(f"区间终点 {t} 超过总页数 {total}（请缩小 --pages）")

    build = resolve_build(args, args.dict)
    os.makedirs(build, exist_ok=True)

    skip = None
    if args.skip_pages:
        skip = parse_range(args.skip_pages, "--skip-pages")
        if skip[1] < f or skip[0] > t:
            warn(f"--skip-pages {args.skip_pages} 与本次区间 {f}-{t} 无交集，忽略")
            skip = None
        elif skip[0] != f:
            die(f"--skip-pages 必须是 --pages 的前缀（前置材料在词典最前面）：--pages {f}-{t} vs --skip-pages {skip[0]}-{skip[1]}")

    parts = []  # (文件名, from, to, kind)
    if skip:
        body_from = skip[1] + 1
        if body_from > t:
            die(f"--skip-pages {args.skip_pages} 覆盖了整个 --pages {f}-{t}")
        parts.append((f"pages-{skip[0]:04d}-{skip[1]:04d}.front.pdf", skip[0], skip[1], "front"))
        parts.append((f"pages-{body_from:04d}-{t:04d}.pdf", body_from, t, "body"))
    else:
        parts.append((f"pages-{f:04d}-{t:04d}.pdf", f, t, "body"))

    produced = []
    for name, pf, pt, kind in parts:
        n = pt - pf + 1
        if n > MAX_PAGES_PER_SLICE:
            die(f"{name} 有 {n} 页 > {MAX_PAGES_PER_SLICE} 页上限（convert_file_to_markdown 限制），请拆成更小的区间")
        writer = PdfWriter()
        for i in range(pf - 1, pt):
            writer.add_page(reader.pages[i])
        out_pdf = os.path.join(build, name)
        with open(out_pdf, "wb") as fh:
            writer.write(fh)
        produced.append((out_pdf, pf, pt, kind, n))

    # manifest：原件事实（路径 / sha256 / 总页数）在 slice 时记下
    man = load_manifest(build)
    man["source"] = os.path.abspath(src)
    man["sha256"] = sha256_file(src)
    man["total_pages"] = total
    save_manifest(build, man)

    print(f"[1/2] 切片完成（词典 {args.dict}，原书共 {total} 页）：")
    for out_pdf, pf, pt, kind, n in produced:
        label = "front（前置材料 → abbrev 子命令）" if kind == "front" else "body（词条正文 → commit 子命令）"
        print(f"  {out_pdf}  （{n} 页，对应原书 {pf}–{pt}，{label}）")
    print("下一步（Agent 编排）——对每个切片调用 convert_file_to_markdown，参数必须是：")
    for out_pdf, pf, pt, kind, _n in produced:
        md_path = out_pdf[:-4] + ".md"
        print(f"  path: {out_pdf}")
        print(f"  prefer: 'layout'      # 三栏词典页，auto 路由会切错（方案 7.3 实测）")
        print(f"  max_chars: 0          # 默认 20000 会静默截断")
        print(f"  output_path: {md_path}")
        if kind == "body":
            print(f"转换完成后入库：python tools/ingest.py commit --dict {args.dict} --md \"{md_path}\" --pages {pf}-{pt} --db <db路径>")
        else:
            print(f"转换完成后存缩略语：python tools/ingest.py abbrev --dict {args.dict} --md \"{md_path}\" --db <db路径>")


# ── commit ───────────────────────────────────────────────────────────────────

def _parse_entries(md_text: str, parser_kind: str, quality: str, stats=None, sigla=None):
    if parser_kind == "html":
        parsed = latin_html.parse(md_text)
        if stats is not None:
            stats["merged"] = 0
            stats["boundary_risk"] = 0
            stats["siglum_veto"] = False
    else:
        # sigla 为 None（第一个区间，缩略语表还没入库）时不启用引文否决，
        # 只靠大小写敏感——stats["siglum_veto"] 记下这次到底测没测。
        parsed = latin_ocr.parse(md_text, stats=stats, sigla=sigla)
    for e in parsed:
        e["quality"] = quality
    return parsed


def cmd_commit(args):
    f, t = parse_range(args.pages)  # commit 侧同样守住 ≤20 页（与 slice 同一上限）
    if not os.path.exists(args.md):
        die(f"转换产物不存在：{args.md}")
    with open(args.md, encoding="utf-8") as fh:
        md_text = fh.read()

    parser_kind = args.parser
    if parser_kind not in ("ocr", "html"):
        die(f"--parser 只支持 ocr / html：{parser_kind}")
    quality = "high" if parser_kind == "html" else "medium"

    # E3：先把该词典已知的 siglum 表拿出来（第一个区间它还空 → 引文否决跳过）。
    # 读库只为了读 abbr；库不存在时 ensure_db 会建表，这里用一个临时只读意图：
    # 文件不存在就跳过（避免 dry-run 也去建库）。
    db_path = resolve_db(args)
    sigla = None
    if os.path.exists(db_path):
        probe = sqlite3.connect(db_path)
        try:
            sigla = sigla_of(probe, args.dict)
        except sqlite3.Error:
            sigla = None
        finally:
            probe.close()

    stats = {}
    entries = _parse_entries(md_text, parser_kind, quality, stats=stats, sigla=sigla)
    fp_suspect = count_fp_suspect(entries, sigla)
    print(f"解析出 {len(entries)} 条词条（parser={parser_kind}，quality={quality}，区间 {f}-{t}）")
    print(f"  质量信号：merged={stats.get('merged', 0)}（并入上一条的行数，漏检下界）"
          f" | fp_suspect={'NULL（siglum 表还没有，没测）' if fp_suspect is None else fp_suspect}"
          f" | boundary_risk={stats.get('boundary_risk', 0)}")

    risks = [e for e in entries if e["page_boundary_risk"]]
    for e in risks:
        preview = (e["body"][:40] + "…") if len(e["body"]) > 40 else e["body"]
        print(f"  ⚠ page_boundary_risk：区间首部的续文（lemma={e['lemma']!r}，{preview}）——上一区间尾词条被切，建议用略重叠的区间复跑")
    print("  提示：区间尾部词条同样可能被切（切片法固有代价，B4）；如需确认，复跑一个略有重叠的区间。")

    if args.dry_run:
        for e in entries[:10]:
            body = e["body"][:60] + ("…" if len(e["body"]) > 60 else "")
            flag = "†" if e["doubtful"] else ("*" if e["reconstructed"] else " ")
            print(f"  · {flag}{e['lemma'] or '(续行)'} | pos={e['pos'] or '-'} | {body}")
        print(f"--dry-run：未写库。共 {len(entries)} 条将写入 {args.dict}")
        return

    if not entries:
        die("0 条词条——检查 md 是否为空、--parser 是否选错（html 产物别用 ocr 解析）")

    conn = ensure_db(db_path)
    try:
        with conn:  # 同一事务：删旧 + 插新（B4 幂等），中途失败整体回滚
            dict_id = args.dict
            row = conn.execute("SELECT id FROM dictionaries WHERE id=?", (dict_id,)).fetchone()
            if row is None:
                conn.execute(
                    "INSERT INTO dictionaries (id, name, lang, coverage, quality, entry_count, imported_at, status)"
                    " VALUES (?, ?, ?, ?, ?, 0, ?, 'ingesting')",
                    (dict_id, args.name or dict_id, args.lang or "la", args.coverage or "", args.quality or quality, local_stamp()),
                )
            # status 只由 mark-ready 子命令翻转（设计 5：录入中的词典不参与查词）
            # 元信息补齐（真件实测的两处静默失败）：前置材料先跑 abbrev 时行是以
            # id 建的（name=老 id、quality=NULL），之后 commit 带的 --name/--coverage
            # 不能丢；quality 为 NULL 时按 parser 落默认值——设计 4 要求 quality
            # 必须透出，OCR 本绝不能以「未知可靠度」出现在查询结果里。
            if args.name or args.coverage:
                conn.execute(
                    "UPDATE dictionaries SET name = COALESCE(NULLIF(?, ''), name),"
                    " coverage = COALESCE(NULLIF(?, ''), coverage) WHERE id = ?",
                    (args.name or "", args.coverage or "", dict_id),
                )
            conn.execute(
                "UPDATE dictionaries SET quality = ? WHERE id = ? AND (quality IS NULL OR quality = '')",
                (args.quality or quality, dict_id),
            )
            old_ids = [r[0] for r in conn.execute(
                "SELECT id FROM entries WHERE source = ? AND page_from >= ? AND page_to <= ?",
                (dict_id, f, t),
            ).fetchall()]
            if old_ids:
                qm = ",".join("?" * len(old_ids))
                conn.execute(f"DELETE FROM entries_fts WHERE rowid IN ({qm})", old_ids)
                conn.execute(f"DELETE FROM chunks WHERE entry_id IN ({qm})", old_ids)
                conn.execute(f"DELETE FROM entries WHERE id IN ({qm})", old_ids)
            for e in entries:
                body = e["body"]
                cur = conn.execute(
                    "INSERT INTO entries (lemma, lemma_fold, pos, body, source, page_from, page_to, quality,"
                    " doubtful, reconstructed, pos_source, chars) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        e["lemma"], fold(e["lemma"]), e["pos"], body, dict_id, f, t,
                        e["quality"], e["doubtful"], e["reconstructed"], e["pos_source"], len(body),
                    ),
                )
                entry_id = cur.lastrowid
                conn.execute("INSERT INTO entries_fts (rowid, body) VALUES (?, ?)", (entry_id, body))
                if len(body) > CHUNK_SIZE:
                    for seq in range(0, -(-len(body) // CHUNK_SIZE)):
                        conn.execute(
                            "INSERT INTO chunks (entry_id, seq, body) VALUES (?, ?, ?)",
                            (entry_id, seq, body[seq * CHUNK_SIZE:(seq + 1) * CHUNK_SIZE]),
                        )
            conn.execute(
                "UPDATE dictionaries SET entry_count = (SELECT count(*) FROM entries WHERE source = ?) WHERE id = ?",
                (dict_id, dict_id),
            )
            # P3-E2 commit point：ranges 行必须在**同一个事务**里最后写。
            # 有这一行 = 这一段真的跑完了；没有 = 没跑过（中途失败整体回滚）。
            conn.execute(
                "INSERT OR REPLACE INTO ranges (dict_id, page_from, page_to, entries, merged,"
                " fp_suspect, boundary_risk, parser_version, fold_version, committed_at)"
                " VALUES (?,?,?,?,?,?,?,?,?,?)",
                (
                    dict_id, f, t, len(entries),
                    stats.get("merged", 0),
                    fp_suspect,                      # None → NULL（= 没测过，不是 0）
                    stats.get("boundary_risk", 0),
                    PARSER_VERSION, fold_version(), local_stamp(),
                ),
            )
            conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES ('parser_version', ?)",
                (PARSER_VERSION,),
            )
            conn.execute(
                "INSERT OR REPLACE INTO meta (key, value) VALUES ('fold_version', ?)",
                (str(fold_version()),),
            )
        deleted = len(old_ids)
        print(f"入库完成：写入 {len(entries)} 条（删除该区间旧条目 {deleted} 条），ranges 已记 {f}-{t} → {db_path}")
    finally:
        conn.close()

    if args.verify:
        run_verify(args.md, None, len(entries))

    build = resolve_build(args, args.dict)
    man = load_manifest(build)
    ranges = [list(r) for r in man.get("ranges_done", []) if [f, t] != list(r)]
    ranges.append([f, t])
    man["ranges_done"] = merge_ranges(ranges)
    save_manifest(build, man)


# ── abbrev ───────────────────────────────────────────────────────────────────

def parse_abbreviations(text: str, region: str = "general"):
    """缩略语表页 → [{abbr, expansion, kind}]（真件规则，OLD 前置材料实测）。

    OLD 的缩略语散在三种版式里，全部要认：
      · **四栏** GENERAL ABBREVIATIONS：`| abbr | 展开 | abbr | 展开 |`（一行两条），
        换行续写的行首是空格单元格 → 追加到**同列**上一条的展开里。
      · **五栏** BIBLIOGRAPHICAL GUIDE：`| SIGL. 作品缩写 引证例 | 作者 | 作品名 | 年代 | 版本 |`。
        第一栏混着 siglum 和引证示例，所以：
          - 作者级：`CIC.` → `M. Tullius Cicero`（取第一个 token，展开只取作者栏）
          - 作品级复合键：`CIC. Ac.` → `M. Tullius Cicero, Academica`
            （引文里出现的正是这种两级形式，复合键才能展开 `CIC. Rep. 2.39`）
        作者栏与作品栏都空的行是上一条的续引（`| praet. 42 | | | | |`）→ 跳过。
      · **三栏** 补充清单：`| CIL | Corpus Inscriptionum Latinarum | Berlin 1863– |`
      · **两栏文本**（无表格线时）：`ABBR␣␣+ 展开`

    `kind` 按**来源区域**判定（P3-E4 / 方案 #54），不看外形：
      书目表（`region='biblio'`）里的条目一律 `'ref'`——那里的 `ACC.` 是
      L. Accius、`Tr.` 是 Tristia、`V.` 是 C. Valerius Flaccus、`M.` 是 M. Sergius，
      外形与词性标号同形但语义完全不同（真库实测 83 条 `'pos'` 里 10/12 是错的）。
      通用缩略语表（`region='general'`）里且在 `latin_pos.txt` 中的才是 `'pos'`。
    """
    import re as _re

    pos_set = latin_ocr.load_pos_set()
    rows = []
    seen = set()          # 已发出的 (abbr) —— 作者级 siglum 在多行重复，取首次
    pending = [None, None]  # 四栏表里每个列对最后一条，供换行续写追加

    def kind_of(abbr):
        if region == "biblio":
            return "ref"  # 书目区域：一律文献缩写（E4）
        # P3.1-R2：**大小写敏感**（与 E3 的词性匹配同一理由）。OLD 的形态标号
        # 印小写斜体，大写形态是别的缩写——General Abbreviations 里的 `Ger.`
        # （German）撞 `ger.`（gerund）就是实测反例，lower() 后会错标 'pos'。
        # 解析器读的是 latin_pos.txt 本身、不读 kind 列，这只影响 kind 的分类
        # （expand 同形决胜 / 将来的 POS 来源），朝「大写一律 ref」收是安全方向
        # （宁窄勿宽）。带点/不带点两种写法都试（表页里两种都有）。
        a = abbr.strip()
        return "pos" if (a in pos_set or a + "." in pos_set) else "ref"

    def emit(abbr, expansion, pair_idx=None):
        abbr = (abbr or "").strip()
        expansion = (expansion or "").strip()
        if not abbr or not expansion:
            return
        if _re.fullmatch(r"[-:= ]+", abbr) or _re.fullmatch(r"[-:= ]+", expansion):
            return
        if abbr.lower() in ("abbr", "abbreviation", "缩写", "abbreviations"):
            return
        if abbr in seen:
            return  # 作者级 siglum 在多行重复出现，取首次
        seen.add(abbr)
        rows.append({"abbr": abbr, "expansion": expansion, "kind": kind_of(abbr)})
        if pair_idx is not None:
            pending[pair_idx] = rows[-1]

    def emit_pair(cells, idx, pair_idx):
        """四栏表的一个列对：abbr 空 = 上一条展开文本的换行续写。"""
        abbr = cells[idx].strip() if idx < len(cells) else ""
        expansion = cells[idx + 1].strip() if idx + 1 < len(cells) else ""
        if not abbr and expansion and pending[pair_idx] is not None:
            pending[pair_idx]["expansion"] += " " + expansion
            return
        emit(abbr, expansion, pair_idx)

    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if not any(cells) or all(_re.fullmatch(r"[-:= ]*", c) for c in cells):
                continue  # 全空行 / | --- | --- | 分隔行
            n = len(cells)
            if n == 4:
                emit_pair(cells, 0, 0)
                emit_pair(cells, 2, 1)
            elif n >= 5:
                first = (cells[0] or "").split()
                if not first:
                    continue
                siglum = first[0]
                author, title = cells[1], cells[2]
                if not author and not title:
                    continue  # 上一条的续引行（| praet. 42 | | | | |）
                if not _re.match(r"^[A-Za-z][A-Za-z0-9.]*\.?$", siglum):
                    continue
                emit(siglum, author if author else title)
                if len(first) > 1 and (author or title):
                    comp = f"{siglum} {first[1]}"
                    exp = ", ".join([p for p in (author, title) if p])
                    if exp and comp not in seen:
                        seen.add(comp)
                        rows.append({"abbr": comp, "expansion": exp, "kind": "ref"})
            elif n == 3:
                emit(cells[0], cells[1])
            else:
                emit_pair(cells, 0, 0)
            continue
        m = _re.match(r"^(.{1,24}?)\s{2,}(\S.*)$", line)
        if m:
            emit(m.group(1), m.group(2))
    return rows


def cmd_abbrev(args):
    if not os.path.exists(args.md):
        die(f"转换产物不存在：{args.md}")
    with open(args.md, encoding="utf-8") as fh:
        text = fh.read()
    rows = parse_abbreviations(text, region=args.region)
    if args.dry_run:
        for r in rows[:15]:
            print(f"  · {r['abbr']}  →  {r['expansion']}  [{r['kind']}]")
        print(f"--dry-run：未写库。共 {len(rows)} 条缩略语（pos={sum(1 for r in rows if r['kind'] == 'pos')}，"
              f"ref={sum(1 for r in rows if r['kind'] == 'ref')}）")
        return
    if not rows:
        die("0 条缩略语——这份 md 可能不是缩略语表页（表格没解析出行），确认 --md 指向 front 切片的转换产物")
    db_path = resolve_db(args)
    conn = ensure_db(db_path)
    try:
        with conn:
            dict_id = args.dict
            row = conn.execute("SELECT id FROM dictionaries WHERE id=?", (dict_id,)).fetchone()
            if row is None:
                conn.execute(
                    "INSERT INTO dictionaries (id, name, lang, coverage, quality, entry_count, imported_at, status)"
                    " VALUES (?, ?, ?, NULL, NULL, 0, ?, 'ingesting')",
                    (dict_id, args.name or dict_id, (args.lang or "la").strip(), local_stamp()),
                )
            # 累加式 upsert（真件规则）：OLD 的缩略语散在多处前置页（书目表
            # p.i–xxvi + 通用缩略语 p.xxvii–…），每个区间一次 abbrev 调用；整表
            # 重建会让后一次把前一次清光。语义：同一次运行内重复的 siglum 取
            # 首次（作者级缩写在多行重复），跨运行同 abbr 取后者（重跑=修正）。
            conn.executemany(
                "INSERT OR REPLACE INTO abbreviations (dict_id, abbr, expansion, kind) VALUES (?, ?, ?, ?)",
                [(dict_id, r["abbr"], r["expansion"], r["kind"]) for r in rows],
            )
    finally:
        conn.close()
    print(f"缩略语入库：{len(rows)} 条（pos={sum(1 for r in rows if r['kind'] == 'pos')}，"
          f"ref={sum(1 for r in rows if r['kind'] == 'ref')}）→ {db_path}")
    print("注意：缩略语不影响 dictionaries.status；词条 commit 后仍需 mark-ready（设计 5）。")


# ── mark-ready / status ──────────────────────────────────────────────────────

def cmd_mark_ready(args):
    db_path = resolve_db(args)
    if not os.path.exists(db_path):
        die(f"词典库不存在：{db_path}")
    conn = sqlite3.connect(db_path)
    try:
        row = conn.execute("SELECT id, status FROM dictionaries WHERE id=?", (args.dict,)).fetchone()
        if row is None:
            die(f"词典 {args.dict} 不在库里（先 commit 至少一个区间）")
        n = conn.execute("SELECT count(*) FROM entries WHERE source=?", (args.dict,)).fetchone()[0]
        if n == 0:
            die("词典 0 条词条——标 ready 会让查询把「未录到」误判成「词典没有」，先摄取")
        with conn:
            conn.execute("UPDATE dictionaries SET status='ready' WHERE id=?", (args.dict,))
        # P3-E5（方案 #56）：成品库此后**永远只读**，WAL 一分钱好处都没有，而
        # 它留下 -wal/-shm 两个兄弟文件，且「只读打开一个 WAL 库仍需要对所在
        # 目录有写权限」（SQLite 要建/读 -shm；目录不可写时 SQLITE_CANTOPEN）。
        # 摄入期仍保持 WAL（Python 写、Node 可能同时读），收尾时切回 DELETE。
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        mode = conn.execute("PRAGMA journal_mode=DELETE").fetchone()[0]
    finally:
        conn.close()
    print(f"词典 {args.dict} 已标记 ready（{n} 条词条），journal_mode={mode}（成品库不带 -wal/-shm）。")
    print("再次摄取新区间前如需暂停查询，把 dictionaries.status 改回 'ingesting' 即可；"
          "需重新启用 WAL 时新开连接执行 PRAGMA journal_mode=WAL。")


def cmd_status(args):
    build_root = os.path.dirname(resolve_build(args, args.dict or "x"))
    db_path = resolve_db(args) if (args.db or args.vault or os.environ.get("DSH_KB_VAULT")) else None
    conn = None
    if db_path and os.path.exists(db_path):
        conn = sqlite3.connect(db_path)
    dicts = []
    if conn is not None:
        if args.dict:
            dicts = conn.execute("SELECT id, name, status, entry_count FROM dictionaries WHERE id=?", (args.dict,)).fetchall()
        else:
            dicts = conn.execute("SELECT id, name, status, entry_count FROM dictionaries ORDER BY id").fetchall()
    elif args.dict:
        build = resolve_build(args, args.dict)
        if os.path.exists(manifest_path(build)):
            dicts = [(args.dict, args.dict, "（无库）", None)]
        else:
            die(f"既没有词典库，也没有 {args.dict} 的 manifest（build 目录：{build}）")
    else:
        # 无库：扫 build 目录下的 manifest
        if not os.path.isdir(build_root):
            die(f"没有词典库，也没有 build 目录：{build_root}")
        for name in sorted(os.listdir(build_root)):
            if os.path.exists(manifest_path(os.path.join(build_root, name))):
                dicts.append((name, name, "（无库）", None))
        if not dicts:
            die(f"没有词典库，build 目录里也没有 manifest：{build_root}")

    print("词典摄取状态：")
    for dict_id, name, status, entry_count in dicts:
        line = f"  {dict_id}（{name}）status={status} entries={entry_count if entry_count is not None else '?'}"
        man = load_manifest(os.path.join(build_root, dict_id))
        man_ranges = man.get("ranges_done") or []
        total = man.get("total_pages")

        # P3-E2：覆盖区间以 **ranges 表**为准（它才是 commit point）；manifest 是
        # 切片侧的记录，用来补 total_pages 与源路径。两者不一致时以库为准并提示。
        db_ranges = []
        row_stats = []
        if conn is not None:
            try:
                db_ranges = [
                    (r[0], r[1]) for r in conn.execute(
                        "SELECT page_from, page_to FROM ranges WHERE dict_id=? ORDER BY page_from", (dict_id,),
                    ).fetchall()
                ]
                row_stats = conn.execute(
                    "SELECT page_from, page_to, entries, merged, fp_suspect, boundary_risk"
                    " FROM ranges WHERE dict_id=? ORDER BY page_from", (dict_id,),
                ).fetchall()
            except sqlite3.Error:
                db_ranges, row_stats = [], []

        detail = []
        effective = db_ranges or man_ranges
        if effective:
            merged = merge_ranges([list(r) for r in effective])
            covered = sum(t - f + 1 for f, t in merged)
            src = "ranges 表" if db_ranges else "manifest（库里还没有 ranges 行）"
            detail.append(f"已覆盖 " + "、".join(f"{f}-{t}" for f, t in merged) + f"（{covered} 页，依据{src}）")
            nxt = max(t for _f, t in merged) + 1
            if total:
                if nxt <= total:
                    detail.append(f"未覆盖 {nxt}-{total}（建议下一段从 {nxt} 开始）")
                else:
                    detail.append("已到末页")
            else:
                detail.append(f"建议下一段从 {nxt} 开始")
        elif total:
            detail.append(f"已切源（{total} 页）但尚未 commit 任何区间")
        if man.get("source"):
            detail.append(f"源：{man['source']}")

        # 每区间的质量信号（方案 7.6 的四个信号里最需要人看的三个）。
        #
        # `merged` 是「未构成词头、并入上一条的行数」。**它天然偏高**：一个词条的
        # 释义往往占十几行，每行都算一次合并（真件 p.20：5 条词条 / 60 行并入）。
        # 所以不能拿绝对阈值判，只能在同一本词典内做**离群比较**：把每段的
        # merged/entries 比值与该词典的中位数比，超出 2 倍才算「明显偏高」。
        # 单段样本（只有一行）时中位数就是它自己 → 不判定（样本不足不报警）。
        if row_stats:
            ratios = sorted((mg / n) if n else float(mg) for _pf, _pt, n, mg, _fp, _br in row_stats)
            median = ratios[len(ratios) // 2] if ratios else 0.0
            detail.append("区间质量信号：")
            suspicious = []
            for pf, pt, n, mg, fp, br in row_stats:
                fp_txt = "没测（表还空）" if fp is None else str(fp)
                ratio = (mg / n) if n else float(mg)
                flags = []
                if len(row_stats) > 1 and median > 0 and ratio > 2 * median and mg >= 10:
                    flags.append(f"merged 偏高（本段 {ratio:.1f} 行/词条，本例中位数 {median:.1f}）")
                if fp:
                    flags.append("fp_suspect>0（lemma 撞 siglum，可能误切）")
                if br:
                    flags.append("boundary_risk>0（区间首尾疑似跨页续文）")
                mark = f"  ⚠ {', '.join(flags)}" if flags else ""
                detail.append(
                    f"  {pf}-{pt}: entries={n} merged={mg} fp_suspect={fp_txt} boundary_risk={br}{mark}"
                )
                if flags:
                    suspicious.append(f"{pf}-{pt}")
            if suspicious:
                detail.append(f"  建议复核：{'、'.join(suspicious)}（重跑一个略有重叠的区间）")

        print(line)
        for d in detail:
            print(f"      · {d}")
    if conn is not None:
        conn.close()


# ── 边界校验（B6，--verify，pdfplumber 可选）────────────────────────────────

def expected_heads(pdf_path: str):
    """每页「该有的词条数」估计：行首为粗体的行数（词典词头是粗体起始行）。

    pdfplumber 的字符内容对老扫描件是坏的，但位置与字体信息是准的（B6）。
    注意实测边界：OLD 这类扫描件带的是隐藏 OCR 层，整页可能没有任何粗体
    字体——此时该页记 None（估不出），对账只对可估的页做。
    """
    if os.environ.get("INGEST_TEST_NO_PDFPLUMBER"):
        print("--verify：pdfplumber 未安装（可选依赖，见 tools/requirements.txt），跳过边界校验")
        return None
    try:
        import pdfplumber
    except ImportError:
        print("--verify：pdfplumber 未安装（可选依赖，见 tools/requirements.txt），跳过边界校验")
        return None
    per_page = {}
    with pdfplumber.open(pdf_path) as pdf:
        for i, page in enumerate(pdf.pages, 1):
            try:
                words = page.extract_words(extra_attrs=["fontname"])
            except TypeError:  # 老版本 pdfplumber 没有 extra_attrs
                words = page.extract_words()
            if not words:
                per_page[i] = None
                continue
            has_bold = any("Bold" in str(w.get("fontname") or "") for w in words)
            if not has_bold:
                per_page[i] = None
                continue
            first_on_line = {}
            for w in words:
                key = round(w["top"] / 3)  # 3pt 行容差
                cur = first_on_line.get(key)
                if cur is None or w["x0"] < cur["x0"]:
                    first_on_line[key] = w
            per_page[i] = sum(1 for w in first_on_line.values() if "Bold" in str(w.get("fontname") or ""))
    return per_page


def run_verify(md_path: str, pdf_hint, n_entries: int):
    pdf_path = pdf_hint or (md_path[:-4] + ".pdf" if md_path.lower().endswith(".md") else None)
    if not pdf_path or not os.path.exists(pdf_path):
        print(f"--verify：找不到切片 PDF（{pdf_path}），跳过边界校验")
        return
    per_page = expected_heads(pdf_path)
    if per_page is None:
        return
    computable = {p: c for p, c in per_page.items() if c is not None}
    print("--verify 边界对账（expected=粗体行首估计，actual=本次解析词条数）：")
    for p in sorted(per_page):
        c = per_page[p]
        print(f"      p{p}: expected={c if c is not None else 'n/a（无粗体信息）'}")
    if not computable:
        print("      全部页面都无法估计（隐藏 OCR 层），对账跳过——见 B6 实测边界注释")
        return
    exp_total = sum(computable.values())
    ratio = n_entries / exp_total if exp_total else 0
    verdict = "OK"
    if ratio < 0.7:
        verdict = "低于阈值（可能漏检），待复核"
    elif ratio > 1.5:
        verdict = "高于阈值（可能误切），待复核"
    print(f"      合计 expected={exp_total} actual={n_entries} ratio={ratio:.2f} → {verdict}")


# ── CLI ──────────────────────────────────────────────────────────────────────

def main(argv=None):
    out_utf8()
    ap = argparse.ArgumentParser(prog="ingest.py", description="词典区间摄取（两段式：slice → convert（Agent）→ commit）")
    sub = ap.add_subparsers(dest="cmd", required=True)

    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--dict", help="词典 id（如 old / souter / ls）；status 子命令可省略（省略=全部）")
    common.add_argument("--db", help="dictionaries.db 路径（默认 <DSH_KB_VAULT>/.kb/dictionaries.db）")
    common.add_argument("--vault", help="vault 根目录（db = <vault>/.kb/dictionaries.db）")
    common.add_argument("--build-dir", help=f"工作目录（默认 <DSH_HOME>/dsh-kb/dict-build/<dict>）")
    common.add_argument("--dry-run", action="store_true", help="走完流程但不写库，打印将要写入的内容")

    p_slice = sub.add_parser("slice", parents=[common], help="校验区间 → 切片 → 打印转换指令")
    p_slice.add_argument("--source", required=True, help="词典原件 PDF")
    p_slice.add_argument("--pages", required=True, help="页区间，如 21-40")
    p_slice.add_argument("--skip-pages", help="前置材料页区间（如 1-3），必须是 --pages 的前缀；切出 front 切片供 abbrev 用")
    p_slice.set_defaults(func=cmd_slice)

    p_commit = sub.add_parser("commit", parents=[common], help="切词条 → 幂等入库 → 更新 manifest")
    p_commit.add_argument("--md", required=True, help="切片的转换产物（.md）")
    p_commit.add_argument("--pages", required=True, help="该切片对应的页区间，如 21-40")
    p_commit.add_argument("--parser", default="ocr", choices=["ocr", "html"], help="ocr=版面模型 markdown（quality medium）；html=结构化录入（quality high）")
    p_commit.add_argument("--name", help="词典显示名（仅首次建行时使用）")
    p_commit.add_argument("--lang", help="语种（仅首次建行时使用，默认 la）")
    p_commit.add_argument("--coverage", help="覆盖时代描述（仅首次建行时使用）")
    p_commit.add_argument("--quality", help="词典级可靠度（仅首次建行时使用；默认随 parser）")
    p_commit.add_argument("--verify", action="store_true", help="用 pdfplumber 做边界对账（可选依赖，缺了自动跳过）")
    p_commit.set_defaults(func=cmd_commit)

    p_abbrev = sub.add_parser("abbrev", parents=[common], help="缩略语表页入库（front 切片的转换产物）")
    p_abbrev.add_argument("--md", required=True, help="front 切片的转换产物（.md）")
    p_abbrev.add_argument("--name", help="词典显示名（仅首次建行时使用）")
    p_abbrev.add_argument("--lang", help="语种（仅首次建行时使用，默认 la）")
    p_abbrev.add_argument(
        "--region", default="general", choices=["general", "biblio"],
        help="这张表来自哪个区域：general=通用缩略语（可判 'pos'），biblio=书目表（一律 'ref'）",
    )
    p_abbrev.set_defaults(func=cmd_abbrev)

    p_ready = sub.add_parser("mark-ready", parents=[common], help="摄取完成后把词典标为 ready（查询只认 ready）")
    p_ready.set_defaults(func=cmd_mark_ready)

    p_status = sub.add_parser("status", parents=[common], help="打印已覆盖 / 未覆盖区间与词条数")
    p_status.set_defaults(func=cmd_status)

    args = ap.parse_args(argv)
    if args.cmd != "status" and not (args.dict or "").strip():
        die("--dict 必填（status 子命令可省略以列出全部）")
    args.func(args)


if __name__ == "__main__":
    main()
