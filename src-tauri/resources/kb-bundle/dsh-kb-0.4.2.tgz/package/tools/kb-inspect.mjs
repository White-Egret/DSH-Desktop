#!/usr/bin/env node
/**
 * 独立自检（P3-F2 / 方案 #50）。
 *
 * **刻意不 import `lib/`** —— dsh-rofm 的这条注释值得原样抄：
 * 「so a broken adapter cannot hide its own damage」。插件自己如果能「检查自己」
 * 就等于没有检查：`loadIndex` 坏掉的时候，用它写的自检会跟着一起坏，
 * 而且坏法一致，看起来一切正常。这个脚本只用 `node:fs` / `node:sqlite`，
 * 按 DDL 直接读文件。
 *
 * 三项检查，输出 PASS / WARN / FAIL（样本不足时 WARN 而不是 FAIL）：
 *   1. `.kb/index.json` 可读性 + version + 与 backup 的关系；
 *   2. index ↔ 磁盘**双向**对账（索引里有、磁盘没有 → broken；
 *      磁盘有、索引没有 → 可重建）；
 *   3. 词典库能否只读打开 + `meta.fold_version` 与代码里的 fold 版本一致 +
 *      ready 词典有几本、各覆盖哪些区间（读 ranges）。
 *
 * 用法：
 *   node tools/kb-inspect.mjs --vault <vaultRoot> [--dict <dictionaries.db>]
 *   node tools/kb-inspect.mjs --vault <vaultRoot> --json
 * 退出码：有 FAIL → 1，否则 0（WARN 不影响退出码）。
 */
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { DatabaseSync } from 'node:sqlite'
import { join, relative } from 'node:path'

// ── 参数 ─────────────────────────────────────────────────────────────────────

const argv = process.argv.slice(2)
function opt(name, fallback = undefined) {
  const i = argv.indexOf(`--${name}`)
  return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : fallback
}
const flag = (name) => argv.includes(`--${name}`)

const vaultRoot = opt('vault')
const jsonOut = flag('json')
if (!vaultRoot) {
  console.error('用法：node tools/kb-inspect.mjs --vault <vaultRoot> [--dict <db>] [--json]')
  process.exit(2)
}

const results = []
function record(level, check, detail) {
  results.push({ level, check, detail })
}

// ── 1. index.json 可读性 ─────────────────────────────────────────────────────

const kbDir = join(vaultRoot, '.kb')
const indexPath = join(kbDir, 'index.json')
const backupPath = join(kbDir, 'index.backup.json')

function readJson(path) {
  let raw
  try {
    raw = readFileSync(path, 'utf8')
  } catch (error) {
    return { ok: false, missing: error.code === 'ENOENT', reason: error.code === 'ENOENT' ? '文件不存在' : error.message }
  }
  try {
    return { ok: true, value: JSON.parse(raw), raw }
  } catch (error) {
    return { ok: false, missing: false, reason: `不是合法 JSON：${error.message}` }
  }
}

const primary = readJson(indexPath)
const backup = readJson(backupPath)
let index = null

if (!primary.ok && primary.missing) {
  record('warn', 'index.json 可读性', '索引不存在——空库或尚未 kb_scan；kb_scan 会从磁盘重建 pages')
} else if (!primary.ok) {
  record('fail', 'index.json 可读性', `主索引损坏：${primary.reason}`
    + (backup.ok ? '（backup 可用，内容按 backup 检查）' : '（backup 也不可用）'))
  if (backup.ok) index = backup.value
} else {
  const version = primary.value?.version
  if (version !== 2) {
    record('fail', 'index.json 版本', `version=${JSON.stringify(version)}，本插件只认 2`)
  } else if (typeof primary.value?.materials !== 'object' || typeof primary.value?.pages !== 'object') {
    record('fail', 'index.json 形状', '缺少 materials / pages 映射')
  } else {
    record('pass', 'index.json 可读性', `version=2，materials ${Object.keys(primary.value.materials).length} 条、`
      + `pages ${Object.keys(primary.value.pages).length} 条`)
    index = primary.value
    if (backup.ok) {
      const n = Object.keys(backup.value?.pages ?? {}).length
      record('pass', 'backup 关系', `index.backup.json 可读（pages ${n} 条，落后主文件一次写入）`)
    } else if (!backup.missing) {
      record('warn', 'backup 关系', `backup 存在但读不出来：${backup.reason}`)
    }
  }
}

// ── 2. index ↔ 磁盘双向对账 ─────────────────────────────────────────────────

function walkMd(dir, out) {
  let entries
  try {
    entries = readdirSync(dir, { withFileTypes: true })
  } catch {
    return
  }
  for (const e of entries) {
    const p = join(dir, e.name)
    if (e.isDirectory()) walkMd(p, out)
    else if (e.isFile() && e.name.toLowerCase().endsWith('.md')) out.push(p)
  }
}

const notesDir = join(vaultRoot, 'notes')
const digestsDir = join(vaultRoot, 'digests')
const onDisk = []
walkMd(notesDir, onDisk)
walkMd(digestsDir, onDisk)
const diskSet = new Set(onDisk.map((p) => relative(vaultRoot, p).split('\\').join('/')))

if (index === null) {
  record('warn', 'index ↔ 磁盘对账', `索引不可用，跳过对账；磁盘上 ${diskSet.size} 个页面文件`)
} else {
  const indexed = new Set(Object.values(index.pages ?? {}).map((p) => {
    const abs = p?.pagePath ?? ''
    return abs.startsWith(vaultRoot) ? relative(vaultRoot, abs).split('\\').join('/') : abs
  }).filter(Boolean))

  const ghost = [...indexed].filter((p) => !diskSet.has(p))       // 索引有、磁盘没有 → broken
  const unindexed = [...diskSet].filter((p) => !indexed.has(p))   // 磁盘有、索引没有 → 可重建

  if (ghost.length > 0) {
    record('fail', 'index ↔ 磁盘对账',
      `${ghost.length} 条索引记录在磁盘上找不到（页面被删/移走？）：${ghost.slice(0, 5).join('、')}`
      + (ghost.length > 5 ? ' …' : ''))
  } else {
    record('pass', 'index ↔ 磁盘对账', '索引里的页面在磁盘上都存在')
  }
  if (unindexed.length > 0) {
    record('warn', 'index 覆盖率',
      `${unindexed.length} 个磁盘页面不在索引里（kb_scan 可重建）：${unindexed.slice(0, 5).join('、')}`
      + (unindexed.length > 5 ? ' …' : ''))
  } else {
    record('pass', 'index 覆盖率', `磁盘上 ${diskSet.size} 个页面全部在索引里`)
  }
}

// ── 3. 词典库 ───────────────────────────────────────────────────────────────

const dictPath = opt('dict', join(kbDir, 'dictionaries.db'))
let dictExists = false
try {
  dictExists = statSync(dictPath).isFile()
} catch { /* 不存在 */ }

// fold 版本：**直接读源码常量**，不 import（损坏的 lib 不该能自证清白）
function codeFoldVersion() {
  try {
    const src = readFileSync(join(import.meta.dirname, '..', 'src', 'dict', 'fold.ts'), 'utf8')
    const m = src.match(/FOLD_VERSION\s*=\s*(\d+)/)
    return m ? Number(m[1]) : null
  } catch {
    return null
  }
}

if (!dictExists) {
  record('warn', '词典库', `没有 ${dictPath}（没建词典是常态，dict 工具不会被注册）`)
} else {
  // SQLite 是**惰性打开**的：`new DatabaseSync(..., {readOnly:true})` 本身可能成功，
  // 真正失败（SQLITE_CANTOPEN / errcode 14）发生在第一次 prepare。所以整段包起来，
  // 否则自检自己会崩——那就成了「坏得一致所以看不出来」的反面教材。
  let db = null
  try {
    db = new DatabaseSync(dictPath, { readOnly: true })
    db.prepare('PRAGMA journal_mode').get() // 触发真正的打开
  } catch (error) {
    record('fail', '词典库可读性', `只读打开失败：${error.message ?? error}。`
      + '若文件存在，检查目录是否可写——只读打开一个 WAL 模式的库也要目录写权限'
      + '（要建/读 -shm）；跑 ingest.py mark-ready 把成品库切成 journal_mode=DELETE 可消除这一要求')
    if (db !== null) { try { db.close() } catch { /* 已关 */ } }
    db = null
  }
  if (db !== null) {
    try {
      const meta = {}
      try {
        for (const r of db.prepare('SELECT key, value FROM meta').all()) meta[r.key] = r.value
      } catch { /* 老库没有 meta 表 */ }
      const journalMode = db.prepare('PRAGMA journal_mode').get()?.journal_mode ?? '?'
      record('pass', '词典库可读性', `只读打开成功，journal_mode=${journalMode}`)

      const code = codeFoldVersion()
      const recorded = meta.fold_version
      if (recorded === undefined) {
        record('fail', 'fold 版本', `库里没有 meta.fold_version（P3 之前的老库），代码是 ${code}；需重跑入库`)
      } else if (code === null) {
        record('warn', 'fold 版本', `库记录 fold_version=${recorded}，但读不到代码里的常量`)
      } else if (Number(recorded) !== code) {
        record('fail', 'fold 版本', `库 fold_version=${recorded} ≠ 代码 ${code}；查询会被闸门拦下，需重跑入库`)
      } else {
        record('pass', 'fold 版本', `一致（${recorded}）`)
      }

      const dicts = db.prepare('SELECT id, name, lang, status, entry_count FROM dictionaries ORDER BY id').all()
      const ready = dicts.filter((d) => d.status === 'ready')
      record(ready.length > 0 ? 'pass' : 'warn', '词典清单',
        `共 ${dicts.length} 本，ready ${ready.length} 本`
        + (dicts.length > 0 ? `：${dicts.map((d) => `${d.id}(${d.status},${d.entry_count ?? '?'})`).join(' ')}` : ''))

      // ranges 覆盖情况（方案 7.6 的审计线索）
      let ranges = []
      try {
        ranges = db.prepare(
          'SELECT dict_id, page_from, page_to, entries, merged, fp_suspect, boundary_risk'
          + ' FROM ranges ORDER BY dict_id, page_from',
        ).all()
      } catch { /* 老库没有 ranges 表 */ }
      if (ranges.length === 0) {
        record('warn', 'ranges 覆盖', '库里没有 ranges 行（老库或尚未 commit）；无法审计区间质量信号')
      } else {
        const byDict = new Map()
        const suspiciousRanges = []
        for (const r of ranges) {
          const list = byDict.get(r.dict_id) ?? []
          list.push(r)
          byDict.set(r.dict_id, list)
        }
        const parts = []
        for (const [id, list] of byDict) {
          const mergedRanges = []
          for (const r of list.sort((a, b) => a.page_from - b.page_from)) {
            const last = mergedRanges[mergedRanges.length - 1]
            if (last && r.page_from <= last[1] + 1) last[1] = Math.max(last[1], r.page_to)
            else mergedRanges.push([r.page_from, r.page_to])
          }
          // 自检只按**结构性**信号报警（fp_suspect / boundary_risk），不对 merged
          // 设绝对阈值——merged 天然偏高（一个词条的释义常占十几行），区间间的
          // 离群比较交给 `ingest.py status`（它看得到该词典全部区间）。
          const flagged = list.filter((r) => r.fp_suspect > 0 || r.boundary_risk > 0)
          const totalMerged = list.reduce((s, r) => s + (r.merged ?? 0), 0)
          const totalEntries = list.reduce((s, r) => s + (r.entries ?? 0), 0)
          parts.push(`${id}: ${mergedRanges.map(([a, b]) => `${a}-${b}`).join('、')}`
            + `（${list.length} 段，${totalEntries} 词条 / ${totalMerged} 行并入`
            + `${flagged.length > 0 ? `，${flagged.length} 段有 fp/boundary 信号` : ''}）`)
          suspiciousRanges.push(...flagged)
        }
        record(suspiciousRanges.length > 0 ? 'warn' : 'pass', 'ranges 覆盖', parts.join('；'))
      }
    } finally {
      db.close()
    }
  }
}

// ── 输出 ─────────────────────────────────────────────────────────────────────

if (jsonOut) {
  console.log(JSON.stringify({ vaultRoot, results }, null, 2))
} else {
  const icon = { pass: '✅', warn: '⚠️ ', fail: '❌' }
  console.log(`dsh-kb 自检（${vaultRoot}）`)
  for (const r of results) console.log(`  ${icon[r.level]} ${r.check}：${r.detail}`)
  const fails = results.filter((r) => r.level === 'fail').length
  const warns = results.filter((r) => r.level === 'warn').length
  console.log(`\n结论：${fails} FAIL / ${warns} WARN / ${results.length - fails - warns} PASS`)
}

process.exit(results.some((r) => r.level === 'fail') ? 1 : 0)