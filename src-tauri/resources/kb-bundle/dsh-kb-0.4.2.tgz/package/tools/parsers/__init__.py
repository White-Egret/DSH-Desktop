# -*- coding: utf-8 -*-
"""tools/parsers —— 词典词条切分器（阶段 B，被 tools/ingest.py 调用）。"""
