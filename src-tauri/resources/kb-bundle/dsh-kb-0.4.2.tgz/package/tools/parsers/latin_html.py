# -*- coding: utf-8 -*-
"""
latin_html.py —— 结构化 HTML → 词典词条（高质量录入路径，quality='high'）。

输入约定（摄取时按同一 schema 生成；'high' 的前提是结构真的在）：

    <article class="entry" data-lemma="amō">
      <span class="lemma">amō</span>   ← data-lemma 或 .lemma，二选一
      <span class="pos">v.</span>
      <span class="body">To love…</span>
    </article>

词性来自 .pos（视为表内确认，pos_source='table'）；正文 = article 内剥掉
词头/词性后的全部文本（嵌套标签安全）。没有词头的 article 不构成词条
（防模板噪声）。词条头里的 † / * 仍记 doubtful / reconstructed。

这是「直接读标签」的路径（B3 对照表）：边界不需要猜，准确率取决于
上游 HTML 的结构化程度，而不是 OCR。
"""
import html as _html
import re

_ENTRY_RE = re.compile(
    r"<article\b[^>]*class=\"[^\"]*\bentry\b[^\"]*\"[^>]*>(.*?)</article>", re.S | re.I
)
_LEMMA_RE = re.compile(
    r"data-lemma=\"([^\"]*)\"|<span[^>]*class=\"[^\"]*\blemma\b[^\"]*\"[^>]*>(.*?)</span>",
    re.S | re.I,
)
_POS_RE = re.compile(r"<[^>]*class=\"[^\"]*\bpos\b[^\"]*\"[^>]*>(.*?)</[^>]*>", re.S | re.I)


def _strip_tags(s: str) -> str:
    s = re.sub(r"<[^>]+>", " ", s)
    return _html.unescape(re.sub(r"\s+", " ", s)).strip()


def parse(text: str):
    """结构化 HTML 文本 → 词条列表（字段同 latin_ocr.parse）。"""
    entries = []
    for m in _ENTRY_RE.finditer(text):
        full = m.group(0)  # 含 <article …> 开标签——data-lemma 属性在这里
        block = m.group(1)  # 开闭标签之间的内容——正文从这里剥
        lm = _LEMMA_RE.search(full)
        if lm is None:
            continue
        lemma = _strip_tags(lm.group(1) or lm.group(2) or "")
        if not lemma:
            continue
        # 词头标记剥掉（与 latin_ocr._normalize_head 同语义）：†/+ → doubtful，
        # * → reconstructed；flag 由下方 head_region 判定，这里只剥字符。
        mm = re.match(r"^[\u2020*+]\s*", lemma)
        if mm:
            lemma = lemma[mm.end():]
        if not lemma:
            continue
        pm = _POS_RE.search(full)
        pos = _strip_tags(pm.group(1)) if pm else None
        # 正文 = block 剥掉词头 span 与词性 span 后的剩余文本（嵌套标签安全）。
        # data-lemma 在开标签上，不在 block 里，无需剥。
        body_src = block
        if lm.group(2) is not None:
            body_src = body_src.replace(lm.group(0), " ", 1)
        if pm is not None:
            body_src = body_src.replace(pm.group(0), " ", 1)
        body = _strip_tags(body_src)
        head_region = full[: lm.end()]
        entries.append(
            {
                "lemma": lemma,
                "pos": pos if pos else None,
                "pos_source": "table" if pos else None,
                "body": body,
                "doubtful": 1 if "\u2020" in head_region else 0,
                "reconstructed": 1 if "*" in head_region else 0,
                "page_boundary_risk": False,
            }
        )
    return entries
