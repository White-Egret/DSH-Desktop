# -*- coding: utf-8 -*-
"""
latin_ocr.py —— 版面模型输出的 markdown → 词典词条（方案 7.4 + 真件规则重写）。

词条边界**可能有漏切/误切**（真件只系统量过 1 页：人修版 5/5、原始 OCR 4/5；
没有跨区间的测量支撑任何具体百分比，所以不写数），调用方必须把本解析器的
产出标 quality='medium'。
**漏检的词条会并入上一个词条的正文，不是丢失**（方案 7.4）——所以这不是
自谦，是给查询方的实际警告。相对误切，漏切是可容忍的失败：内容还在、词头
丢了；误切则是词头与内容双双错。因此本文件的判据一律**宁窄勿宽**。

规则来源（不是凭空写的正则，是真件对出来的）：
原件 = OLD 前言之后的头 20 页（前置材料 + 正文 p.20 的 A¹/ā²/-a¹/-ā²/ab 段），
markdown 经 OXR 版面转换并由人对照扫描图修正。以下四条是真件教出来的：

1. **词头是形态串**，不是单个词：`ab, abs, ā prep.`、`ā², āh interj.`。
   → 取第一个逗号前形态作 lemma（可查键），其余形态留在 body 里。
     已知限制：按 `abs` 查不到本条——alt form 由 dict_search（FTS 全文）覆盖。
2. **短词性标号必须带点**：`m.` `f.` `n.` `a.` `advl.` `interj.` `prep.`。
   不带点的 `a b c d` 是**义项标号**（`b the regular abbreviation of the
   praenomen Aulus.`）。匹配不做 rstrip，靠这一点分界（见 latin_pos.txt 规则 1）。
3. **POS 槽最远在词头后第 4 个 token**（`ab,` `abs,` `ā` `prep.`）→ 窗口取 5。
4. **词性可以缺席**：字母名条目 `A¹, a. The first letter of the Latin
   alphabet…` 没有词性。补一条窄规则：首 token 形如「词头+同形号数字」且整行
   不是引文/义项行时，也成立。

符号处理（B5②）：† 存疑、* 重构词形——记 flag 并从 lemma 剥掉；† 的 OCR 变体
（`+`、行首孤立 `t`/`f`）**只有在剥掉后该行能构成词头时**才标 doubtful，
否则义项行 `f (objection).` 会被误标。`~`（词条重复占位）挂回上一条的 lemma。

Markdown 噪声：`|` 表格行、`---` 分隔线跳过；`#` 行**剥掉标记后当正文**
（OXR 常把义项标签 `c (poet.) apart from.` 识别成标题），只有剥完仍无小写字母
的才当章节标题跳掉。
"""
import os
import re

_SUPER = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")

# 词头首字符：拉丁字母（含带音符与扩展）、连字符（后缀条目 -a¹）、~（重复占位）
_HEAD_START = r"[A-Za-z\u00C0-\u024F\u1E00-\u1EFF\-~]"
# 义项标号：单个 a–h 字母（可带逗号/点）或纯数字（可带点/括号）——绝不能当词头
_SENSE_LABEL = re.compile(r"^(?:[a-hA-H][.,;]?|\d+[.,;]?|\d+\))$")
# 同形号词头（POS 缺席时的窄规则）：词头 + 数字 + 可选逗号
_HOMOGRAPH = re.compile(r"^" + _HEAD_START + r"{1,14}\d,?$")

_LEMMA_CLEAN = re.compile(r"^" + _HEAD_START + r"+")

POS_WINDOW = 5  # POS 标号最远出现在词头后第 4 个 token（真件 p.20 实测）

_POS_SET = None

# 引文/义项行的行首记号（OLD 正文用它们标记引文与子义项）
_BULLETS = ("▶", "•", "‣", "–", "—")


def load_pos_set():
    """读 latin_pos.txt（B5①：手工维护，不运行时抽取）。

    表内形式**按原样匹配**（带点就是带点）：只 lower()，不 rstrip('.')——
    带点与否正是词头与义项行的分水岭（规则 2）。
    """
    global _POS_SET
    if _POS_SET is not None:
        return _POS_SET
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "latin_pos.txt")
    pos_set = set()
    with open(path, encoding="utf-8") as fh:
        for raw in fh:
            line = raw.split("#", 1)[0].strip()
            if line:
                pos_set.add(line.lower())
    _POS_SET = pos_set
    return pos_set


def _siglum_key(s: str) -> str:
    """siglum 归一化键：小写 + 去点 + 折叠空白。

    与 src/dict/lookup.ts 的 siglumKey 只差一点——那边把点换成空格（保留
    `CIC. Ac.` 的两段结构），这边只需要「这一个 token 是不是某个 siglum」
    的单 token 判定，所以直接去点。两处口径不同是刻意的：用途不同。
    """
    return re.sub(r"[\s.]+", "", s.strip().lower())


def _delatex(s: str) -> str:
    """把版面模型偶尔吐出的 LaTeX 数学标记降级成普通字符。

    真件（OLD p.20 原始 OCR）里 `-ā²` 被排成 `- $\\tilde{a}^{2}$`：既不降级、
    也不合并，词头就变成孤零零的 `-` token 被当引文弹掉（实测丢条目）。
    \\tilde/\\bar/\\acute… 的音符直接丢掉——fold 本来就要去音符，查询键不受影响。
    """
    s = re.sub(r"\\(?:tilde|bar|hat|vec|acute|grave|breve|dot|ddot|macron|check){\s*([{}\\]?\w)}", r"\1", s)
    s = re.sub(r"\\text\{([^{}]*)\}", r"\1", s)
    s = re.sub(r"\^\{([^{}]*)\}", r"\1", s)          # ^{2} → 2
    s = re.sub(r"[_^](\w)", r"\1", s)                # ^2 / _2 → 2
    s = re.sub(r"\\[,\s;!]", "", s)
    s = re.sub(r"[${}\\]", "", s)
    return re.sub(r"\s{2,}", " ", s).strip()


def _head_candidate(tokens, pos_set, sigla=None):
    """token 序列 → (词头簇, POS token, 词性来源, 余下 tokens) 或 None。

    两条否决来自真件与方案 7.4「真件复核」（E3 / #55）：

    ① **词性标号大小写敏感**（`tokens[i] in pos_set`，pos_set 全小写）。
       OLD 的词性标号印成小写斜体，而作者/作品 siglum 印成小型大写，OCR 出
       `Tr.` `M.` `A.` `Part.`。用 lower() 比较会把这些 siglum 当词性，于是
       `Ov. M. 1.5` 被切成 lemma `Ov`（Metamorphoses 撞 m. = masculine）——
       构造的 10 条标准引文行实测 10/10 误切。这正是本文件「宁窄勿宽」的方向：
       OCR 偶尔把词性首字母大写时漏检（并入上一条，内容不丢），可容忍。
       真件那 5 个词头在大小写敏感下仍然全过（prep./interj./m./advl./a. 都小写）。

    ② **引文形状否决**：`tokens[0]` 归一化后命中该词典 siglum 表时，这一行不是
       词头。siglum 表还没有时（第一个区间）跳过这条否决，只靠 ①——
       「测出来是 0」和「没测」由调用方分别记（fp_suspect 列用 NULL 表达没测过）。
    """
    if not tokens or _SENSE_LABEL.match(tokens[0]):
        return None
    if sigla and _siglum_key(tokens[0]) in sigla:
        return None
    if tokens[0].startswith(_BULLETS):
        return None
    if tokens[0].startswith("("):
        return None

    # 主路径：窗口内找带点词性标号（大小写敏感）
    for i in range(1, min(len(tokens), POS_WINDOW + 1)):
        if tokens[i] in pos_set:
            return tokens[0:i], tokens[i], "table", tokens[i + 1:]

    # 后缀/前缀条目的两种形态：
    #   `-a1 m. suff.`     连字符粘在词头上（正常）
    #   `- a1 advl. suff.` 版面模型把连字符与词头拆开（真件 LaTeX 降级后的形态）
    # 拆开时 tokens[0] == '-'，词头簇从 tokens[1] 起算，并把 '-' 前缀补回 lemma。
    # 引文行（`- caput a ceruice reuulsum ENN. Ann. 472;`）窗口内没有带点词性标号，
    # 因此不会被误认——这正是允许这条规则的前提。
    if tokens[0] == "-" and len(tokens) > 2:
        for i in range(2, min(len(tokens), POS_WINDOW + 1)):
            if tokens[i] in pos_set and _LEMMA_CLEAN.match(tokens[1]):
                return ["-"] + tokens[1:i], tokens[i], "table", tokens[i + 1:]

    # 窄路径：同形号词头 + 大写起始的释义（POS 缺席，如字母名条目 A¹, a.）
    if _HOMOGRAPH.match(tokens[0]) and len(tokens) > 2 and tokens[2][:1].isupper():
        return tokens[0:2], None, None, tokens[2:]
    return None


def _normalize_flags(clean):
    """† / * 与 OCR 变体 → (去掉标记的文本, doubtful, reconstructed)。

    变体（`+`、行首孤立 `t`/`f`）只有在剥掉后仍能构成词头时才认——否则义项行
    `f (objection).` 之类会被误标。真实 † 与 * 无条件剥（连写 `*adprobus` 与
    分开 `* adprobus` 都要认——版面模型的两种产物都见过）。
    """
    if clean.startswith("\u2020"):
        return clean[1:].lstrip(), 1, 0
    if clean.startswith("* "):
        return clean[2:].lstrip(), 0, 1
    if clean.startswith("*") and len(clean) > 1 and _LEMMA_CLEAN.match(clean[1:]):
        return clean[1:].lstrip(), 0, 1
    for variant in ("+ ", "t ", "f "):
        if clean.startswith(variant):
            stripped = clean[len(variant):]
            if _LEMMA_CLEAN.match(stripped):
                return stripped, 1, 0
    return clean, 0, 0


def _split_forms(cluster_tokens):
    """词头簇 → (lemma 首形, 其余形态文本)。

    形态之间可能是逗号（`ab, abs, ā`）也可能是空格（`accūsātrīx ~īcīs`），
    所以**取第一个 token 作 lemma**（可查键），其余原样留在 body 开头。
    """
    parts = [p for p in " ".join(cluster_tokens).strip().split() if p]
    if not parts:
        return "", ""
    if parts[0] == "-" and len(parts) > 1:
        # 连字符与词头被版面模型拆开（后缀条目 -ā²）→ 补回去
        lemma = "-" + parts[1].strip(" .,;:")
        return lemma, " ".join(parts[2:]).strip(" ,;")
    lemma = parts[0].strip(" .,;:")
    rest = " ".join(parts[1:]).strip(" ,;")
    return lemma, rest


# 章节标题行（剥掉 # 之后没有小写字母，或整行没有字母）——前置材料的结构性噪声。
# 真件规则：OXR 会把义项标签也识别成标题（`# c (poet.) apart from.`），所以只有
# 「全大写」或「根本没有字母」（`# § 3`）的才当标题丢掉，带小写字母的一律留作正文。
def _is_section_title(text):
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return True
    return all(c.upper() == c for c in letters)


_SKIP_PREFIX = ("|", "!", "```", "---", "===")


def parse(text, stats=None, sigla=None):
    """markdown 文本 → 词条列表。

    每条：{lemma, pos, pos_source, body, doubtful, reconstructed,
           page_boundary_risk}
    首个词头之前的非装饰行 = 上一区间的续文 → lemma='' + page_boundary_risk。

    可选参数（P3-E2/E3，都是为了给 ranges 表填质量信号）：
      · stats：dict，parse 会往里写两条计数——
          merged         未构成词头、并入上一条的行数（**漏检的下界**：方案 7.4
                         的降级行为就是「并入上一条」，这个数直接量化「这一区间
                         有多少内容粘错了位置」）
          boundary_risk  区间首/尾疑似跨页续文的条数
      · sigla：该词典已知 siglum 的归一化集合（_siglum_key 口径）。给了就启用
        引文形状否决；不给（第一个区间，表还没有）就只靠大小写敏感。
    """
    pos_set = load_pos_set()
    entries = []
    current = None
    merged = 0

    def _flush():
        nonlocal current
        if current is not None:
            entries.append(current)
            current = None

    for raw in text.splitlines():
        s = raw.strip().translate(_SUPER)
        if "$" in s:
            s = _delatex(s)  # 版面模型的 LaTeX 产物（真件 p.20 的 -$\tilde{a}^{2}$）
        if not s or s.startswith(_SKIP_PREFIX):
            continue
        if s.startswith("#"):
            s = s.lstrip("#").strip()
            if not s or _is_section_title(s):
                continue  # 章节标题（GUIDE / CONVENTIONS / GENERAL ABBREVIATIONS）
        clean, doubtful, reconstructed = _normalize_flags(s.replace("**", " ").strip())

        tokens = clean.split()
        head = _head_candidate(tokens, pos_set, sigla)
        if head is None:
            if current is None:
                current = {
                    "lemma": "", "pos": None, "pos_source": None, "body": s,
                    "doubtful": 0, "reconstructed": 0, "page_boundary_risk": True,
                }
            else:
                current["body"] = (current["body"] + "\n" + s).strip()
                merged += 1  # 并入上一条 = 漏检的下界（方案 7.4 的降级行为）
            continue

        cluster, pos, pos_source, rest_tokens = head
        if cluster[0].startswith("~"):
            # 词条重复占位（~īcīs）：真词头是上一条的，正文保持原样（B5②）
            lemma = entries[-1]["lemma"] if entries else ""
            body = clean
        else:
            lemma, extra_forms = _split_forms(cluster)
            body = " ".join(([extra_forms] if extra_forms else []) + rest_tokens).strip()
        _flush()
        current = {
            "lemma": lemma,
            "pos": pos,
            "pos_source": pos_source,
            "body": body,
            "doubtful": doubtful,
            "reconstructed": reconstructed,
            "page_boundary_risk": False,
        }
    _flush()
    if stats is not None:
        stats["merged"] = merged
        stats["boundary_risk"] = sum(1 for e in entries if e["page_boundary_risk"])
        stats["siglum_veto"] = sigla is not None
    return entries
