#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ingest.py 的 Python 测试（阶段 B / stage-g）：直接 `python tools/test_ingest.py`。

覆盖验收 17–27：
  17 摄取小样（ocr 5 条 / html 3 条）  18 区间校验四种拒绝   19 切片与页码
  20 幂等重跑                          21 不重复造轮（转换调用点契约）
  22 无批调度器                        23 词性表覆盖动词      24 疑号与星号
  25 OCR 符号归一化                    26 前置材料被跳过      27 缩略语可查
外加：fold 共享向量（与 Node 同一份 fold-vectors.json，硬约束 4）。
"""
import json
import os
import sqlite3
import subprocess
import sys
import tempfile
import unittest

TOOLS = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(TOOLS)
sys.path.insert(0, TOOLS)

import fold  # noqa: E402
import ingest  # noqa: E402
from parsers import latin_html, latin_ocr  # noqa: E402

INGEST = os.path.join(TOOLS, "ingest.py")

# 永久真件回归夹具（P3 第 0 步）：唯一一份真实 OXR 产物。那 6 个 fake 测不出的
# 缺陷全是它抓出来的；重转要再花 OXR 额度，且换一次模型版本产物就变。
TESTDATA = os.path.join(TOOLS, "testdata")


def run_cli(args, vault):
    env = dict(os.environ)
    env["PYTHONIOENCODING"] = "utf-8"
    env["DSH_KB_VAULT"] = vault
    return subprocess.run(
        [sys.executable, INGEST] + args, capture_output=True, text=True,
        encoding="utf-8", env=env,
    )


def make_pdf(path, n_pages):
    from pypdf import PdfWriter

    w = PdfWriter()
    for _ in range(n_pages):
        w.add_blank_page(width=300, height=300)
    with open(path, "wb") as fh:
        w.write(fh)


# ── fold：共享测试向量（硬约束 4）────────────────────────────────────────────

class FoldTest(unittest.TestCase):
    def test_shared_vectors(self):
        with open(os.path.join(REPO_ROOT, "test", "fixtures", "fold-vectors.json"), encoding="utf-8") as fh:
            vectors = json.load(fh)
        self.assertGreaterEqual(len(vectors), 8)
        for v in vectors:
            with self.subTest(case=v["in"]):
                self.assertEqual(fold.fold(v["in"]), v["out"])

    def test_uppercase_paths(self):
        self.assertEqual(fold.fold("JŪS"), "ius")
        self.assertEqual(fold.fold("ŒNANTHĒ"), "oenanthe")


# ── latin_ocr（验收 17 / 23 / 24 / 25 / B4 边界）────────────────────────────

OCR_SAMPLE = """# 某词典正文

accūsātrīx  ~īcīs  f.  [Accvšō + -trāx]  A female accuser or prosecutor.
some continuation prose that belongs to the entry above.

amō  āre  v.t.  to love.
dīcō  ere  v.i.  (old dīcēbam) to say.
partiēns  part.  dividing.
gerundum  ger.  a thing to be done.
†accusabilis  a.  liable to accusation.
*adprobus  a.  approved (reconstructed).
"""


class LatinOcrTest(unittest.TestCase):
    def test_five_head_fields(self):
        es = latin_ocr.parse(OCR_SAMPLE)
        self.assertEqual(len(es), 7)
        e0 = es[0]
        self.assertEqual(e0["lemma"], "accūsātrīx")
        self.assertEqual(e0["pos"], "f.")
        self.assertEqual(e0["pos_source"], "table")
        self.assertIn("~īcīs", e0["body"])
        self.assertIn("A female accuser", e0["body"])
        self.assertIn("some continuation prose", e0["body"], "词条头之后的行并入正文")
        self.assertEqual(e0["doubtful"], 0)
        self.assertEqual(e0["reconstructed"], 0)

    def test_verb_class_pos_slots(self):
        es = latin_ocr.parse(OCR_SAMPLE)
        by_lemma = {e["lemma"]: e for e in es}
        self.assertEqual(by_lemma["amō"]["pos"], "v.t.")
        self.assertEqual(by_lemma["dīcō"]["pos"], "v.i.")
        self.assertEqual(by_lemma["partiēns"]["pos"], "part.")
        self.assertEqual(by_lemma["gerundum"]["pos"], "ger.")
        for k in ("amō", "dīcō", "partiēns", "gerundum"):
            self.assertEqual(by_lemma[k]["pos_source"], "table")

    def test_dagger_and_star(self):
        es = latin_ocr.parse(OCR_SAMPLE)
        by_lemma = {e["lemma"]: e for e in es}
        self.assertEqual(by_lemma["accusabilis"]["doubtful"], 1, "† 剥掉并记 flag")
        self.assertEqual(by_lemma["adprobus"]["reconstructed"], 1, "* 剥掉并记 flag")
        self.assertNotIn("†", by_lemma["accusabilis"]["lemma"])
        self.assertNotIn("*", by_lemma["adprobus"]["lemma"])

    def test_ocr_variants_of_dagger(self):
        for variant in ("+ accusabilis  a.  liable.", "t accusabilis  a.  liable."):
            with self.subTest(line=variant):
                es = latin_ocr.parse(variant)
                self.assertEqual(len(es), 1, f"OCR 变体 {variant!r} 必须切出词条而非漏检")
                self.assertEqual(es[0]["lemma"], "accusabilis")
                self.assertEqual(es[0]["doubtful"], 1)

    def test_star_variant_with_space(self):
        es = latin_ocr.parse("* adprobus  a.  approved.")
        self.assertEqual(es[0]["reconstructed"], 1)
        self.assertEqual(es[0]["lemma"], "adprobus")

    def test_boundary_risk_first_line(self):
        text = "and the rest of the previous entry's body continues here.\n\namō  v.  to love."
        es = latin_ocr.parse(text)
        self.assertEqual(len(es), 2)
        self.assertEqual(es[0]["lemma"], "")
        self.assertTrue(es[0]["page_boundary_risk"])
        self.assertEqual(es[1]["lemma"], "amō")
        self.assertFalse(es[1]["page_boundary_risk"])

    def test_decorative_lines_skipped(self):
        text = "| ABBR | expansion |\n|---|---|\n---\n## § 3\namō  v.  to love."
        es = latin_ocr.parse(text)
        self.assertEqual(len(es), 1)
        self.assertNotIn("|", es[0]["body"])

    def test_unknown_pos_label_does_not_fake_head(self):
        # 表外标号（qq.）不再靠位置猜词头：真件里 POS 是词头判定信号，猜 = 误切。
        # 后果按方案 7.4 的降级行为——并入上一条，内容不丢（pos_source 恒 'table'）。
        es = latin_ocr.parse("amō  v.  to love.\nquoddam  qq.  gloss with unknown label.")
        self.assertEqual(len(es), 1)
        self.assertEqual(es[0]["lemma"], "amō")
        self.assertIn("unknown label", es[0]["body"])

    def test_loc_label_from_table(self):
        es = latin_ocr.parse("quoad  loc.  as far as, until.")
        self.assertEqual(es[0]["pos"], "loc.")
        self.assertEqual(es[0]["pos_source"], "table")

    def test_star_forms_attached_and_spaced(self):
        for form in ("*adprobus  a.  approved.", "* adprobus  a.  approved."):
            with self.subTest(form=form):
                es = latin_ocr.parse(form)
                self.assertEqual(len(es), 1, form)
                self.assertEqual(es[0]["lemma"], "adprobus")
                self.assertEqual(es[0]["reconstructed"], 1)

    def test_symbol_lines_are_not_noise(self):
        # 真件：`# § 3` 是装饰（剥掉 # 后没有字母）丢掉；`# e (contempt).` 是义项
        # 标签（OXR 常把它识别成标题），必须留成上一条的正文。
        text = "# § 3\namō  v.  to love.\n# e (contempt). ah fulica AFRAN. com. 264."
        es = latin_ocr.parse(text)
        self.assertEqual(len(es), 1)
        self.assertIn("e (contempt).", es[0]["body"])
        self.assertNotIn("§ 3", es[0]["body"])


# ── 永久真件夹具（P3 第 0 步 / 验收 31）─────────────────────────────────────


class RealFixtureTest(unittest.TestCase):
    """仓库里的真实 OXR 产物（tools/testdata/），不依赖临时区与 OXR 额度。"""

    def test_fixture_files_present(self):
        for name in ("pages-0020-0020.md", "front-sigla.md", "front-bib.md"):
            path = os.path.join(TESTDATA, name)
            self.assertTrue(os.path.exists(path), f"真件夹具缺失：{path}")
            self.assertGreater(os.path.getsize(path), 1000, f"{name} 体积异常")

    def test_pages_0020_five_heads(self):
        # 真件正文页：5 个词头、零误切。这是 anti-退化基线——P3 的所有解析器
        # 改动（大小写敏感、引文否决、fold 加 NFKC）都不许让这条退化。
        with open(os.path.join(TESTDATA, "pages-0020-0020.md"), encoding="utf-8") as fh:
            es = latin_ocr.parse(fh.read())
        self.assertEqual([e["lemma"] for e in es], ["A1", "ā2", "-à1", "-a2", "ab"])
        by = {e["lemma"]: e for e in es}
        self.assertEqual(by["ā2"]["pos"], "interj.")
        self.assertEqual(by["ab"]["pos"], "prep.")
        self.assertEqual(by["-à1"]["pos"], "m.")
        self.assertEqual(by["-a2"]["pos"], "advl.")
        self.assertEqual(by["A1"]["pos"], "a.")
        self.assertGreater(len(by["ab"]["body"]), 10000, "ab 是全书最长词条之一，正文不许被截断")

    def test_front_sigla_four_column_table(self):
        # 四栏 GENERAL ABBREVIATIONS：真件跑出 264 条，pos/ref 都有
        import ingest

        with open(os.path.join(TESTDATA, "front-sigla.md"), encoding="utf-8") as fh:
            rows = ingest.parse_abbreviations(fh.read())
        self.assertGreater(len(rows), 200, "通用缩略语表应有数百条")
        by = {r["abbr"]: r for r in rows}
        self.assertEqual(by["interj."]["expansion"], "interjection")
        self.assertEqual(by["prep."]["expansion"], "preposition")
        self.assertIn(by["interj."]["kind"], ("pos", "ref"))

    def test_front_bib_five_column_table(self):
        # 五栏书目表：作者级 + 两级复合键
        import ingest

        with open(os.path.join(TESTDATA, "front-bib.md"), encoding="utf-8") as fh:
            rows = ingest.parse_abbreviations(fh.read())
        by = {r["abbr"]: r for r in rows}
        self.assertGreater(len(rows), 500, "书目表应有上千条 siglum")
        self.assertEqual(by["CIC."]["expansion"], "M. Tullius Cicero")
        self.assertIn("Academica", by["CIC. Ac."]["expansion"], "两级复合键")
        self.assertEqual(by["CIL"]["expansion"], "Corpus Inscriptionum Latinarum")


# ── 真件回归：OLD 正文页（前言之后的 p.20，A¹…ab 段）────────────────────────
#
# 摘自 test.md（原件 p.20：OXR 版面转换 + 人对照扫描图修正）。真件词头 5 个：
# A1 / ā2 / -a1 / -ā2 / ab。这组的价值是它包含 fake 样本里没有的真实形态：
# 无词性的字母名条目、同形号、后缀条目、逗号并列的多形态词头（ab, abs, ā），
# 以及大量以 `-` / `▶` 起始、绝不能被切成词条的引文行。

REAL_OLD_PAGE = """A1, a. The first letter of the Latin alphabet, representing both long and short vowels; it was also doubled to indicate the long vowel.

▶ 'rabonem'? quam esse dicam hanc beluam? Pl. Truc. 690; A primum est, hinc incipiam LUCIL. 351.

b the regular abbreviation of the praenomen Aulus.

▶ L. PISONE A. GABINIO COS CIL 1.756.2.

ā2, āh interj. [cf. Gk aí, etc.] An interjection expr. any of various feelings, e.g.:

a (distress, regret, pity).

▶ a! ne fle PL. Mil. 1324; ah! cepisti me PAC. trag. 353.

-a1 m. suff. Formed from vbl. bases to denote agent (scriba), usu. in comps. (aduena).

-ā2 advl. suff. OL -ād (in origin abl. of f. adjs.); forms advs. which are also used as preps.

ab, abs, ā prep. Also aps, af. [cf. Gk ἀπό, Skt ápa, Eng. of] CONST.: w. abl., also w. acc. (irreg.) CIL 4.2155.

A Motion away, Distance, Separation.

1 (after vbs., etc., of motion) From, away from, off.
- caput a ceruice reuulsum ENN. Ann. 472; aps te abire PL. Mil. 974; a caus a ad causam ire CIC. de Orat. 2.101.

b (after words implying motion).

▶ ab Suessa nuntiatum est LIV. 32.1.10; credo .. te esse ab illo PL. Cur. 452.
"""


class RealOldPageTest(unittest.TestCase):
    def test_five_real_heads_no_false_cuts(self):
        es = latin_ocr.parse(REAL_OLD_PAGE)
        self.assertEqual([e["lemma"] for e in es], ["A1", "ā2", "-a1", "-ā2", "ab"],
                         "真件 p.20：恰好 5 个词头、顺序与原件一致，引文行不得误切")

    def test_pos_and_homograph_details(self):
        es = latin_ocr.parse(REAL_OLD_PAGE)
        by = {e["lemma"]: e for e in es}
        self.assertEqual(by["ā2"]["pos"], "interj.")
        self.assertEqual(by["ab"]["pos"], "prep.")
        self.assertEqual(by["-a1"]["pos"], "m.")
        self.assertEqual(by["-ā2"]["pos"], "advl.")
        self.assertTrue(by["ab"]["body"].startswith("abs, ā"),
                        "多形态词头：首形作 lemma（可查键），其余形态留在正文里")
        self.assertIn("Skt ápa", by["ab"]["body"])

    def test_sense_labels_and_citations_kept_in_body(self):
        ab = {e["lemma"]: e for e in latin_ocr.parse(REAL_OLD_PAGE)}["ab"]["body"]
        for probe in ("A Motion away", "1 (after vbs.", "b (after words implying motion)",
                      "caput a ceruice reuulsum", "ab Suessa nuntiatum est"):
            self.assertIn(probe, ab, f"义项与引文必须留在 ab 的正文里：{probe!r}")
        self.assertEqual(sum(1 for e in latin_ocr.parse(REAL_OLD_PAGE) if e["page_boundary_risk"]), 0)


    def test_latex_markup_headword(self):
        # 真件原始 OCR（p.20 第 37 行原样）：`-ā²` 被排成 LaTeX，连字符与词头
        # 拆开、音符变成 \tilde——不处理就整条漏检（第一次真件跑就是这样丢的）。
        raw = r"""-à¹ m. suff. Formed from vbl. bases to denote agent (scriba).

- $\tilde{a}^{2}$ advl. suff. OL -ād (in origin abl. of f. adjs.); forms advs.

ab, abs, ā prep. Also aps, af. [cf. Gk ἀπό] CONST.: w. abl.
"""
        es = latin_ocr.parse(raw)
        # 原件词头是 -ā¹/-ā²；原始 OCR 一个读成长音符 à、一个读成 LaTeX \tilde。
        # 两个都算识别成功——查询键看 fold，两条都归一到 -a1/-a2。
        self.assertEqual([fold.fold(e["lemma"]) for e in es], ["-a1", "-a2", "ab"],
                         "LaTeX 词头必须降级并识别（\tilde/\bar 的音符 fold 本来就要去掉）")
        self.assertEqual(es[1]["pos"], "advl.")
        self.assertEqual(fold.fold(es[1]["lemma"]), fold.fold("-ā2"),
                         "降级后的键与修正版 md 的同一条词头一致")

    def test_citation_dash_not_split_into_entry(self):
        # 上面那条规则的代价必须由这条测试压住：以 `- ` 起始的引文行不能被
        # 「拆开的连字符」规则误认成词条（窗口内没有带点词性标号）。
        raw = "amō  v.  to love.\n- caput a ceruice reuulsum ENN. Ann. 472; aps te abire PL. Mil. 974;\n"
        es = latin_ocr.parse(raw)
        self.assertEqual([e["lemma"] for e in es], ["amō"])
        self.assertIn("caput a ceruice", es[0]["body"])


# ── P3-E：词性大小写敏感 + 引文否决（验收 16、18、19）──────────────────────

# 10 条标准引文行（方案 7.4「真件复核」给的实测样本）。用 lower() 比较词性时
# 它们 10/10 被切成假词头：Ov. M. → lemma 'Ov' pos 'M.'（Metamorphoses 撞
# masculine），Verg. A. → 'Verg'/'A.'（Aeneis 撞 adjective）……
CITATION_LINES = """Ov. M. 1.5
Verg. A. 4.10
Tac. A. 1.1
Ov. Tr. 1.2.3
Ov. A. 1.1
Cic. Part. Or. 1.1
Liv. praef. 1
Plin. HN praef. 3
ACC. poet. fr. 1
AED. Poet. 1
"""


class PosCaseSensitivityTest(unittest.TestCase):
    def test_citations_do_not_become_entries(self):
        # 验收 16 的正解：**有 siglum 表时** 10 条引文一条都不产生词条。
        # 真实流程里这是常态——书目表（p.1–13）先入库，正文页才有 siglum 表可查。
        with open(os.path.join(TESTDATA, "front-bib.md"), encoding="utf-8") as fh:
            sigla = {latin_ocr._siglum_key(r["abbr"]) for r in ingest.parse_abbreviations(fh.read(), "biblio")}
        stats = {}
        es = latin_ocr.parse(CITATION_LINES, stats=stats, sigla=sigla)
        real = [e for e in es if e["lemma"]]
        self.assertEqual(real, [], f"引文行不得产生词条，实际：{[e['lemma'] for e in real]}")
        self.assertTrue(stats["siglum_veto"], "这次运行确实启用了引文否决")

    def test_first_interval_degradation_is_documented(self):
        # 诚实记录**第一个区间**（siglum 表还空）的退化程度：大小写敏感已经
        # 解决 7/10（M. A. Tr. Part. 都因大写被挡），剩下 3 条是「作品缩写恰好
        # 是小写形态」——Liv. praef. / Plin. praef. / ACC. poet.。这三条要等
        # 书目表入库后由引文否决挡住（见上一条）。这不是漏测，是已知边界。
        es = [e for e in latin_ocr.parse(CITATION_LINES) if e["lemma"]]
        self.assertEqual(sorted(e["lemma"] for e in es), ["ACC", "Liv", "Plin"],
                         "第一个区间的残留误切必须与记录一致；numbers 变了说明规则漂移")

    def test_lowercase_pos_still_works(self):
        # 大小写敏感不能误伤小写词性标号（验收 18）
        for line, lemma, pos in (
            ("ab, abs, a prep. Also aps.", "ab", "prep."),
            ("-a1 m. suff. Formed from vbl. bases.", "-a1", "m."),
            ("ā2, āh interj. An interjection.", "ā2", "interj."),
            ("ā2, āh a. 形容词义", "ā2", "a."),
        ):
            with self.subTest(line=line):
                es = latin_ocr.parse(line)
                self.assertEqual(len(es), 1, line)
                self.assertEqual(es[0]["lemma"], lemma)
                self.assertEqual(es[0]["pos"], pos)

    def test_real_page_still_five_heads(self):
        # 验收 17：真件不退化
        with open(os.path.join(TESTDATA, "pages-0020-0020.md"), encoding="utf-8") as fh:
            es = latin_ocr.parse(fh.read())
        self.assertEqual([e["lemma"] for e in es], ["A1", "ā2", "-à1", "-a2", "ab"])

    def test_fp_suspect_zero_vs_not_measured(self):
        # 验收 19：「测出来是 0」与「没测」必须能区分
        with open(os.path.join(TESTDATA, "pages-0020-0020.md"), encoding="utf-8") as fh:
            md = fh.read()
        no_sigla = latin_ocr.parse(md)
        self.assertEqual(_count_fp(no_sigla, None), None, "表还空 → NULL（没测过）")
        sigla = {"ov", "verg", "tac", "cic", "caes", "pl", "sal", "enn", "liv"}
        self.assertEqual(_count_fp(no_sigla, sigla), 0, "真件页不撞 siglum → 0（测了，没有）")

        # 构造误切样本：lemma 正好撞上 siglum
        fake = [{"lemma": "Ov"}, {"lemma": "accusatrix"}, {"lemma": "VERG"}]
        self.assertEqual(_count_fp(fake, sigla), 2)


def _count_fp(entries, sigla):
    return ingest.count_fp_suspect(entries, sigla)


# ── P3-E：fold 版本与 kind（验收 12、13、20）────────────────────────────────

class FoldAndKindTest(unittest.TestCase):
    def test_fold_vectors_new_entries(self):
        # 验收 12：新向量两侧都过
        with open(os.path.join(REPO_ROOT, "test", "fixtures", "fold-vectors.json"), encoding="utf-8") as fh:
            vectors = json.load(fh)
        by_in = {v["in"]: v["out"] for v in vectors}
        self.assertEqual(fold.fold("ｖｉｔａ"), "uita")
        self.assertEqual(fold.fold("Straße"), "strasse")
        self.assertEqual(fold.fold("Æneas"), "aeneas")
        self.assertIn("ｖｉｔａ", by_in, "全角向量必须在共享文件里")
        self.assertIn("Straße", by_in, "ß 向量必须在共享文件里")

    def test_fold_version_matches_constant(self):
        import ingest

        self.assertEqual(fold.fold_version(), 2)
        self.assertEqual(ingest.SCHEMA_VERSION, 2)

    def test_kind_by_region(self):
        # 验收 20：书目区域一律 ref；通用表里只有真形态标号才是 pos
        with open(os.path.join(TESTDATA, "front-bib.md"), encoding="utf-8") as fh:
            biblio = ingest.parse_abbreviations(fh.read(), region="biblio")
        by = {r["abbr"]: r for r in biblio}
        self.assertTrue(all(r["kind"] == "ref" for r in biblio), "书目表不得产生 kind=pos")
        for probe in ("ACC.", "Tr.", "V.", "Dat.", "N."):
            self.assertIn(probe, by, f"书目表里应有 {probe}")
            self.assertEqual(by[probe]["kind"], "ref", f"{probe} 是书目 siglum，不是词性")

        with open(os.path.join(TESTDATA, "front-sigla.md"), encoding="utf-8") as fh:
            general = ingest.parse_abbreviations(fh.read(), region="general")
        g = {r["abbr"]: r for r in general}
        for probe in ("a.", "abl.", "m.", "f.", "n.", "prep."):
            self.assertEqual(g[probe]["kind"], "pos", f"{probe} 是真形态标号")
        self.assertEqual(g["Gk"]["kind"], "ref", "Gk 是阅读 aid，不是词性")


# ── P3.1-R2：kind 大小写敏感 + 成品库不翻回 WAL（验收 3、4）────────────────


class KindCaseSensitivityTest(unittest.TestCase):
    def test_general_region_is_case_sensitive(self):
        # General Abbreviations 里与形态标号同形的大写缩写（Ger.=German 撞
        # ger.=gerund）不得标 pos——OLD 的形态标号印小写斜体（E3 同一理由）
        md = "| Ger. | German |\n| ger. | gerund |\n| a. | adjective |\n| A. | 前言标记 |\n"
        rows = {r["abbr"]: r for r in ingest.parse_abbreviations(md, region="general")}
        self.assertEqual(rows["Ger."]["kind"], "ref", "大写 Ger. 是 German，不是 gerund")
        self.assertEqual(rows["ger."]["kind"], "pos", "小写 ger. 是真形态标号")
        self.assertEqual(rows["a."]["kind"], "pos")
        self.assertEqual(rows["A."]["kind"], "ref", "大写 A. 不是形容词标号")

    def test_biblio_region_stays_ref(self):
        md = "| Tr. | Tristia |\n"
        rows = ingest.parse_abbreviations(md, region="biblio")
        self.assertEqual(rows[0]["kind"], "ref")


class ReadyDbStaysDeleteTest(unittest.TestCase):
    """验收 4：成品库（ready）任何子命令跑完必须 journal_mode=delete、无 -wal/-shm。"""

    def test_abbrev_on_ready_db_does_not_flip_wal(self):
        # 直接搭：commit → mark-ready → abbrev → 断言仍是 delete
        import uuid

        base = None
        for candidate in (os.path.join(REPO_ROOT, ".tmp"), os.environ.get("TMP"), tempfile.gettempdir()):
            if not candidate:
                continue
            try:
                os.makedirs(candidate, exist_ok=True)
                probe = os.path.join(candidate, f".probe-{uuid.uuid4().hex[:8]}")
                os.makedirs(probe)
                os.rmdir(probe)
                base = candidate
                break
            except OSError:
                continue
        assert base, "找不到可写临时目录"
        self.tmp = os.path.join(base, "kb-ready-" + uuid.uuid4().hex[:8])
        os.makedirs(self.tmp)
        try:
            self.vault = os.path.join(self.tmp, "vault")
            self.build = os.path.join(self.tmp, "build", "old")
            os.makedirs(self.vault)
            os.makedirs(self.build)
            self.src_pdf = os.path.join(self.tmp, "old.pdf")
            make_pdf(self.src_pdf, 25)

            md = os.path.join(self.build, "pages-0021-0025.md")
            with open(md, "w", encoding="utf-8") as fh:
                fh.write("amō  āre  v.t.  to love.\ndīcō  ere  v.i.  to say.\n")
            self.assertEqual(run_cli(
                ["commit", "--dict", "old", "--md", md, "--pages", "21-25", "--build-dir", self.build],
                self.vault).returncode, 0)
            self.assertEqual(run_cli(
                ["mark-ready", "--dict", "old", "--build-dir", self.build], self.vault).returncode, 0)

            db = os.path.join(self.vault, ".kb", "dictionaries.db")
            conn = sqlite3.connect(db)
            self.assertEqual(conn.execute("PRAGMA journal_mode").fetchone()[0], "delete", "mark-ready 后应是 delete")
            conn.close()

            # 成品库上跑 abbrev（重跑真件缩略语表，走 INSERT OR REPLACE）
            front = os.path.join(self.build, "front.md")
            with open(front, "w", encoding="utf-8") as fh:
                fh.write("| CIC. | M. Tullius Cicero |\n")
            r = run_cli(["abbrev", "--dict", "old", "--region", "general", "--md", front,
                         "--build-dir", self.build], self.vault)
            self.assertEqual(r.returncode, 0, r.stderr)

            conn = sqlite3.connect(db)
            mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
            n = conn.execute("SELECT count(*) FROM abbreviations WHERE dict_id='old'").fetchone()[0]
            conn.close()
            self.assertEqual(mode, "delete", "R2 修法 A：已存在的库保留当前 journal_mode，不得翻回 WAL")
            siblings = [f for f in os.listdir(os.path.dirname(db)) if f.startswith("dictionaries.db-")]
            self.assertEqual(siblings, [], f"不得留 -wal/-shm：{siblings}")
            self.assertEqual(n, 1)
        finally:
            import shutil

            shutil.rmtree(self.tmp, ignore_errors=True)


# ── latin_html（验收 17 的 HTML 半边）────────────────────────────────────────

HTML_SAMPLE = """
<div>
<article class="entry" data-lemma="amō"><span class="pos">v.</span>
<span class="body">To love. <i>▶</i> amo te.</span></article>
<article class="entry"><span class="lemma">†accusabilis</span>
<span class="pos">a.</span><span class="body">Liable to accusation.</span></article>
<article class="entry" data-lemma="aeternus"><span class="pos">a.</span>
<span class="body">Eternal, everlasting. Cf. <b>aevum</b>.</span></article>
</div>
"""


class LatinHtmlTest(unittest.TestCase):
    def test_three_entries(self):
        es = latin_html.parse(HTML_SAMPLE)
        self.assertEqual(len(es), 3)
        self.assertEqual(es[0]["lemma"], "amō")
        self.assertEqual(es[0]["pos"], "v.")
        self.assertEqual(es[0]["pos_source"], "table")
        self.assertIn("To love.", es[0]["body"])
        self.assertIn("amo te.", es[0]["body"])
        self.assertNotIn("span", es[0]["body"])

    def test_dagger_from_head_region(self):
        es = latin_html.parse(HTML_SAMPLE)
        self.assertEqual(es[1]["lemma"], "accusabilis")
        self.assertEqual(es[1]["doubtful"], 1)
        self.assertEqual(es[2]["doubtful"], 0)


# ── CLI：区间校验 / 切片 / 入库 / 幂等 / 前置材料 ────────────────────────────

class IngestCliTest(unittest.TestCase):
    def setUp(self):
        # 不用 tempfile.mkdtemp：它给目录上一把受限 DACL，沙箱令牌连自己都
        # 进不去（实测 WinError 5 + icacls 拒读）。普通 makedirs 继承父目录
        # ACL，node 探针与 Python 探针都验证可建可删。
        #
        # base 的选择顺序（P3.1 补）：**仓库内 .tmp 优先**——沙箱 runner 会把
        # 自己的平台临时目录注入 TMP 且覆盖外部设置，那个目录的 ACL 不一定
        # 放行受限令牌（实测 makedirs WinError 5），跨会话也不稳定。仓库内
        # 目录归仓库管，探测可写才用；探测失败回落 TMP / 系统默认。
        import uuid

        repo_tmp = os.path.join(REPO_ROOT, ".tmp")
        base = None
        for candidate in (repo_tmp, os.environ.get("TMP"), os.environ.get("TEMP"), tempfile.gettempdir()):
            if not candidate:
                continue
            try:
                os.makedirs(candidate, exist_ok=True)
                probe = os.path.join(candidate, f".probe-{uuid.uuid4().hex[:8]}")
                os.makedirs(probe)
                os.rmdir(probe)
                base = candidate
                break
            except OSError:
                continue
        if base is None:
            self.fail("找不到可写的临时目录（仓库 .tmp / TMP / TEMP / gettempdir() 全部不可写）")

        self.tmp = os.path.join(base, "kb-ingest-" + uuid.uuid4().hex[:8])
        os.makedirs(self.tmp)
        self.vault = os.path.join(self.tmp, "vault")
        os.makedirs(self.vault)
        self.build = os.path.join(self.tmp, "build", "old")
        self.src_pdf = os.path.join(self.tmp, "old.pdf")
        make_pdf(self.src_pdf, 25)

    def tearDown(self):
        import shutil

        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_range_validation(self):
        # 验收 18：超 20 页 / 起点 0 / 起点大于终点 / 超总页数
        for pages, expect in (("1-25", "拆"), ("0-5", "≥ 1"), ("30-20", "大于终点"), ("21-30", "总页数")):
            with self.subTest(pages=pages):
                r = run_cli(["slice", "--dict", "old", "--source", self.src_pdf, "--pages", pages,
                             "--build-dir", self.build], self.vault)
                self.assertNotEqual(r.returncode, 0, f"--pages {pages} 应被拒绝")
                self.assertIn(expect, r.stderr)
        r = run_cli(["slice", "--dict", "old", "--source", self.src_pdf, "--pages", "abc",
                     "--build-dir", self.build], self.vault)
        self.assertNotEqual(r.returncode, 0)

    def test_slice_pages_and_convert_contract(self):
        # 验收 19 + 21：切片正确 + 转换调用点契约（prefer/max_chars 由 slice 打印）
        r = run_cli(["slice", "--dict", "old", "--source", self.src_pdf, "--pages", "21-25",
                     "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("prefer: 'layout'", r.stdout, "转换参数必须是 prefer='layout'")
        self.assertIn("max_chars: 0", r.stdout, "转换参数必须是 max_chars=0（默认会截断）")
        out_pdf = os.path.join(self.build, "pages-0021-0025.pdf")
        self.assertTrue(os.path.exists(out_pdf))
        from pypdf import PdfReader

        self.assertEqual(len(PdfReader(out_pdf).pages), 5)
        # manifest 记录原件事实
        with open(os.path.join(self.build, "manifest.json"), encoding="utf-8") as fh:
            man = json.load(fh)
        self.assertEqual(man["total_pages"], 25)
        self.assertEqual(os.path.normpath(man["source"]), os.path.normpath(self.src_pdf))
        self.assertEqual(len(man["sha256"]), 64)

    COMMIT_MD = """accūsātrīx  ~īcīs  f.  [Accvšō + -trāx]  A female accuser or prosecutor.
continuation prose.

amō  āre  v.t.  to love.
dīcō  ere  v.i.  (old) to say.
†accusabilis  a.  liable to accusation.
Æneas  m.  son of Venus and Anchises.
"""

    def _commit(self, md_text, extra=None):
        md = os.path.join(self.build, "pages-0021-0025.md")
        os.makedirs(self.build, exist_ok=True)
        with open(md, "w", encoding="utf-8") as fh:
            fh.write(md_text)
        args = ["commit", "--dict", "old", "--md", md, "--pages", "21-25",
                "--build-dir", self.build, "--name", "Oxford Latin Dictionary",
                "--coverage", "≤ 200 A.D."] + (extra or [])
        return run_cli(args, self.vault)

    def test_commit_and_page_numbers(self):
        # 验收 19：page_from=21 / page_to=25；lemma_fold 与 Node 同算法
        r = self._commit(self.COMMIT_MD)
        self.assertEqual(r.returncode, 0, r.stderr)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT lemma, lemma_fold, pos, body, source, page_from, page_to, quality, doubtful, reconstructed"
            " FROM entries ORDER BY id"
        ).fetchall()
        conn.close()
        self.assertEqual(len(rows), 5)
        self.assertEqual(rows[0][5], 21)
        self.assertEqual(rows[0][6], 25)
        for lemma, lemma_fold, *_ in rows:
            self.assertEqual(lemma_fold, fold.fold(lemma))
        self.assertEqual(rows[1][2], "v.t.")
        self.assertEqual(rows[3][0], "accusabilis", "† 从 lemma 剥掉（CLI 全链路）")
        self.assertEqual(rows[3][8], 1, "doubtful 落库")
        self.assertEqual(rows[4][0], "Æneas")
        self.assertEqual(rows[4][1], "aeneas")
        # quality 随 parser：ocr → medium（设计 4）
        self.assertTrue(all(r[7] == "medium" for r in rows))
        # FTS 与 chunks 行存在
        conn = sqlite3.connect(db)
        n_fts = conn.execute("SELECT count(*) FROM entries_fts").fetchone()[0]
        conn.close()
        self.assertEqual(n_fts, 5)

    def test_idempotent_rerun(self):
        # 验收 20：同一区间跑两次条目数不变；换成 3 条的 md → 删旧插新
        self._commit(self.COMMIT_MD)
        self._commit(self.COMMIT_MD)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        self.assertEqual(conn.execute("SELECT count(*) FROM entries").fetchone()[0], 5)
        conn.close()
        shorter = "amō  āre  v.t.  to love.\ndīcō  ere  v.i.  to say.\nferō  ferre  v.t.  to carry.\n"
        r = self._commit(shorter)
        self.assertEqual(r.returncode, 0, r.stderr)
        conn = sqlite3.connect(db)
        self.assertEqual(conn.execute("SELECT count(*) FROM entries").fetchone()[0], 3, "区间重叠时后跑的覆盖")
        conn.close()

    def test_dry_run_writes_nothing(self):
        r = self._commit(self.COMMIT_MD, extra=["--dry-run"])
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("5 条", r.stdout)
        self.assertFalse(os.path.exists(os.path.join(self.vault, ".kb", "dictionaries.db")),
                         "--dry-run 不写库")

    def test_skip_pages_and_abbreviations(self):
        # 验收 26 + 27：前置材料切出 front 切片，只进 abbreviations 不进 entries
        r = run_cli(["slice", "--dict", "old", "--source", self.src_pdf, "--pages", "1-6",
                     "--skip-pages", "1-3", "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertTrue(os.path.exists(os.path.join(self.build, "pages-0001-0003.front.pdf")))
        self.assertTrue(os.path.exists(os.path.join(self.build, "pages-0004-0006.pdf")))

        front_md = os.path.join(self.build, "pages-0001-0003.front.md")
        with open(front_md, "w", encoding="utf-8") as fh:
            fh.write(
                "# CONSENTED ABBREVIATIONS\n\n"
                "| v. | verb |\n"
                "|---|---|\n"
                "| Cic. | Cicero |\n"
                "| Dig. | Digesta |\n"
                "AB.    author of a work\n"
            )
        r = run_cli(["abbrev", "--dict", "old", "--md", front_md, "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        rows = conn.execute("SELECT abbr, expansion, kind FROM abbreviations WHERE dict_id='old'").fetchall()
        conn.close()
        by_abbr = {a: (e, k) for a, e, k in rows}
        self.assertEqual(by_abbr["Cic."], ("Cicero", "ref"))
        self.assertEqual(by_abbr["Dig."], ("Digesta", "ref"))
        self.assertEqual(by_abbr["v."], ("verb", "pos"), "词性表里的缩写标 pos")
        self.assertEqual(by_abbr["AB."], ("author of a work", "ref"), "两栏文本行也解析")
        # 前置材料的行不产生 entries（该词典还没有任何 commit）
        conn = sqlite3.connect(db)
        n = conn.execute("SELECT count(*) FROM entries WHERE source='old'").fetchone()[0]
        conn.close()
        self.assertEqual(n, 0)

    def test_abbrev_is_additive_across_ranges(self):
        # 真件规则：OLD 的缩略语散在多处前置页，每区间一次 abbrev——整表重建会把
        # 前一次清光（第一版实测踩过）。两次不同输入 → 都留着；重跑同一份 → 不翻倍。
        os.makedirs(self.build, exist_ok=True)
        a = os.path.join(self.build, "front-a.md")
        b = os.path.join(self.build, "front-b.md")
        with open(a, "w", encoding="utf-8") as fh:
            fh.write("| CIC. | M. Tullius Cicero |\n| OV. | P. Ouidius Naso |\n")
        with open(b, "w", encoding="utf-8") as fh:
            fh.write("| interj. | interjection |\n| prep. | preposition |\n")
        for md in (a, b):
            r = run_cli(["abbrev", "--dict", "old", "--md", md, "--build-dir", self.build], self.vault)
            self.assertEqual(r.returncode, 0, r.stderr)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        abbrs = {r[0] for r in conn.execute("SELECT abbr FROM abbreviations WHERE dict_id='old'")}
        conn.close()
        self.assertEqual(abbrs, {"CIC.", "OV.", "interj.", "prep."}, "两次运行都要留着（累加式）")
        r = run_cli(["abbrev", "--dict", "old", "--md", a, "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        conn = sqlite3.connect(db)
        self.assertEqual(conn.execute("SELECT count(*) FROM abbreviations").fetchone()[0], 4, "重跑不翻倍")
        conn.close()

    def test_ranges_is_commit_point_and_idempotent(self):
        # 验收 14/15：ranges 是 commit point；同区间跑两次只有一行、entries 不翻倍
        self._commit(self.COMMIT_MD)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        rows = conn.execute(
            "SELECT page_from, page_to, entries, merged, fp_suspect, boundary_risk,"
            " parser_version, fold_version FROM ranges"
        ).fetchall()
        conn.close()
        self.assertEqual(len(rows), 1, "一个区间一行")
        f, t, n, merged, fp, br, pv, fv = rows[0]
        self.assertEqual((f, t, n), (21, 25, 5))
        self.assertIsInstance(merged, int, "merged 是漏检下界，必须是数")
        self.assertIsNone(fp, "siglum 表还空 → fp_suspect = NULL（没测过，不是 0）")
        self.assertEqual(br, 0)
        self.assertEqual(pv, ingest.PARSER_VERSION)
        self.assertEqual(fv, fold.fold_version())

        # 重跑：ranges 仍一行、entries 不变
        self._commit(self.COMMIT_MD)
        conn = sqlite3.connect(db)
        self.assertEqual(conn.execute("SELECT count(*) FROM ranges").fetchone()[0], 1)
        self.assertEqual(conn.execute("SELECT count(*) FROM entries").fetchone()[0], 5)
        conn.close()

    def test_ranges_rolls_back_with_entries(self):
        # 验收 14：插入中途失败 → 事务回滚、ranges 无此行、旧词条还在
        self._commit(self.COMMIT_MD)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        before = conn.execute("SELECT count(*) FROM entries").fetchone()[0]
        # 造一个会让插入失败的条件：在 entries（普通表）上加触发器抛错。
        # 注意不能加在 entries_fts 上——FTS5 是虚拟表，SQLite 不允许在虚拟表上建触发器。
        conn.execute(
            "CREATE TRIGGER boom BEFORE INSERT ON entries"
            " WHEN NEW.lemma = 'ferō'"
            " BEGIN SELECT RAISE(ABORT, '模拟中途失败'); END"
        )
        conn.commit()
        conn.close()

        shorter = "amō  āre  v.t.  to love.\ndīcō  ere  v.i.  to say.\nferō  ferre  v.t.  to carry.\n"
        r = self._commit(shorter)
        self.assertNotEqual(r.returncode, 0, "插入失败必须导致非零退出")

        conn = sqlite3.connect(db)
        after = conn.execute("SELECT count(*) FROM entries").fetchone()[0]
        ranges = conn.execute("SELECT page_from, page_to FROM ranges").fetchall()
        conn.close()
        self.assertEqual(after, before, "回滚后旧词条还在")
        self.assertEqual(ranges, [(21, 25)], "ranges 里没有新写入的痕迹（本来就只有那一段）")

    def test_meta_written_with_fold_version(self):
        # E2：meta 至少写 schema/fold/parser/created_at
        self._commit(self.COMMIT_MD)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        meta = {r[0]: r[1] for r in conn.execute("SELECT key, value FROM meta").fetchall()}
        conn.close()
        self.assertEqual(meta["schema_version"], str(ingest.SCHEMA_VERSION))
        self.assertEqual(meta["fold_version"], str(fold.fold_version()))
        self.assertEqual(meta["parser_version"], ingest.PARSER_VERSION)
        self.assertTrue(meta["created_at"])

    def test_mark_ready_switches_off_wal(self):
        # 验收 22：mark-ready 之后 journal_mode=delete，目录里没有 -wal / -shm
        self._commit(self.COMMIT_MD)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        r = run_cli(["mark-ready", "--dict", "old", "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("journal_mode=delete", r.stdout)
        conn = sqlite3.connect(db)
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        conn.close()
        self.assertEqual(mode, "delete")
        siblings = [f for f in os.listdir(os.path.dirname(db)) if f.startswith("dictionaries.db-")]
        self.assertEqual(siblings, [], f"成品库不该留 -wal/-shm，实际：{siblings}")

    def test_ingesting_db_stays_wal(self):
        # 验收 22 的反面：录入期（还没 mark-ready）仍是 WAL，Node 侧能并发读
        self._commit(self.COMMIT_MD)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
        status = conn.execute("SELECT status FROM dictionaries WHERE id='old'").fetchone()[0]
        conn.close()
        self.assertEqual(mode, "wal")
        self.assertEqual(status, "ingesting")

    def test_mark_ready(self):
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        # 0 词条不能 ready（否则查询把「未录到」误判成「词典没有」，设计 5）
        r = run_cli(["mark-ready", "--dict", "old", "--build-dir", self.build], self.vault)
        self.assertNotEqual(r.returncode, 0)
        self._commit(self.COMMIT_MD)
        conn = sqlite3.connect(db)
        self.assertEqual(conn.execute("SELECT status FROM dictionaries WHERE id='old'").fetchone()[0], "ingesting")
        conn.close()
        r = run_cli(["mark-ready", "--dict", "old", "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        conn = sqlite3.connect(db)
        self.assertEqual(conn.execute("SELECT status FROM dictionaries WHERE id='old'").fetchone()[0], "ready")
        conn.close()

    def test_status_report(self):
        # 先 slice（manifest 记下 total_pages）再 commit，status 才能报「已到末页」
        r0 = run_cli(["slice", "--dict", "old", "--source", self.src_pdf, "--pages", "21-25",
                      "--build-dir", self.build], self.vault)
        self.assertEqual(r0.returncode, 0, r0.stderr)
        self._commit(self.COMMIT_MD)
        r = run_cli(["status", "--dict", "old", "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("21-25", r.stdout)
        self.assertIn("已到末页", r.stdout)
        r2 = run_cli(["status", "--build-dir", self.build], self.vault)
        self.assertEqual(r2.returncode, 0, r2.stderr)
        self.assertIn("old", r2.stdout)

    def test_commit_backfills_metadata_after_abbrev(self):
        # 真件顺序：前置材料先跑 abbrev（以 id 建行）→ 之后 commit 的 --name/--coverage
        # 必须补上，不能静默丢掉（第一版实测 status 显示成「old（old）」）。
        os.makedirs(self.build, exist_ok=True)
        front = os.path.join(self.build, "front.md")
        with open(front, "w", encoding="utf-8") as fh:
            fh.write("| CIC. | M. Tullius Cicero |\n")
        r = run_cli(["abbrev", "--dict", "old", "--md", front, "--build-dir", self.build], self.vault)
        self.assertEqual(r.returncode, 0, r.stderr)
        r2 = self._commit(self.COMMIT_MD)  # 带 --name "Oxford Latin Dictionary" --coverage "≤ 200 A.D."
        self.assertEqual(r2.returncode, 0, r2.stderr)
        db = os.path.join(self.vault, ".kb", "dictionaries.db")
        conn = sqlite3.connect(db)
        name, coverage, q = conn.execute("SELECT name, coverage, quality FROM dictionaries WHERE id='old'").fetchone()
        abbrs = conn.execute("SELECT count(*) FROM abbreviations WHERE dict_id='old'").fetchone()[0]
        conn.close()
        self.assertEqual(name, "Oxford Latin Dictionary")
        self.assertEqual(coverage, "≤ 200 A.D.")
        self.assertEqual(q, "medium", "设计 4：abbrev 先建行时 quality 为 NULL，commit 必须按 parser 补上")
        self.assertEqual(abbrs, 1, "commit 不该动缩略语表")

    def test_verify_graceful(self):
        # B6：--verify 在 pdfplumber 缺失/无粗体信息时不炸、优雅跳过
        os.environ["INGEST_TEST_NO_PDFPLUMBER"] = "1"
        try:
            r = self._commit(self.COMMIT_MD, extra=["--verify"])
            self.assertEqual(r.returncode, 0, r.stderr)
        finally:
            os.environ.pop("INGEST_TEST_NO_PDFPLUMBER", None)

    def test_no_scheduler_no_extra_engines(self):
        # 验收 21/22：没有批调度器，也没有自研转换/OCR 引擎
        with open(INGEST, encoding="utf-8") as fh:
            src = fh.read()
        for banned in ("batch_log", "--only", "--delay", "retry", "import fitz", "pymupdf4llm", "markitdown"):
            self.assertNotIn(banned, src, f"ingest.py 里不应出现 {banned!r}（B0 的刻意不做 / B2 的不造轮子）")
        self.assertIn("'layout'", src)
        self.assertIn("max_chars: 0", src)


if __name__ == "__main__":
    unittest.main(verbosity=2)
