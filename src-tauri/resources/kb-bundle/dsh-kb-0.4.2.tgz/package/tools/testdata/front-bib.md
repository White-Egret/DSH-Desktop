# BIBLIOGRAPHICAL GUIDE

# I AUTHORS AND WORKS

The references given in column 1 are normally the last possible for each work. This will make clear which system of chapter, paragraph, etc., division, or of pagination, is being followed, where two or more exist. Authors used as secondary sources are printed in lower case while square brackets around an author’s name indicate dubious ascription. The full form of post-classical or modern collections, anthologies, etc., is given in the Supplementary List (II) below. The abbreviations for these are usually printed with lower-case initial (e.g. anth., poet., trag.). In the indication of date, Roman numerals refer to centuries.

In the description of Editions used, OCT, T, and L refer to Oxford Classical Texts (Scriptorum Classicorum Bibliotheca Oxoniensis), Bibliotheca Teubneriana, and the Loeb Classical Library respectively. The editions cited are normally those used for the original excerpting of material. Important changes in later editions have been taken into account wherever possible.

| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| ACC. poet. 26 (28) | L. Accius |  | 170-c. 85 BC |  |
| praet. 42 |  |  |  |  |
| trag. 696 |  |  |  |  |
| Act. Triumph. 37 (CIL 1.p.50) |  | Acta Triumphalia |  |  |
| AED. Poet. 2.6 | Valerius Aedituus |  | ii-i BC |  |
| Aetna 646 |  |  | before AD 63 | Poetae Latini Minores Vollmer T 1930 |
| AFRAN. com. 432 | L. Afranius |  | b. c. 150 BC |  |
| AFRIC. dig. 50.16.208 | Sex. Caecilius Africanus |  | ii AD (mid) |  |
| AGEN. agrim. p.51 | Agennius Vrbicus |  | ? ii AD (early) |  |
| ALF. dig. 50.16.203 | P. Alfenus Varus |  | cos. 39 BC |  |
| iur. 1 |  |  |  |  |
| gram. 4 |  |  |  |  |
| AMP. 50.2 | L. Ampelius | Liber Memorialis | ? ii AD | Assmann T 1935 |
| ANDR. com. 8 | L. Liius Andronicus |  | c. 284-204 BC |  |
| poet. 45 |  |  |  |  |
| trag. 41 |  |  |  |  |
| ANNIAN. poet. 3.4 | Annianus |  | ii AD |  |
| ANNIUS orat. 5 | T. Annius Luscus |  | cos. 153 BC |  |
| ANT. Fro. 1.p.126(163N) | Antoninus Pius |  | Emp. AD 138-61 | see Fro. |
| ANT. Att. 10.8a.2 | M. Antonius |  | c. 82-30 BC | see CIC. Att. |
| orat. 13 |  |  |  |  |
| AP. CLAUD. PULCH. gram. 3 | Appius Claudius Pulcher |  | cos. 54 BC |  |
| APP. poet. 2.2 | Appius Claudius Caecus |  | cos. 307, 296 BC |  |
| APRIS. com. 10 | ? Aprissius |  | quoted in Varro |  |
| APUL. Apol. 103 | Apuleius | Apologia | b. c. AD 123 | Helm T 1912 |
| Fl. 23 |  | Florida |  | Helm T 1921 |
| Met. 11.30 |  | Metamorphoses |  | Helm T 1931 |
| Mun. 38 |  | de Mundo |  | Thomas T 1921 |
| Pl. 2.28 |  | de Platone |  | Thomas T 1921 |
| poet. 7 |  |  |  |  |
| Soc. 24 |  | de Deo Socratis |  | Thomas T 1921 |
| ARB. poet. 2 | Arb(r)onius Silo |  | time of Augustus |  |
| ARG. Pl. Truc. 11 |  | Argumentum Plauti, etc. | post-Plautine (variously dated) | see Pl. |
| ARR. hist. 7 | L. Arruntius |  | cos. 22 BC |  |
| ASC. Corn. 72 | Q. Asconius Pedianus | in Cornelianam | 9 BC-AD 76 | Clark OCT 1907 |
| Mil. 49 |  | in Milonianam |  |  |
| Pis. 15 |  | in Pisonianam |  |  |


| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| Sc. 25 |  | in Scaurianam |  |  |
| Tog. 84 |  | in orationem in toga candida |  |  |
| ASEL. hist. 14 | Sempronius Asellio |  | ii-i BC |  |
| AS. GAL. poet. 2 | C. Asinius Gallus |  | cos. 22 BC |  |
| ATBIUS. gram. 14 | L. Ateius Praetextatus |  | i BC |  |
| ATIL. com. 4 | Atilius |  | ii BC |  |
| ATTA com. 24 | T. Quinctius Atta |  | d. 77 BC |  |
| poet. 1 |  |  |  |  |
| AUFUST. gram. 3 | Aufustius |  | i BC |  |
| AUG. ANC. 6.43 | C. Iulius Caesar Octauianus (Augustus) | Monumentum Ancyranum | 63 BC-AD 14 | Ehrenberg & Jones Oxf. 1949 |
| hist. 20 |  |  |  |  |
| poet. 6 |  |  |  |  |
| AUGUR. poet. 8 | Sentius Augurinus |  | ii AD (early) |  |
| August. C. D. 22.30 | Aurelius Augustinus (St Augustine) | de Ciuitate Dei | AD 354-430 | Dombart T 1892 |
| AUR. Fro. 1.p.14 (49N) | M. Aurelius Antoninus |  | emp. AD 161-180 | see FRO. |
| poet. 1 |  |  |  |  |
| AUR. OP. gram. 18 | Aurelius Opillus |  | ii-i BC |  |
| AVIT. poet. 3.2 | Alfius Auitus |  | ii AD |  |
| BALB. Att. 9.i3a.1 | L. Cornelius Balbus |  | cos. 40 BC | see CIC. Att. |
| BALB. grom. p.108La | Balbus |  | time of Trajan |  |
| BALB. OPP. Att. 9.78.1 | see BALB. Att./OPP. hist |  |  | see CIC. Att. |
| BAS. gram. 10 | Gaius Bassus |  | i BC |  |
| BAS. poet. 10 | Caesius Bassus |  | i AD |  |
| B. Afr. 98.2 |  | de Bello Africo | c. 40 BC | see CAES. Civ. |
| B. Alex. 78.5 |  | de Bello Alexandrino | c. 40 BC | see CAES. Civ. |
| B. Hisp. 42.7 |  | de Bello Hispaniensi | c. 40 BC | see CAES. Civ. |
| BIB. poet. 17.2 | M. Furius Bibaculus |  | b. 103 BC |  |
| BITH. Fam. 6.16 | A. Pompeius Bithynicus |  | praet. 45 BC | see CIC. Fam. |
| BRUT. ad. Brut. 2.3.6 | M. Iunius Brutus |  | 85-42 BC | see CIC. ad Brut. |
| orat. 31 |  |  |  |  |
| BRUT. iur. 3 | M. Iunius Brutus |  | ii BC (late) |  |
| BRUT. CAS. Fam. 11.3.4 | see BRUT.1/CAS. |  |  | see CIC. Fam. |
| Buc. Eins. 2.38 |  | Bucolica Einsildensia | time of Nero | see CALP. Ecl. |
| CABCIL. com. 294 | Caecilius Statius |  | d. 168 BC |  |
| CAECIN. Fam. 6.7.6 | A. Caecina |  | i BC | see CIC. Fam. |
| CAEL. Att. 10.0a.5 | M. Caelius Rufus |  | i BC | see CIC. Att. |
| Fam. 8.17.2 |  |  |  | see CIC. Fam. |
| orat. 34 |  |  |  |  |
| CABL. iur. 2 | Cn. Arulenus Caelius Sabinus |  | cos. AD 69 |  |
| CASP. orat. 9 | Q. Serulius Caepio |  | d. 90 BC |  |
| CAES. Att. 10.8b.2 | C. Iulius Caesar |  | c. 100-44 BC | see CIC. Att. |
| Ciu. 3.112.13 |  | de Bello Ciuli |  | du Pontet OCT 1900 |
| Gal. 7.90.8 |  | de Bello Gallico |  | du Pontet OCT 1900 |
| gram. 31 |  |  |  |  |
| orat. 47 |  |  |  |  |
| poet. 2.6 |  |  |  |  |
| CAESBL. in Gel. 6(7).3.4 | L. Caesellius Vindex |  | ii AD (early) |  |
| CALID. orat. 13 | M. Calidius |  | praet. 57 BC |  |
| CALIGULA in Suet. Cal. 55.1 | C. Caesar Augustus Germanicus |  | AD 12-41 |  |
| CALL. dig. 50.16.220.3 | Callistratus |  | ii-iii AD |  |
| CALP. Decl. 53 | Calpurnius Flaccus | Declamationes | ii AD | Lehnert T 1903 |
| CALP. Ecl. 7.84 | T. Calpurnius Siculus | Eclogae | i AD (mid) | Giarratano Turin 1924 |
| CALP. hist. 45 | L. Calpurnius Piso Frugi |  | cos. 133 BC |  |
| CALV. orat. 37 | C. Licinius Macer Caluus |  | 82-47 BC |  |
| poet. 19 |  |  |  |  |
| CAN. orat. 5 | P. Cannutius |  | i BC |  |
| CAP. gram. 14 | C. Ateius Capito |  | cos. AD 5 |  |
| iur. 34 |  |  |  |  |
| CAPER in G.L. 1.132 | Flavius Caper |  | ii AD |  |
| CARBO orat. 9 | C. Papirius Carbo |  | cos. 110 BC |  |
| CARBO ARV. orat. 3 | C. Papirius Carbo Aruina |  | i BC (early) |  |


| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| Carm. Bell. Aeg. 67 |  | Carmen de Bello Aegyptiaco | contemp. Ovid | Poetae Latini Minores Baehrens T 1879 |
| Carm. Nelei 5 (trag. p.271) |  | Carmen Nelei | ? iii BC |  |
| Carm. Sal. 21 (poet. p.5) |  | Carmen Saliare | uncertain |  |
| CAS. Fam. 15.19.4 | C. Cassius Longinus |  | d. 42 BC | see Ctc. Fam. |
| CASC. iur. 2 | A. Cascellius |  | i BC (early) |  |
| CAS. SBV. in Quint. Inst. 11.1.58 | Cassius Seuerus |  | d. c. AD 34 |  |
| CASSIUS PARMENSIS in Suet. Aug. 4.2 |  | Cassius Parmensis | i BC |  |
| CATO Agr. 163.3 | M. Porcius Cato | de Agri Cultura | 234-149 BC | Goetz T 1922 |
| Dict. 83.(J) |  | Dicta Memorabilia |  | Jordan Leipzig 1860 |
| Ep. 5.(J) |  | Epistulae |  | Jordan Leipzig 1860 |
| Fil. 16.(J) |  | libri ad Filium |  | Jordan Leipzig 1860 |
| hist. 143 |  |  |  |  |
| inc. 77.(J) |  |  |  |  |
| iur. 2 |  |  |  |  |
| Mil. 45.(J) |  | de Re Militari |  | Jordan Leipzig 1860 |
| Mor. 3.(J) |  | Carmen de Moribus |  | Jordan Leipzig 1860 |
| orat. 249 |  |  |  |  |
| CATO Fam. 15.5.3 | M. Porcius Cato Viticensis |  | 95-46 BC | see Ctc. Fam. |
| CATO nep. orat. 3 | C. Porcius Cato |  | cos. 114 BC |  |
| CATUL. 116.8 | C. Valerius Catullus |  | c 84-c 54 BC | Mynors OCT 1958 |
| CELS. 8.25.5 | A. Cornelius Celsius |  | contemp. Tiberius | Marx Leipzig 1915 |
| CELS. dig. 50.17.193 | P. Luuentius Celsius |  | cos. II. AD 129 |  |
| Char. p.532.K | Flauius Sospater Charisius | Ars Grammatica | iv AD | Barwick T 1925 |
| CIC. Ac. 1.4.6 | M. Tullius Cicero | Academica | 106-43 BC | Plasberg T 1922 |
| ad Brut. 2.5.6 |  | Epistulae ad Brutum |  | Purser OCT 1901 |
| Aer. Al. Mil. fr. 24 |  | Interrogatio de aere alieno Milonis |  | Mueller T 1898 |
| Agr. 3.16 |  | de Lege Agraria |  | Clark OCT 1909 |
| Alcyon. fr. 2 |  | Alcyones |  | Mueller T 1898 |
| Alex. fr. 13 |  | de Rege Alexandrino |  | Mueller T 1898 |
| Amic. 104 |  | de Amicitia |  | Simbeck T 1917 |
| Arat. 733.(480) |  | Arati Phoenomena |  | Mueller T 1898 |
| Arat. Progn. 425 |  | Arati Prognostica |  | Mueller T 1898 |
| Arch. 32 |  | pro Archia |  | Clark OCT 1911 |
| Att. 16.16f.18 |  | Epistulae ad Atticum |  | Purser OCT 1903 |
| Aug. fr. 5 |  | de Augustus |  | Mueller T 1898 |
| Balb. 65 |  | pro Balbo |  | Peterson OCT 1911 |
| Brut. 333 |  | Brutus |  | Wilkins OCT 1903 |
| Caec. 104 |  | pro Caecina |  | Clark OCT 1909 |
| Cael. 80 |  | pro Caelio |  | Clark OCT 1905 |
| Catil. 4.24 |  | in Catilinam |  | Clark OCT 1905 |
| Cato fr. 15 |  | Cato |  | Mueller T 1898 |
| Chorog. fr. 1 |  | Chorographia |  | Mueller T 1898 |
| Clod. fr. 33 |  | in P. Clodium et C. Curionem |  | Mueller T 1898 |
| Clu. 202 |  | pro Cluentio |  | Clark OCT 1905 |
| Cons. fr. 11 |  | de Consulatu suo |  | Mueller T 1898 |
| Consil. fr. 4 |  | de Consilisis suis |  | Mueller T 1898 |
| Consol. fr. 17 |  | Consolatio |  | Mueller T 1898 |
| Corn. 2 fr. 18 |  | pro Cornelio |  | Mueller T 1898 |
| de Orat. 3.230 |  | de Oratore |  | Wilkins OCT 1903 |
| Deiot. 43 |  | pro Rege Deiotaro |  | Clark OCT 1918 |
| Din. 2. 150 |  | de Diunianone |  | Ax T 1938 |
| Din. Cae. 73 |  | Diuniatio in Qi Caecilium |  | Peterson OCT 1917 |
| Dom. 147 |  | de Domo sua |  | Peterson OCT 1911 |
| Eleg. fr. 1 |  | Elegia Talemastis (dub. title) |  | Mueller T 1898 |
| Ep. fr. 18.5 |  | fragmenta epistularum |  | Purser OCT 1903 |
| Epigr. 3 |  | Epigrammata |  | Mueller T 1898 |
| Facet. 53 |  | Facete Dicta |  | Mueller T 1898 |
| Fam. 16.24.2 |  | Epistulae ad Familiares |  | Purser OCT 1901 |
| Fat. 48 |  | de Fato |  | Ax T 1938 |
| Fin. 5. 96 |  | de Finibus Bonorum et Malorum |  | Schiche T 1915 |
| Flac. 106 |  | pro Flacco |  | Clark OCT 1909 |
| Font. 49 |  | pro Fonteio |  | Clark OCT 1911 |
| Fund. fr. 7 |  | pro Fundanio |  | Mueller T 1898 |
| Gal. fr. 7 |  | pro Q. Gallio |  | Mueller T 1898 |
| Glor. fr. 14 |  | de Gloria |  | Plasberg T 1917 |
| Har. 63 |  | de Haruspicum Responso |  | Peterson OCT 1911 |
| Hort. fr. 103 |  | Hortensis |  | Mueller T 1898 |


| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| inc. orat. fr.34 |  | incertarum orationum fragmenta |  | Mueller T 1898 |
| Inv. 2.78 |  | de Inuentione |  | Stroebel T 1915 |
| iur. Civ. fr.3 |  | de Jure Ciulli in artem redigendo |  | Mueller T 1898 |
| Leg. 3.49 |  | de Legibus |  | Vahlen T 1883 |
| lib. inc. fr.43 |  | fragmenta librorum incertorum |  | Vahlen T 1883 |
| Lig. 38 |  | pro Ligario |  | Clark OCT 1918 |
| Lim. 4 |  | Limon |  | Mueller T 1898 |
| Luc. 148 |  | Lucellus |  | Plasberg T 1912 |
| Man. 71 |  | pro Lege Manilia |  | Clark OCT 1905 |
| pro Man. fr.1 |  | pro C. Manilio |  | Mueller T 1898 |
| Mar. 4.2 |  | Marius |  | Mueller T 1898 |
| Marc. 34 |  | pro Marcello |  | Clark OCT 1918 |
| Met. fr.10 |  | contra Contionem Q. Metelli |  | Mueller T 1898 |
| Mil. 105 |  | pro Milone |  | Clark OCT 1918 |
| Mur. 90 |  | pro Murena |  | Clark OCT 1918 |
| N. D. 3.95 |  | de Natura Deorum |  | Ax T 1933 |
| Ocon. fr.18 |  | Oeconomicus |  | Mueller T 1898 |
| Off. 3.121 |  | de Officis |  | Atzert T 1932 |
| Op. fr.12 |  | pro Oppio |  | Mueller T 1898 |
| Opt. Gen. 23 |  | de Optimo Genere Oratorum |  | Wilkins OCT 1903 |
| Orat. 238 |  | Orator |  | Wilkins OCT 1903 |
| Parad. 52 |  | Paradoxa Stoicorum |  | Mueller T 1898 |
| Part. 140 |  | Partitiones Oratoriae |  | Wilkins OCT 1903 |
| Phil. 14.28 |  | Philipicae |  | Clark OCT 1918 |
| Pis. 99 |  | in Pisonem |  | Clark OCT 1909 |
| Planc. 104 |  | pro Plancio |  | Clark OCT 1911 |
| poet. 40 (55).2 |  |  |  |  |
| Prot. fr.5 |  | Protogoras |  | Mueller T 1898 |
| Prov. 47 |  | de Prouiciis Consularibus |  | Peterson OCT 1911 |
| Q. fr. 3.9.9 |  | Epistulae ad Quintum fratrem |  | Purser OCT 1902 |
| Q. Rosc. 56 |  | pro Q. Roscio comeodo |  | Clark OCT 1909 |
| Quinct. 99 |  | pro Quinctio |  | Clark OCT 1909 |
| Rab. Perd. 38 |  | pro Rabirio Perduellionis Reo |  | Clark OCT 1909 |
| Rab. Post. 48 |  | pro Rabirio Postumo |  | Clark OCT 1909 |
| Red. Pop. 25 |  | post Reditum ad Populum |  | Peterson OCT 1911 |
| Red. Sen. 39 |  | post Reditum in Senatu |  | Peterson OCT 1911 |
| Rep. 6.39 |  | de Republica |  | Ziegler T 1929 |
| S. Rosc. 154 |  | pro S. Roscio Amerino |  | Clark OCT 1905 |
| Scaur. 51 |  | pro Scauro |  | Clark OCT 1911 |
| Sen. 85 |  | de Senectute |  | Simbeck T 1917 |
| Sest. 147 |  | pro Sestio |  | Peterson OCT 1911 |
| sing. voc. ex inc. lib. 37 |  | singulae uoces ex incertis libris |  | Mueller T 1898 |
| Sul. 93 |  | pro Sulta |  | Clark OCT 1911 |
| Tim. 52 |  | Timaeus |  | Ax T 1938 |
| Top. Cand. fr.28 |  | in Toga Candida |  | Mueller T 1898 |
| Top. 100 |  | Topica |  | Wilkins OCT 1903 |
| Tul. 56 |  | pro Tullio |  | Clark OCT 1911 |
| Tusc. 5.121 |  | Tusculanae Disputationes |  | Pohlenz T 1918 |
| Var. fr. 19 |  | pro L. Vareno |  | Mueller T 1898 |
| Vat. 41 |  | in Vatinium |  | Peterson OCT 1911 |
| Ver. 56 |  | in Verrem (actio prima) |  | Peterson OCT 1917 |
| Ver. 5.189 |  | in Verrem (actio secunda) |  | Peterson OCT 1917 |
| Virt. fr. |  | de Virtuibus |  | Plasberg T 1932 |
| [Cic. ] Sal. 22 |  | in Salutium |  | Kurfess T 1914 |
| Exil. 30 |  | oratio pride quam in exilium iret |  | Mueller T 1898 |
| Cic. fil. Fam. 16.25 | M. Tullius Cicero |  | b. 65 BC | see Cic. Fam. |
| CINC. gram. 34 | L. Cincius |  | i BC |  |
| iur. 35 |  |  |  |  |
| CINNA poet. 12 | C. Heluius Cinna |  | i BC |  |
| Cris 541 |  | (in Appendix Vergiliana) | time of Augustus ii AD | Ellis OCT 1907 |
| CLEM. dig. 50.16.153 | Terentius Clemens |  |  |  |
| CLOAT. gram. 16 | Cloatius Verus |  | i BC (late) |  |
| CLOD. hist. 4 | M. Clodius Licinus |  | cos. suff. AD 4 |  |
| COBL. hist. 67 | L. Coelius Antipater |  | ii BC (late) |  |
| COL. 12.59.5 | L. Iunius Moderatus Columella | de Re Rustica | i AD (mid) | Books 1, 2, 6–11 Lundström–Josephson Uppsala 1897–1955 Books 3–5, 12 Ash, Forster–Heffner L 1941–55 |
| Arb. 30.2 |  | de Arboribus |  | Forster–Heffner L 1955 |


# BIBLIOGRAPHICAL GUIDE

| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| Copa 38 |  | (in Appendix Vergiliana) | time of Augustus | Ellis OCT 1907 |
| CORN. SBV. poet. 13.25 | Cornelius Seuerus |  | time of Augustus |  |
| CORNELIA Nep. fr.2 | (mother of Gracchi) |  | ii BC | see NEP. |
| CORNIF. gram. 17 | Cornificius Longus |  | i BC |  |
| CORNIF. poet. 3 | Q. Cornificius |  | i BC |  |
| CORNIF. GAL. poet. 1 | Cornificius Gallus |  | time of Augustus |  |
| COTTA orat. 18 | C. Aurelius Cotta |  | cos. 75 BC |  |
| CRAS. orat. 49 | L. Licinius Crassus |  | cos. 95 BC |  |
| CREM. hist. 6 | A. Cremitius Cordus |  | d. AD 25 |  |
| Culex 414 |  | (in Appendix Vergiliana) | time of Augustus | Ellis OCT 1907 |
| CUR. Fam. 7.39.2 | M: Curius |  | trib. 58 BC | see CIC. Fam. |
| CURIO av. orat. 4 | C. Scribonius Curio (auus) |  | praet. 121 BC |  |
| CURIO pat. orat. 14 | C. Scribonius Curio (pater) |  | cos. 76 BC |  |
| CURT. 10.10.20 | Q. Curtius Rufus | Historiae Alexandri Magni | i AD (mid) | Hedicke T 1908 |
| D. BRUT. Fam. 11. 26 | D. Iunius Brutus Albinus |  | d. 43 BC | see CIC. Fam. |
| Dirae 103 |  | (in Appendix Vergiliana) | i BC (late) | Ellis OCT 1907 |
| DOLAB. Fam. 9.9.3 | P. Cornelius Dolabella |  | d. 43 BC | see CIC. Fam. |
| DOM. in Plin. Ep. 10.68(66).6 | T. Flavius Domitianus |  | emp. AD 81–96 |  |
| DOM. Ar. in Quint. Inst. 11.3.126 | Domitius Afer |  | d. AD 59 |  |
| DOM. MARS. poet. 7.4 | Domitius Marsus |  | time of Augustus |  |
| Don. Ter. Ph. 1055 | Aelius Donatus | Commentum Terenti | iv AD | Wessner T 1903–5 |
| DORC. poet. 2 | Dorcatius |  | time of Augustus |  |
| Ed. aed. cur. (Font. iur. p.238) 3 |  | Edicta aedilium curulum |  |  |
| Ed. pr. (Font. iur. p.237) 45.13 |  | Edicta praetorum |  |  |
| EGN. poet. 2.2 | Egnatius |  | i BC |  |
| Eleg. Maec. 178 |  | Elegia in Maecenatem (in Appendix Vergiliana) | i AD (early) | Ellis OCT 1907 |
| Elog. 48 (CIL 1.p.103) |  | Elogium |  |  |
| Elog. Cal. (poet. p.7) |  | A. Atilii Calatini elogium | A. was cos. 258, 254 BC |  |
| ENN. Ann. 628 | Q. Ennius | Annales | 239–169 BC | Vahlen Leipzig 1928 |
| inc. 53 |  |  |  | Vahlen Leipzig 1928 |
| Sat. 70 |  | Satirae |  | Vahlen Leipzig 1928 |
| scen. 430 |  | scenica |  | Vahlen Leipzig 1928 |
| var. 146 |  | uaria |  | Vahlen Leipzig 1928 |
| Epic. Drusi 474 |  | Epicedion Drusi (Consolatio ad Liiam) | i AD | Poetae Latini Minores Vollmer T 1923 |
| Epigr. Pac. 4 (poet. p.32) |  | Epigramma Pacuii | (Pacuvius d. c. 130 BC) |  |
| Epigr. Plaut. 3 (poet. p.32) |  | Epigramma a Varrone Plauto attributum |  |  |
| FAB. MAX. hist. 4 | Q. Fabius Maximus Seruilianus |  | cos. 142 BC |  |
| FAB. PICT. hist. 6 | Ser. Fabius Pictor |  | ii BC (mid) |  |
| iur. 9 |  |  |  |  |
| FAN. hist. 9 | C. Fannius |  | cos. 122 BC |  |
| orat. 5 |  |  |  |  |
| Fast. Col. (CIL 1.p.64) |  | Fasti Consulares Colotiani |  |  |
| Fast. Cos. Cap. 46 (CIL 1.p.39) |  | Fasti Consulares Capitolini |  |  |
| Fast. Praen.* (CIL 1.p.72) |  | Fasti Consulares Praenestini |  |  |
| FAV. orat. 1 | ? Fauorinus |  | ii or i BC |  |
| FEN. hist. 30 | Fenestella | ? 52 BC–? AD 19 |  |  |
| FBST. p. 376M | Sex. Pompeius Festus |  | ii AD (late) | Lindsay T 1913 |
| FLOR. anth. 252.2 | ? L. Annius Florus |  | ii AD |  |
| Epit. 3.34 (4.12.66) |  | Epitome bellorum omnium annorum DCC |  | Rossbach T 1896 |
| poet. 4 |  |  |  |  |
| Verg. p.187R |  | Vergilius orator an poeta |  | Rossbach T 1896 |
| FLORENT. dig. 50.16.2 | Florentinus |  | iii AD (early) |  |
| FRO. Amic. 2.p.244 (188N) | M. Cornelius Fronto | Epistulae ad Amicos ad Antoninum Pium | c. AD 100–c. 166 | Haines L 1919–20 |
| Ant. 1.p.262 (170N) |  |  |  |  |
| Ar. 1.p.58 (238N) |  | Arion |  |  |
| Aur. 2.p.232 (232N) |  | ad Aurelium |  |  |
| Parth. 2.p.30 (222N) |  | de Bello Parthico |  |  |
| Ver. 2.p.238 (136N) |  | ad Verum |  |  |

* Other Fasti in CIL 1 are referred to similarly.


| ABBREVIATION | NAMB OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| FROM. agrim. p.49 | Sex. Iulius Frontinus |  | c. AD 30-104 |  |
| Aq. 130 |  | de Aquis Vrbis Romae |  | Krohn T 1922 |
| Str. 4.7.24 |  | Strategemata |  | Gundermann T 1888 |
| Fulg. serm. ant. 62 | Fabius Planciades Fulgentius Afer | expositio meronum antiquorum | v-vi AD . | Helm T 1898 |
| FUR. ANT. poet. 6 | A. Furius Antias |  | fl. 100 BC |  |
| FURIUS iur. 1 | L. Furius Philus |  | ii BC |  |
| GABT. poet. 3 | Cn. Cornelius Lentulus Gaetulicus |  | c08. AD 26 |  |
| GAIUS dig. 50.17.158 | (other names unkn.) |  | ii AD |  |
| Inst. 4.1.87 |  | Institutiones |  | Kuebler T 1935 |
| GAL. poet. 1 | C. Cornelius Gallus |  | c. 69-26 BC |  |
| GAL. gram. 28 | C. Aelius Gallus |  | i BC (late) |  |
| iur. 3 |  |  |  |  |
| GALBA Fam. 10.30.5 | Ser. Sulpicius Galba . |  | i BC | see CtC. Fam. |
| GAN. poet. 3 | Gannius |  | unkn. |  |
| GEL. 20.11.5 | A. Gellius | Noctes Atticae | AD 123-c. 165 | Hosius T 1903 |
| GEL. hist. 33 | Cn. Gellius |  | ii BC (late) |  |
| GERM. Arad. 725 | Germanicus Iulius Caesar | Aratea | 15 BC-AD 19 | Breysig T 1899 |
| Epig. 2.8 |  | Epigrammata |  | Breysig T 1899 |
| fr. 6.2 |  |  |  | Breysig T 1899 |
| GNIPHO gram. 4 | M. Antonius Gnipho |  | ii-i BC |  |
| GRACCH. orat. 68 | C. Sempronius Gracchus |  | trib. pl. 123, 122 BC |  |
| GRACCH. trag. 4 | Gracchus |  | ? time of Augustus |  |
| GRACCHAN. iur. 11 | M. Iunius Gracchanus |  | ii BC (late) |  |
| GRAN. FL. gram. | Granius Flaccus |  | i BC |  |
| iur. 8 |  |  |  |  |
| GRAT. 541 | Grattius | Cynegetica | contemp. Ovid | Poetae Latini Minores Vollmer T 1911 |
| HADR. poet. 3.5 | P. Aelius Hadrianus |  | emp. AD 117-28 |  |
| HBM. hist. 40 | L. Cassius Hemina |  | ii BC (mid) |  |
| HIRT. Att. 15.6.3 | A. Hirtius |  | c08. 43 BC | see CtC. Att. |
| Gal. 8.55.2 |  |  |  | see CARS. Gal. |
| HOR. Ars 476 | Q. Horatius Flaccus | Ars Poetica | 65-8 BC | Garrod OCT 1911 |
| Carm. 4.15.33 |  | Carmina |  | Garrod OCT 1911 |
| Ep. 2.2.216 |  | Epistulae |  | Garrod OCT 1911 |
| Epod. 17.81 |  | Epodi |  | Garrod OCT 1911 |
| S. 2.8.95 |  | Sermones |  | Garrod OCT 1911 |
| Saec. 76 |  | Carmen Sacculare |  | Garrod OCT 1911 |
| HORT. orat. 46 | Q. Hortensius Hortalus |  | 114-50 BC |  |
| HOST. poet. 5 | Hostius |  | ii BC |  |
| HYG. gram. 23 | C. Iulius Hyginus |  | time of Augustus |  |
| hist. 17 |  |  |  |  |
| HYG. Fab. 277.5 | Hyginus | Fabulae (Genealogiae) | ? ii AD | Rose Leyden 1934 |
| Astr. 4.19 |  | Astronomica |  | Bunte Leipzig 1875 |
| HYG. agrim. p.98 | Hyginus |  | time of Trajan |  |
| HYG. Gr. agrim. p.171 | Hyginus Gromaticus |  | ii AD |  |
| Ilias 1070 |  | Baebi Italici Ilias | i AD (late) | Poetae Latini Minores Vollmer T 1913 |
| IMBR. com. 2 | Licinius Imbrex |  | ? ii BC |  |
| Inst. Dac. 15 (CIL 3-p.959) |  | Instrumenta Dacica |  |  |
| Isid. Orig. 30.16.8 | Isidorus Hispalensis | Origines | Bp. of Seville AD 602-36 | Lindsay OCT 1911 |
| JAVOL. dig. 50.17.202 | Iauelenus Priscus |  |  |  |
| JULIAN. dig. 50.17.67 | Saluius Iulianus |  | ii AD (mid) |  |
| JUV. 16.60 | D. Iunius Iuuenalis |  | i-i AD | Owen OCT 1907 |
| JUVENT. com. 10 | Iuuentius |  | before Varro |  |
| LABBO dig. 50.16.244 | M. Antistius Labeo |  | d. before AD 22 |  |
| gram. 25 |  |  |  |  |
| iur. 31 |  |  |  |  |
| LABEO poet. 1 | Attius Labeo |  | (mentioned by Persius) |  |
| LABER. com. 158 | D. Laberius |  | c. 115-43 BC |  |
| LAEL. orat. 14 | C. Laelius Sapiens |  | c08. 140 BC |  |
| LAEL. FEL. iur. 4 | Laelius Felix |  | ? ii AD (mid) |  |
| LAEV. poet. 32.2 | Laevius |  | i BC (early) |  |
| LANUV. com. 2 | Luscius Lanuuiinus |  | contemp. Terence |  |


# BIBLIOGRAPHICAL GUIDE

| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| LARG. 271 | Scribonius Largus |  | i AD (first half) | Helmreich T 1887 |
| LAUREA poet. 10 | M. Tullius Laurea |  | freedman of Cicero |  |
| Laus Pit. 261 |  | Laus Pisonis | i AD (mid) | Poetae Latini Minores Baehrens T 1879 |
| L. CAES. iur. 4 | L. Julius Caesar |  | cos. 64 BC |  |
| Leg. pub. (Font. iur. p.119) 26 |  | Leges Publicae |  |  |
| LENT. Fam. 12,15,7 | P. Cornelius Lentulus Spinther |  | cos. 57 BC | see CIC. Fam. |
| LEP. Fam. 10,35,2 | M. Aemilius Lepidus |  | Triumvir 43 BC | see CIC. Fam. |
| LEP. orat. 6 | M. Aemilius Lepidus Porcina |  | cos. 137 BC |  |
| LEX. XII (Font. iur. p.40) |  | Leges (or Lex) XII tabularum |  |  |
| LIC. RUP. dig. 50,17,210 | Licinius Rufnus |  | ii-iii AD |  |
| LIV. 45,44,31 | T. Liuius | ab Vrbe Condita | ? 59 BC-? AD 17 | Bks. 1-10, 21-30 Conway etc. OCT 1914-15 Bks. 31-8 Mueller T 1920-30 Bks. 39-40 Heraeus T 1931 Bks. 41-5 Giarratano Rome 1933 fragments and periochae Weissborn T 1933 |
| LUC. 10,54,6 | M. Annaeus Lucanus | Bellum Ciule | AD 39-65 | Housman Oxf. 1916 |
| LUCC. Fam. 5,14,3 | L. Luceius |  | i BC (mid) | see CIC. Fam. |
| LUCIL. 1350 | C. Lucilius |  | c. 180-c. 102 BC | Marx Leipzig 1904 |
| LUCIL. JUN. poet. 4 | C. Lucilius Junior |  | i AD (mid) |  |
| LUCR. 6,1286 | T. Lucretius Carus | de Rerum Natura | c. 94-55 BC | Bailey OCT 1912 |
| LUTAT. poet. 2,4 | Q. Latatius Catulus |  | cos. 102 BC |  |
| Lydia 80 |  | (in Appendix Vergiliana) | i BC (late) | Ellis OCT 1907 |
| MACER poet. 17 | Aemilius Macer |  | d. 16 BC |  |
| MACER dig. 50,5-5 | Aemilius Macer |  | iii AD (early) |  |
| MACER hist. 27 | C. Licinius Macer |  | trib. pl. 73 BC |  |
| MACr. 7,16,34 | Ambrosius Theodosius Macrobius | Saturnalia | iv AD (late) | Eyssenhardt T 1893 |
| MACC. poet. 9 | C. Maecenas |  | d. 8 BC |  |
| MACCIAN. dig. 49,17,18 iur. 81 | L. Volusius Maecianus |  | ii AD (late) |  |
| MAN. poet. 3,2 | Manilius |  | i BC (early) |  |
| MAN. iur. 11 | M. Manilius |  | cos. 149 BC |  |
| MAN. 5,745 | M. Manilius | Astronomica | i AD (early) | Housman Camb. 1933 |
| MANC. oral. 1 | Helius Mancia |  | i BC (early) |  |
| MARC. Fam. 4,11,2 | M. Claudius Marcellus |  | cos. 51 BC | see CIC. Fam. |
| MARCEL. dig. 50,17,192 | Vplius Marcellus |  | ii AD (late) |  |
| MARCIANUS dig. 49,1-7 | Aelius Marcianus |  | iii AD |  |
| MARCUS poet. 3 | Cn. Marcius |  | ? iii BC |  |
| MARIAN. poet. 5 | Marianus |  | ii AD |  |
| MART. 14,233,2 | M. Valerius Martialis | Epigrammata Spectacula | ? AD 40- ? 101 | Lindsay OCT 1929 |
| Sp. 33,2 |  |  |  | Lindsay OCT 1929 |
| MAT. poet. 17 | Cn. Matius |  | i BC (early) |  |
| MAT. in Cic. Att. 9,15,6 Fam. 11,28,8 | C. Matius |  | i BC | see CIC. Att. |
| MAUR. 2981 | Terentianus Maurus | de Litteris de Syllabis de Metris | ii AD (late) | see CIC. Fam. |
| MAUR. dig. 49,14,15,6 | Iunius Mauricianus |  | ii AD (mid) |  |
| MBLA 3,107 | Pomponius Mela | de Choreographia | wrote c. AD 40 | Frick T 1880 |
| MBM. oral. 14 poet. 1 | C. Memmius |  | praet. 58 BC |  |
| MBN. dig. 49,18,1 | Arrius Menander |  | ii-iii AD |  |
| MBS. COR. gram. 5 | M. Valerius Messalla Coruinus |  | 64 BC-AD 8 |  |
| hist. 10 orat. 33 |  |  |  |  |
| MBS. RUF. gram. 8 hist. 3 iur. 2 | M. Valerius Messalla Rufus |  | cos. 53 BC |  |
| MBT. CEL. Fam. 5,1,2 | Q. Caecilius Metellus Celer |  | cos. 60 BC | see CIC. Fam. |
| MBT. MAC. orat. 9 | Q. Caecilius Metellus Macedonicus |  | cos. 143 BC |  |


| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| MET. NEP. Fam. 5.3.1 | Q. Caecilius Metellus Nepos |  | COS. 57 BC | see CIC. Fam. |
| MET. NUM. orat. 5 | Q. Caecilius Metellus Numidicus |  | COS. 109 BC |  |
| MET. P-IUS in Macr. 3.13.12 | Q. Caecilius Metellus Pius |  | COS. 53 BC |  |
| Met. vers. (poet. p.28) |  | Metellorum uersus | iii BC (late) |  |
| Minucius Felix |  |  | iii AD |  |
| MOD. dig. 50.17.197 | Herennius Modestinus |  | iii AD (early) |  |
| MODESTUS in Macr. 1.16.28 | Iulius Modestus |  | time of Augustus |  |
| MONT. poet. 2.3 | Iulius Montanus |  | time of Tiberius |  |
| MOR. 124 |  | Moretum (in Appendix Vergiliana) | time of Virgil | Ellis OCT 1907 |
| M. SERGIUS in Var. L. 6.91 | M.('). Sergius Mani filius |  | ? ii BC |  |
| MUC. hist. 32 | C. Licinius Mucianus |  | COS. AD 70, 72 |  |
| MUM. com. 7 | Mummius |  | i BC |  |
| MUNARIUS in Non. p.221M |  |  | ? ii or i BC |  |
| NAEV. com. 138 | Cn. Naeuius |  | c. 270-201 BC |  |
| poet. 64.4 |  |  |  |  |
| preat. 8 |  |  |  |  |
| trag. 62 |  |  |  |  |
| Naev. Cyp. II. 2 (poet. p.51) |  | Naeuii Cyprus Ilias | ? i BC |  |
| NAM. iur. 1 | P. Aufidius Namusa |  | i BC |  |
| NEP. Ag. 8.7 | Cornelius Nepos | Agesilaus | c. 99-24 BC | Winstedt OCT 1904 |
| Alc. 11.6 |  | Alcibiades |  | Winstedt OCT 1904 |
| Ar. 3.3 |  | Aristides |  | Winstedt OCT 1904 |
| Att. 22.4 |  | Atticus |  | Winstedt OCT 1904 |
| Ca. 3.5 |  | Cato |  | Winstedt OCT 1904 |
| Cha. 4.3 |  | Chabrias |  | Winstedt OCT 1904 |
| Cim. 4.4 |  | Cimon |  | Winstedt OCT 1904 |
| Con. 5.4 |  | Conon |  | Winstedt OCT 1904 |
| Dat. 11.5 |  | Datames |  | Winstedt OCT 1904 |
| Di. 10.3 |  | Dion |  | Winstedt OCT 1904 |
| Ep. 10.4 |  | Epaminondas |  | Winstedt OCT 1904 |
| Eum. 13.4 |  | Eumenes |  | Winstedt OCT 1904 |
| Ham. 4.3 |  | Hamilcar |  | Winstedt OCT 1904 |
| Han. 13.4 |  | Hannibal |  | Winstedt OCT 1904 |
| Iph. 3.4 |  | Iphicrates |  | Winstedt OCT 1904 |
| Lys. 4.3 |  | Lysander |  | Winstedt OCT 1904 |
| Mill. 8.4 |  | Miltiades |  | Winstedt OCT 1904 |
| Paus. 5.5 |  | Pausanias |  | Winstedt OCT 1904 |
| Pel. 5.5 |  | Pelopidas |  | Winstedt OCT 1904 |
| Phoc. 4.4 |  | Phocion |  | Winstedt OCT 1904 |
| Reg. 3.5 |  | de Regibus |  | Winstedt OCT 1904 |
| Them. 10.5 |  | Themistocles |  | Winstedt OCT 1904 |
| Thr. 4.4 |  | Thrasybulus |  | Winstedt OCT 1904 |
| Timol. 5.4 |  | Timoleon |  | Winstedt OCT 1904 |
| Timoth. 4.6 |  | Timotheus |  | Winstedt OCT 1904 |
| NEBRAT. dig. 505.4 | L. Neratius Priscus |  | ii AD (early) |  |
| NERO poet. 5 | Nero Claudius Caesar |  | emp. AD 54-68 |  |
| NERVA Plin. Ep. 10.58.7 | M. Cocceius Nerva |  | emp. AD 96-98 |  |
| NIGID. gram. 48 | P. Nigidius Figulus |  | preat. 58 BC |  |
| NIN. poet. 2 | Ninnius Crassus |  | i BC (early) |  |
| NIPS. grom. p.301La | M. Iunius Nipsus |  | ? ii AD |  |
| Non. p. 557M | Nonius Marcellus | de Conpendiosa Doctrina | iv AD (early) | Lindsay T 1903 |
| NOV. com. 118 | Nouius |  | i BC (early) |  |
| NOV. orat. 1 | L. Nouius |  | trib. pl. 58 BC |  |
| NUx 182 |  |  | ? i AD (early) | Poetae Latini Minores Vollmer T 1933 |
| Obtr. Verg. (poet. p.105) |  | Obtrectatores Vergili |  |  |
| OPP. hist. 8 | C. Oppius |  | i BC |  |
| OPP. in Macr. 3.19.4 | Oppius Chares | de Siluestribus Arboribus | i BC |  |
| ORB. gram. 3 | L. Orbilius Pupillus |  | b. c. 113 BC |  |
| OV. Am. 3.15.20 | P. Ouidius Naso | Amores | 43 BC-AD ? 17 | Ehwald T 1916 |
| Ars 3.812 |  | Ars Amatoria |  | Ehwald T 1916 |
| Ep. 10.248 |  | Epistulae (Heroides) |  | Ehwald T 1916 |
| Fast. 6.812 |  | Fasti |  | Lenz T 1932 |
| Hal. 134 |  | Haliuteica |  | Owen OCT 1915 |
| Ib. 642 |  | Ibis |  | Owen OCT 1915 |
| Med. 100 |  | Medicamina Faciei Femineae |  | Ehwald T 1916 |


# BIBLIOGRAPHICAL GUIDE

| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| Met. 15,879 |  | Metamorphoses |  | Ehwald T 1915 |
| poet. 11 |  |  |  |  |
| Pont. 4,16,52 |  | Epistulae ex Ponto |  | Owen OCT 1915 |
| Rem. 814 |  | Remedia Amoris |  | Ehwald T 1916 |
| Tr. 5,14,46 |  | Tristia |  | Owen OCT 1915 |
| [Ov.] Ep. Sapph. 220 |  | Epistula Sapphus |  | see Ov. Ep. |
| PAC. praet. 5 | M. Pacuius |  | 220-c. 130 BC |  |
| trag. 425 |  |  |  |  |
| PACON. poet. 4 | S. Paonianus |  | unkn. |  |
| PAP. poet. 4 | Papinius |  | i BC (early) |  |
| PAPIN. dig. 50,17,74 | Aemilius Papinianus |  | ii AD (late) |  |
| PAPIRUS FABIANUS in Char. p.106K | Papirius Fabianus |  | c. 30 BC-c. AD 30 |  |
| PAP. JUST. dig. 50,12,13 | Papirius Justus |  | ii AD (late) |  |
| PAUL. dig. 50,17,211 | Iulius Paulus |  | ii-iii AD |  |
| PAUL. Fest. p.379M | Paulus Diaconus | Epitoma Festi | viii AD | Lindsay T 1913 |
| PAUL. orat. 2 | L. Aemilius Paulus |  | cos. 182, 168 BC |  |
| PEDO poet. 23 | Albinouanus Pedo |  | contemp. Ovid |  |
| PERS. 6,80 | A. Persius Flaccus | Saturae | AD 34-52 | Owen OCT 1907 |
| PETR. 141,11 | Petronius Arbiter |  | i AD (mid) | Buecheler-Heraeus Berlin 1922 |
| PHAED. 5,10,10 | Phaedrus | Fabulae | c. 15 BC-AD 50 | Postgate OCT 1919 |
| PL. Am. 1146 | T. Maccius Plautus | Amphitruo | d. 184 BC | Lindsay OCT 1903 |
| AS. 947 |  | Asinaria |  | Lindsay OCT 1903 |
| Aul. 831 |  | Aulularia |  | Lindsay OCT 1903 |
| Bac. 1211 |  | Bacchides |  | Lindsay OCT 1903 |
| Capt. 1036 |  | Captiui |  | Lindsay OCT 1903 |
| Cas. 1018 |  | Casina |  | Lindsay OCT 1903 |
| Cist. 787 |  | Cistellaria |  | Lindsay OCT 1903 |
| Cur. 729 |  | Curculio |  | Lindsay OCT 1903 |
| Epid. 733 |  | Epidicus |  | Lindsay OCT 1903 |
| Men. 1161 |  | Menaechmi |  | Lindsay OCT 1903 |
| Mer. 1026 |  | Mercator |  | Lindsay OCT 1903 |
| Mil. 1437 |  | Miles Gloriosus |  | Lindsay OCT 1903 |
| Mos. 1181 |  | Mostellaria |  | Lindsay OCT 1903 |
| Per. 858 |  | Persa |  | Lindsay OCT 1903 |
| Poen. 1422 |  | Poenulus |  | Lindsay OCT 1903 |
| Ps. 1335 |  | Pseudolus |  | Lindsay OCT 1903 |
| Rud. 1423 |  | Rudens |  | Lindsay OCT 1903 |
| St. 775 |  | Sichus |  | Lindsay OCT 1903 |
| Trim. 1189 |  | Trimummus |  | Lindsay OCT 1903 |
| Truc. 968 |  | Truculentus |  | Lindsay OCT 1903 |
| Vid. 91 |  | Vidularia |  | Lindsay OCT 1903 |
| PLANC. Fam. 10,24,8 | L. Munatius Plancus |  | cos. 42 BC | see CIC. Fam. |
| orat. 2 |  |  |  |  |
| PLIN. Nat. 37,205 | C. Plinius Secundus | Naturalis Historia | c. AD 23-79 | Mayhoff T 1892-1909 |
| PLIN. Ep. 9,40,3 | C. Plinius Caecilius Secundus | Epistulae | c. AD 61-114 | Schuster T 1952 |
| Ep. Tra. 10,120 (121).2 |  | Epistulae ad Traianum |  | Schuster T 1952 |
| Pan. 95,5 |  | Panegyricus |  | Schuster T 1952 |
| POL. Fam. 10,33,5 | C. Asinius Pollio |  | 76 BC-AD 5 | see CIC. Fam. |
| gram. 12 |  |  |  |  |
| hist. 8 |  |  |  |  |
| orat. 50 |  |  |  |  |
| poet. 1 |  |  |  |  |
| POMP. Aff. 8,12d,2 | Cn. Pompeius Magnus |  | 106-48 BC | see CIC. Aff. |
| orat. 22 |  |  |  |  |
| POMP. RUP. orat. 4 | Q. Pompeius Rufus |  | cos. 88 BC |  |
| POMPIL. poet. 1,2 | Pompilus |  | before Varro |  |
| trag. 1 |  |  |  |  |
| POMPON. com. 195 | L. Pomonius (Bononiensis) |  | ii-i BC |  |
| POMPON. dig. 50,17,206 | Sex. Pomonius |  | ii AD (mid) |  |
| iur. 1 |  |  |  |  |
| PORC. gram. 6 | Porcius Licinus |  | ii BC (late) |  |
| poet. 7 |  |  |  |  |
| POST. hist. 3 | A. Postumius Albinus |  | cos. 151 BC |  |
| P. POMPON. trag. 12 | P. Pomonius Secundus |  | cos. suff. AD 44 |  |
| Praec. 5,5 (poet. p.31) |  | Praecepta Rustica et Medica |  |  |
| Prec. Herb. 21 |  | Precatio Omnium Herbarum | i AD | Poetae Latini Minores Baehrens T 1879 |


# xxvii

| ABBREVIATION | NAMB OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| Prec. Ter. 32 |  | Precatio Terrae | i AD | Poetae Latini Minores Baehrens T 1879 |
| Priap. 86.21 |  | Priapea | time of Augustus | Buecheler-Heraeus Berlin 1932 |
| Prisc. in G.L. 3.515 | Priscianus |  | vi AD |  |
| Priv. Mil. Vet. 58 (CIL 3.p.901) |  | Priulegia Militum Veteranorumque |  |  |
| PROB. iur. 6.77 | ascribed to M. Valerius Probus (time of Nero) | Notae Iuris | dub. |  |
| PROC. dig. 50.16.126 | Proculus |  | i AD (early) |  |
| PROP. 4.11.102 | Sex. Propertius | Elegiae | i BC (late) | Barber OCT 1953 |
| PUB. com. 20 | Publilius Syrus |  | i BC |  |
| Sent. V. 35 |  | Sententiae |  | Meyer Leipzig 1880 |
| Q. CIC. Fam. 16.27.2 | Q. Tullius Cicero |  | 102-43 BC | see CIC. Fam. in CIC. Q. Fr. |
| Pet. 58 |  | Commentariolum Petitionis |  |  |
| poet. 20 |  |  |  |  |
| Q. SCAEV. dig. 50.17.73 | Q. Mucus Scaeula |  | cos. 95 BC |  |
| iur. 21 |  |  |  |  |
| QUAD. hist. 96 | Q. Claudius Quadrigarius |  | i BC (early) |  |
| QUINT. Decl. 388 (p.141,l.23) | M. Fabius Quintilianus | Declamationes | b. c. AD 35-40 | Ritter T 1884 |
| Inst. 12.11.31 |  | Institutio Oratoria |  | Radermacher T 1907-35 |
| [QUINT.] Decl. 19.16 |  | Declamationes Maiores | ? ii AD (late) | Lehnert T 1905 |
| RAB. poet. 5 | C. Rabirius |  | time of Augustus |  |
| Rhet. Her. 4.69 |  | Rhetorica ad Herennium | i BC (early) | Marx T 1935 |
| RUT. LUP. 2.20 | P. Rutilus Lupus | Schemata Lexeos | ? i BC (late) | Rhetores Latini Minores Halm Leipzig 1863 |
| RUT. RUP. hist. 15 | P. Rutilus Rufus |  | cos. 105 BC |  |
| SAB. dig. 33.7.18.14 | Masurius Sabinus |  | i AD (early) |  |
| iur. 28 |  |  |  |  |
| SABIDIUS gram. 1 |  |  | ? ii or i BC |  |
| SAL. Cat. 61.9 | C. Sallustius Crispus | Catilina | 86-c. 34 BC | Ahlberg T 1919 |
| Hist. 5.27 |  | Historiae |  | Maurenbrecher Leipzig 1893 |
| Jug. 114.4 |  | Iugurtha |  | Ahlberg T 1919 |
| Rep. 2.13.8 |  | Epistuleae ad Caesarem senem de re publica |  | Kurfess T 1921 |
| [SAL.] Cic. 7 |  | in Ciceronem | before Quintilian | Kurfess T 1914 |
| SAN. gram. 16 | Santra |  | i BC |  |
| trag. 4 |  |  |  |  |
| SAT. dig. 48.19.16.10 | Claudius Saturninus |  | ii AD (mid) |  |
| SCAEV. poet. 2 | Q. Mucus Scaeula |  | trib. pl. 54 BC |  |
| SCAEV. dig. 50.17.92 | Q. Ceruidius Scaeula |  | ii AD (late) |  |
| SCAEV. MEM. trag. 2 | ? Scaeus Memor |  | contemp. Martial |  |
| SCAUR. gram. in G.L. 7.33 | Q. Terentius Saurus |  | ii AD (early) |  |
| SCAUR. hist. 7 | M. Aemilius Scaurus |  | cos. 115 BC |  |
| orat. 10 |  |  |  |  |
| SCIP. orat. 6 | P. Cornelius Scipio Africanus Maior |  | 236-184 BC |  |
| SCIP. min. orat. 23 | P. Cornelius Scipio Aemilianus Africanus |  | 185-129 BC |  |
| S. CLOD. gram. 8 | Seruius Clodius |  | d. c. 60 BC |  |
| SEN. Con. 10.6.2 | L. Annaeus Seneca | Controuersiae | b. c. 55 BC | Mueller Vienna 1887 |
| Suas. 7.14 |  | Suasoniae |  | Edward Camb. 1928 |
| SEN. Ag. 1012 | L. Annaeus Seneca | Agamemnon | c. 5 BC-AD 65 | Richter T 1921 |
| Apoc. 15.2 |  | Apocolocyntosis |  | Buecheler-Heraeus Berlin 1932 |
| Ben. 7.31.5 |  | de Beneficiis |  | Hosius T 1914 |
| Cl. 2.75 |  | de Clementia |  | Hosius T 1914 |
| Dial. 12.20.2 |  | Dialogi |  | Hermes T 1923 |
| Ep. 124.24 |  | Epistulae |  | Beltrami Rome 1937 |
| fr. (Haase p.457) |  |  |  | Haase T 1878 |
| Her. F. 1344 |  | Hercules Furens |  | Richter T 1921 |
| Her. O. 1996 |  | Hercules Detaeus |  | Richter T 1921 |
| hist. 1 |  |  |  |  |
| Med. 1027 |  | Medea |  | Richter T 1921 |
| Nat. 7.32.4 |  | Naturales Quaestiones |  | Gercke T 1907 |
| Oed. 1061 |  | Oedipus |  | Richter T 1921 |
| Phaed. 1280 |  | Phaedra |  | Richter T 1921 |
| Phoen. 664 |  | Phoenissae |  | Richter T 1921 |
| Thy. 1112 |  | Thyestes |  | Richter T 1921 |
| Tro. 1179 |  | Troades |  | Richter T 1921 |


# BIBLIOGRAPHICAL GUIDE

| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| [SBN. ] Oct. 983 |  | Octauia | after AD 68 | Richter T 1921 |
| SEPT. poet. 33-5 | Septimius Serenus |  | ii AD |  |
| SBRV. A. 12,952 | Maurus (Marius) Seruius Honoratus | in Vergilium Commentarius | iv- v AD | Thilo T 1878-87 |
| SBV. poet. 2 | Seuius Nicanor |  | ii- i BC |  |
| SEXTIL. poet. 1 | Sextilius Ena |  | i BC (late) |  |
| SIC. FL. agrim. p.130 | Siculus Flaccus |  | unkn. |  |
| SIL. 17. 654 | Silius Italicus | Punica | c. AD 26-101 | Duff L 1934 |
| SINN. gram. 27 | Sinnius Capito |  | time of Augustus |  |
| SIS. hist. 143 | L. Cornelius Sisenna |  | praet. 78 BC |  |
| Mil. 9 |  | Milesiae |  | in hist. |
| STAT. Ach. 2.167 | P. Papinius Statius | Achilleis de Bello Germanico | c. AD 45-96 | Garrod OCT 1906 |
| Germ. 4 |  | Siluae |  | Garrod OCT 1906 |
| Stiv. 5.5.87 |  | Thebais |  | Phillimore OCT 1918 |
| Theb. 12.819 |  |  |  | Garrod OCT 1906 |
| STILO gram. 78 | L. Aelius Stilo |  | ii- i BC |  |
| STRAB. orat. 14 | C. Iulius Caesar Strabo |  | d. 87 BC |  |
| trag. 5 |  |  |  |  |
| SUBIUS poet. 8 |  |  | i BC |  |
| SUET. Aug. 101.4 | C. Suetonius Tranquillus | Augustus | ? AD 70- ? 140 | Ihm T 1933 |
| Cal. 60 |  | Caligula |  | Ihm T 1933 |
| Cl. 46 |  | Claudius |  | Ihm T 1933 |
| Dom. 23.2 |  | Domitianus |  | Ihm T 1933 |
| fr. 207 (P.353Re) |  |  |  | Reifferscheid Leipzig 1860 |
| Gal. 23 |  | Galba |  | Ihm T 1933 |
| Gram. 24 (p.118Re) |  | de Grammaticis |  | Reifferscheid Leipzig 1860 |
| Jul. 89 |  | Iulius |  | Ihm T 1933 |
| Nero 57.2 |  | Nero |  | Ihm T 1933 |
| Otho 12.2 |  | Otho |  | Ihm T 1933 |
| Poet. 47 (p.52Re) |  | de Poetis |  | Reifferscheid Leipzig 1860 |
| Rhet. 30 (p.127Re) |  | de Rhetoribus |  | Reifferscheid Leipzig 1860 |
| Tik. 76 |  | Tiberius |  | Ihm T 1933 |
| Tit. 11 |  | Titus |  | Ihm T 1933 |
| Ves. 25 |  | Vespasianus |  | Ihm T 1933 |
| Vit. 18 |  | Vitellius |  | Ihm T 1933 |
| SULLA hist. 21 | L. Cornelius Sulla |  | 13-8-78 BC |  |
| SULP. peri. Ter. Ad. 12 | C. Sulpicius Apollinaris | Periochae Terentii Comoediarum | ii AD | see TER. |
| SULPICIA poet. 2 |  |  | i AD (late) |  |
| SULP. RUP. Fam. 4.5.6 | Ser. Sulpicius Rufus |  | cois. 51 BC | see CIC. Fam. |
| iur. 18 |  |  |  |  |
| orat. 12 |  |  |  |  |
| gram. 14 |  |  |  |  |
| Tab. Aem. poet. 1 |  | Tabula M. Aemilii | c. 179 BC |  |
| Tab. Cer. 25 (CIL 3.p.959) |  | Tabellae Ceratae | ii AD (mainly) |  |
| Tab. Glab. poet. 1 |  | Tabula Acilii Glabrionis | c. 190 BC |  |
| Tab. Triumph. (CIL 1.p.77) |  | Tabula Triumphalis Barberiniana |  |  |
| TAC. Ag. 46.4 | Cornelius Tacitus | Agricola | b. c. AD 55 | Furneaux-Anderson OCT 1939 |
| Ann. 16.35 |  | Annales |  | Fisher OCT 1906 |
| Dial. 42.2 |  | Dialogus de Oratoribus |  | Furneaux OCT 1939 |
| Ger. 46.6 |  | Germania |  | Furneaux-Anderson OCT 1939 |
| Hist. 5.26 |  | Historiae |  | Fisher OCT 1910 |
| TARQUITIUS PRISCUS in Macr. 3.20.3 |  |  | ? i BC |  |
| TARR. PAT. dig. 50.6.7(6) | Tarruntenus Paternus |  | ii AD (late) |  |
| Ter. Ad. 997 | P. Terentius Afer | Adelphi | c. 195-159 BC | Kauer-Lindsay OCT 1926 |
| An. 981 |  | Andria |  |  |
| Eu. 1094 |  | Eunuchus |  |  |
| Hau. 1067 |  | Heauton Timorumenos |  |  |
| Hec. 880 |  | Hecra |  |  |
| Ph. 1055 |  | Phormio |  |  |
| TERT. dig. 49.17.4-2 | Tertullianus |  | ii AD (late) |  |
| Tertullian ad Nationes 2.9.20 | Tertullian | ad Nationes | ii-iii AD |  |
| TIB. 2.6.54 | Albius Tibullus | Elegiae | ? 48-19 BC | Postgate OCT 1914 |
| [TIB. ] 3.20.4 |  | var. elegies incl. in MSS. of Tibullus | contemp. Tibullus |  |
| TIC. poet. 2.1 | Ticidas |  | contemp. Catullus |  |
| TIRO gram. 14 | M. Tullius Tiro |  | freedman of Cicero |  |


| ABBREVIATION | NAME OF AUTHOR | TITLE OF WORK | DATE | EDITION |
| --- | --- | --- | --- | --- |
| TIT. gram. 3 | Titius |  | ? i BC (late) |  |
| TIT. orat. 2 | C. Titius |  | ii BC (mid) |  |
| TITIN. com. 188 | Titinius |  | ii BC |  |
| TRA. Plin. Ep. 10,121(122) | M. Vlipius Traianus |  | emp. AD 98-117 |  |
| TRAB. com. 6 | Q. Trabea |  | contemp. Caecilius |  |
| TRACHALUS in Quint. Inst. 8,5,19 | P. Galerius Trachalus |  | i AD |  |
| TREB. iur. 1 | C. Trebatius Testa |  | i BC (late) |  |
| TREBON. Fam. 12,16,4 | C. Trebonius |  | cos. 45 BC | see C1C. Fam. |
| TROG. in Plin. Nat. 11,276 | Pompeius Trogus |  | time of Augustus |  |
| TRYPH. dig. 50,16,225 | Claudius Tryphoninus |  | ii-iii AD |  |
| TUB. hist. 13 | Q. Aelius Tubero |  | i BC |  |
| iur. 2 |  |  |  |  |
| TURN. poet. 2 | Turnus |  | i AD (late) |  |
| TURP. com. 218 | Sex. Turpilius |  | d. 103 BC |  |
| ULP. dig. 50,17,209 | Domittius Vlpianus |  | d. AD 228 |  |
| VAG. poet. 2,2 | Vagellius |  | i AD (mid) |  |
| VAL. com. 1 | Valerius |  | ? i BC (mid) |  |
| VAL. dig. 50,8,6 (4) | Aburnius Valens |  | ii AD (mid) |  |
| VAL. ANT. hist. 66 | Valerius Antias |  | i BC (early) |  |
| VALG. poet. 6 | Valgius Rufus |  | cos. 12 BC |  |
| VAR. gram. 461 | M. Terentius Varro |  | 116-27 BC |  |
| hist. 23 |  |  |  |  |
| hist. Ann. 2 |  | Annales |  |  |
| hist. Urb. 1 |  | Res Vrbanae |  | Goetz-Schoell Leipzig 1910 |
| L. 10,8,4 |  | de Lingua Latina |  | Buecheler-Heraeus Berlin 1922 |
| Men. 591 |  | Menippeae |  | Goetz T 1929 |
| R. 3,17,10 |  | Res Rusticae |  |  |
| VAR. AT. poet. 23 | P. Terentius Varro Atacinus |  | 82-c. 35 BC |  |
| VAT. Fam. 5,10b | P. Vatinius |  | cos. 47 BC | see C1C. Fam. |
| Vegetius Epitoma Rei Militaris | P. Flavius Vegetius Renatus? |  | iv/v AD | Lang T 1869 |
| 2,19 |  |  |  |  |
| Mulomedicina 5,23,1 |  |  |  |  |
| VEL. gram. in G.L. 7,81 | Velius Longus |  | ii AD (early) |  |
| VBLL. 2,131,2 | C. Velleius Paterculus |  | b. c. 19 BC | Ellis OCT 1898 |
| VEN. dig. 50,17,99 | Venuleius Saturninus |  | i AD (mid) |  |
| VER. Fro. 2,p.236(132N) | L. Verus |  | AD 130-69 | see Fro. |
| VER. FL. gram. 35 | M. Verrius Flaccus |  | time of Augustus |  |
| hist. 2 |  |  |  |  |
| VERAN. gram. 13 | Veranius |  | i BC (late) |  |
| iur. 14 |  |  |  |  |
| BERG. A. 12,952 | P. Vergilius Maro | Aeneis | 70-19 BC | Hirtzel OCT 1900 |
| Cat. 14,2 |  | Catalepton (in Appendix Vergiliana) |  | Ellis OCT 1907 |
| Ecl. 10,77 |  | Eclogae |  | Hirtzel OCT 1900 |
| G. 4,566 |  | Geogica |  | Hirtzel OCT 1900 |
| VERGINIUS RUFUS poet. 1 | L. Verginius Rufus |  | i AD |  |
| Vers. popin Suet. Dom. 23,2 (poet. p.133) |  | uersus populares |  |  |
| Vers. sacr. (poet. p.5) |  | uersus sacrorum |  |  |
| V. FL. 8,467 | C. Valerius Flaccus | Argonautica | d. c. 92 AD | Kramer T 1913 |
| VIB. CRISP. in Quint. Inst. 8,5,17 | Q. Vibius Crispis |  | i AD |  |
| VITR. 10,16,2 | Vitruuius Pollio | de Architectura | time of Augustus | Krohn T 1913 |
| V. MAX. 9,15. ext. 2 | Valerius Maximus | Facta et Dicta Memorabilia | i AD (early) | Kempf T 1888 |
| VOL. poet. 1 | Columnius |  | i BC |  |
| VOLC. poet. 4 | Volcacius Sedigitus |  | ii-i BC |  |
| V. RUF. poet. 5,3 | Varius Rufus |  | time of Augustus |  |
| trag. 9 |  |  |  |  |
| V. SOR. poet. 4,2 | Q. Valerius Soranus |  | trib. pl. 82 BC |  |


*II SUPPLEMENTARY LIST OF MODERN COLLECTIONS, ETC.*

| ABBREVIATION | TITLE OF WORK | EDITION |
| --- | --- | --- |
| A. Épig. | L'Année Épigraphique | Paris 1888– |
| agrim. | Corpus Agrimensorum | Thulin T 1913 |
| anth. | Anthologia Latina | Riese T 1894 |
| Atel. | Fabulae Atellanae | see com. |
| BGU | Aegyptische Urkunden aus d. Kgl. Museen zu Berlin. Griechische Urkunden | Berlin 1895–1926 |
| BIFAO | Bulletin de l'Institut français d'Archéologie orientale | Cairo 1901– |
| BMCI | Coins of the Roman Empire in the British Museum | Mattingly et al. London 1923– |
| BMCR | Coins of the Roman Republic in the British Museum | Grueber London 1910 |
| CIL | Corpus Inscriptionum Latinarum | Berlin 1863– |
| com. | Comicorum Romanorum Fragmenta | Ribbeck T 1898 |
| CPL | Corpus Papyrorum Latinarum | Cavenaile Wiesbaden 1958 |
| dig. | Digesta Iustiniani | Mommsen–Krueger Berlin 1922 |
| FJRA | Fontes Iuris Romani Anteiustiniani | Riccobono et al. Florence 1940–3 |
| Font. iur. | Fontes Iuris Romani Antiqui | Bruns Tübingen 1909 |
| G.L. | Grammatici Latini | Keil Leipzig 1855–80 |
| gram. | Grammaticae Romanae Fragmenta | Funaioli T 1907 |
| grom. | Die Schriften der römischen Feldmesser | Lachmann et al. Berlin 1848 |
| hist. | Historicorum Romanorum Reliquiae | Peter T 1914, 1906 |
| Inscr. Corinth. | Corinth. 8 | pt. 2 Cambridge (Mass.) 1931, pt. 3 Princeton (N. J.) 1966 |
| Inscr. Dessau | Inscriptiones Latinae Selectae | Dessau Berlin 1892–1916 |
| Inscr. Rev. Arch. | (Inscription in) Revue Archéologique | Paris 1844– |
| iur. | Iurisprudentia Anteiustiniana | Seckel–Kuebler T 1908 |
| mim. | Mimi | see com. |
| orat. | Oratorum Romanorum Fragmenta | Malcovati Turin 1930 |
| P. Freib. | Mitteilungen aus der Freiburger Papyrussammlung | Heidelberg 1914 |
| P. Gen. | Les Papyrus de Genève | Nicole Geneva 1896–1900 |
| P. Mich. | Michigan Papyri | Dunlap et al. Ann Arbor 1936– |
| P. Oxy. | The Oxyhrynchus Papiri | Grenfell et al. London 1898– |
| P. Ryl. | Catalogue of the Greek and Latin Papyri in the J. Rylands Library | Manchester 1911–52 |
| P. Tebt. | The Tebtunis Papyri | Grenfell et al. London 1902–38 |
| pall. | Fabulae Palliatae | see com. |
| poet. | Fragmenta Poetarum Latinorum | Morel T 1927 |
| praat. | Fabularum Praetextarum Reliquiae | see trag. |
| Raccolta Lumbroso | Raccolta di scritti in onore di Giacomo Lumbroso | Milan 1935 |
| SB | Sammelbuch griechischer Urkunden aus Ägypten | Berlin 1913– |
| Stud. Pal. | Studien zur Paläographie und Papyruskunde | Wessely Leipzig 1901–24 |
| tog. | Fabulae Togatae | see com. |
| trag. | Tragicorum Romanorum Fragmenta | Ribbeck T 1897 |

