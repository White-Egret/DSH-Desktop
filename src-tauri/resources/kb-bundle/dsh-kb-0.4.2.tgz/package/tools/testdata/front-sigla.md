# GENERAL ABBREVIATIONS

Note: Many abbreviations appear in plural form with the addition of 's', e.g. abbrevs., compars., gds., phrs., qus. They are not listed separately below.

| a. | adjective | arg. lib. | argumentum libri, the synopsis or |
| --- | --- | --- | --- |
| abbrev. | abbreviation, abbreviated |  | summary (of a book) |
| abl. | ablative | Arm. | Armenian |
| absol. | absolute(ly) | AS | Anglo-Saxon |
| abst. | abstract(ly) | astrol. | astrology, astrological |
| abus. | abusive | astron. | astronomy, astronomical |
| acc. | accusative, according to | attrib. | attributive(ly) |
| act. | active(ly) | Av. | Avestan |
| ad. | (in etym.) adaptation of |  |  |
| ad fin. | ad finem, towards the end | Bulg. | Bulgarian |
| adj. | adjective |  |  |
| adjl. | adjectival | c. | circiter, about |
| adv. | adverb | card. | cardinal |
| advl. | adverbial(ly) | catachr. | catachrestically |
| affect. | affectionate(ly) | cf. | confer, compare |
| agr. | agriculture | cj. | conjecture(d) |
| allus. | allusive | cjj. | conjectures |
| anal. | analogy | cl. | clause |
| app. | apparently | class. | classical |
| appel. | appellative(ly) | cls. | clauses |
| appos. | apposition | cod. | codex |
| Arab. | Arabic | codd. | codices |
| arch. | archaic | cogn. | cognate |
| archit. | architecture | collat. | collateral |


| collect. | collective(ly) | gd. | gerund |
| --- | --- | --- | --- |
| colloq. | colloquial | gdve. | gerundive |
| comp. | compound, composition | gen. | genitive |
| compar. | comparative | geog. | geography, geographical |
| compl. | complement | geom. | geometry, geometrical |
| concr. | concrete | Ger. | German |
| conj. | conjunction, conjugation | Gk | Greek |
| const. | construction, construed with | Goth. | Gothic |
| contemp. | contemporary with | gram. | grammar, grammatical |
| contempt. | contemptuous(ly) |  |  |
| contr. | contracted | Heb. | Hebrew |
| Corn. | Cornish | heter. | heteroclite |
| correl. | correlative | hyperb. | hyperbolically |
| cos. | consul |  |  |
|  |  | IE | Indo-European |
| dat. | dative | imp. | imperative |
| def. | definition | impers. | impersonal |
| dep. | deponent | impf. | imperfect |
| deriv. | derivative, derivation | inanim. | inanimate |
| dim. | diminutive | inc. | incerta, incertorum, uncertain |
| dir. | direct | ind. | indicative |
| dist. | distinguish, distinguishable, | indcl. | indeclinable |
|  | distinct | indef. | indefinite |
| disyll. | disyllabic | indir. | indirect |
| dub. | dubi(us), doubtful | inf. | infinitive |
|  |  | inscr. | inscription |
| Ed. | edict | instr. | instrument(al) |
| ed. | editor, edited by | interj. | interjection |
| edd. | editors | interp. | interpolated |
| ellipt. | elliptical(ly) | interr. | interrogative |
| emph. | emphasis, emphatic | intr. | intransitive |
| Eng. | English | Ir. | Irish |
| ep. | epithet | iron. | ironical(ly) |
| equiv. | equivalent | irreg. | irregular(ly) |
| erron. | erroneous(ly) | It. | Italian |
| esp. | especially |  |  |
| Etr. | Etruscan | L. | Latin |
| etym. | etymology | l. | line |
| euphem. | euphemism, euphemistic(ally) | l.c. | loco citato, in the passage already cited |
| ex. | example | leg. | legal(ly), in legal use |
| exc. | except; (in refs.) excerpta, excerpts | Let. | Lettish |
| exclam. | exclamation, exclamatory | LG | Low German |
| expl. | explanation, explained | lit. | literal(ly) |
| expr. | expression, expressing, expressed | Lith. | Lithuanian |
| ext. | externa, foreign | loc. | locative |
| exx. | examples | log. | logic(al) |
| f. | feminine | m. | masculine |
| facet. | facetious(ly) | masc. | masculine |
| fem. | feminine | math. | mathematics |
| fig. | figurative(ly) | med. | medical |
| f.l. | falsa lectio, false reading | metath. | metathesis |
| foll. | following, followed | meton. | metonymical(ly) |
| fr. | fragment | MHG | Middle High German |
| Fr. | French | mil. | in military usage |
| freq. | frequent(ly) | mod. | modern |
| fut. | future | monosyll. | monosyllabic |
|  |  | mus. | musical, in music |
| Gael. | Gaelic | mythol. | mythology, mythological |
| Gall. | Gallic |  |  |


| n. | neuter | pros. | (in) prosody |
| --- | --- | --- | --- |
| naut. | nautical(ly) | prov. | proverb, proverbial(ly) |
| neg. | negative |  |  |
| neut. | neuter | qu. | question |
| NHG | New High German | quasi-concr. | quasi-concrete |
| nom. | nominative | quot. | quotation |
| num. | numeral |  |  |
| O | Old (of language) | ref. | reference, referring |
| obj. | object(ive) | refl. | reflexive |
| obs. | obsolete | rel. | relative |
| obsc. | obscene | relig. | (in) religion, religious |
| OBulg. | Old Bulgarian | ret. | retained |
| occ. | occasional(ly) | rhet. | in rhetoric |
| OCorn. | Old Cornish | Russ. | Russian |
| OE | Old English |  |  |
| OHG | Old High German | S.C. | Senatus Consultum |
| OIce. | Old Icelandic | sc. | scilicet |
| OIr. | Old Irish | scr. ex. | scriptura exterior, outer writing |
| OLith. | Old Lithuanian | scr. int. | scriptura interior, inner writing |
| ON | Old Norse | sg. | singular |
| onomat. | onomatopoeic(ally) | sim. | similar |
| opp. | opposite | Skt | Sanskrit |
| ord. | ordinal | sp. | speech |
| orig. | origin, original(ly) | spec. | specific(ally), specified |
| orthog. | orthography | sq. | et sequens, and following |
| ORuss. | Old Russian | sub. cl. | subordinate clause |
| Osc. | Oscan | subj. | subject(ive); subjunctive |
| OSl. | Old (Church) Slavonic | suff. | suffix |
|  |  | sup. | supine |
| parenth. | parenthetical(ly) | superl. | superlative |
| part. | partitive(ly) | surv. | (in) surveying |
| pass. | passive(ly) | s.v.l. | si uera lectio, if the reading is correct |
| perh. | perhaps | s.vv.ll. | si uerae lectiones, if the readings are |
| periph. | periphrastic(ally) |  | correct |
| Pers. | Persian | syll. | syllable |
| pers. | person | synec. | synecdoche |
| pf. | perfect |  |  |
| Pg. | Portuguese | tech. | technical(ly) |
| phil. | in philosophy | term. | termination |
| phon. | phonetic(ally) | tm. | (in) tmesis |
| phr. | phrase | topog. | topographical(ly) |
| pl. | plural | tr. | transitive |
| pleon. | pleonastic(ally) | transf. | (in) transferred (sense) |
| plpf. | pluperfect | transf. ep. | transferred epithet |
| poet. | poetic | transl. | translating, translation of |
| poss. | possessive | trisyll. | trisyllabic |
| ppl. | participial |  |  |
| pple. | participle | Umb. | Umbrian |
| pr. | preface, proem, prologue | unkn. | unknown |
| praet. | praetor | usu. | usual(ly) |
| prec. | preceding, preceded |  |  |
| pred. | predicate, predicative(ly) | var. | variant (of) |
| pregn. | pregnant(ly) | vb. | verb |
| prep. | preposition | vbl. | verbal |
| pres. | present | v.l. | uaria lectio, variant reading |
| prob. | probably | voc. | vocative |
| prol. | proleptic | vv.ll. | uariae lectiones, variant readings |
| pron. | pronoun, pronominal |  |  |
| prop. | proper(ly) | w. | with |
