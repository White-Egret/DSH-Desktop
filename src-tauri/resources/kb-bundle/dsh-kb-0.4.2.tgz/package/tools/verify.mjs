#!/usr/bin/env node
/**
 * 工程门禁（P3-F1 / 方案 #49）：跑测试并验证「测试数没有悄悄变少」。
 *
 * 为什么需要：`npm test` 只报「这次跑的都过了」。一个 40 条测试的文件被删掉、
 * 或者里面整块被注释掉，退出码依然是 0。这就是 dsh-rofm 踩过的坑
 * （「A stale/low floor can no longer let a 53-test file be deleted while the
 * gate still passes」）——它的反证：删掉一个 53-test 文件 → FAIL
 * （expected ≥1026, got 973）。
 *
 * 机制（抄 rofm 的机制，不抄它 2,665 行的体量）：
 *   1. 跑 `node test/run-all.mjs`，解析 `ℹ tests N` / `ℹ fail N` / `ℹ skipped N`；
 *   2. 跑 `python tools/test_ingest.py`，解析 `Ran N tests` / `OK|FAILED`；
 *   3. **静态扫描**：数 `test/*.test.mjs` 里的 `test(` 声明数与
 *      `tools/test_ingest.py` 里的 `def test_` 数；
 *      下限取 `max(基线记录值, 声明数 × 0.98)`。
 * 第 3 条是门禁的灵魂：只有记录值会被「忘了更新 baseline」骗过，两者交叉验证
 * 才能同时拦住「删测试」与「漏更新」。
 *
 * 刻意不换 runner：同进程 runner 有理由（`node --test` 每文件起子进程，在受限
 * 沙箱里 EPERM）。门禁只需要能解析出总数。
 *
 * 用法：node tools/verify.mjs [--no-run]
 *   --no-run  只做静态扫描（不跑测试），用于快速自检
 */
import { spawnSync } from 'node:child_process'
import { closeSync, mkdtempSync, openSync, readFileSync, readdirSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const TOOLS = dirname(fileURLToPath(import.meta.url))
const ROOT = dirname(TOOLS)
const TEST_DIR = join(ROOT, 'test')

const args = new Set(process.argv.slice(2))
const noRun = args.has('--no-run')

/**
 * 跑一个子进程并把输出收回来。
 *
 * **不能**用默认的 `stdio: 'pipe'`：受限沙箱里名为管道的 stdio 会 EPERM
 * （「programs cannot open named pipes」）。改成把 stdout/stderr 重定向到一个
 * 临时文件，进程结束后读回来——既不碰管道，也拿得到全文。
 *
 * 日志目录**仓库内 .tmp 优先**（P3.1 补）：沙箱 runner 会把自己的平台临时
 * 目录注入 TMP/TEMP 且覆盖外部设置，而那个目录的 ACL 不一定放行受限令牌
 * ——mkdtemp 直接 EPERM。仓库内目录跨会话稳定。
 */
function pickTmpDir() {
  const repoTmp = join(ROOT, '.tmp')
  try {
    mkdirSync(repoTmp, { recursive: true })
    return repoTmp
  } catch {
    return process.env.TMP || process.env.TEMP || tmpdir()
  }
}
const LOG_DIR = mkdtempSync(join(pickTmpDir(), 'kb-verify-'))
let logSeq = 0

function runCaptured(exe, argv) {
  logSeq += 1
  const logPath = join(LOG_DIR, `run-${logSeq}.log`)
  const fd = openSync(logPath, 'w')
  try {
    const r = spawnSync(exe, argv, {
      cwd: ROOT,
      stdio: ['ignore', fd, fd],
      timeout: 900000,
      env: { ...process.env, PYTHONIOENCODING: 'utf-8' },
    })
    const out = readFileSync(logPath, 'utf8')
    return { error: r.error, status: r.status, signal: r.signal, out }
  } finally {
    closeSync(fd)
  }
}

function cleanupLogs() {
  try {
    rmSync(LOG_DIR, { recursive: true, force: true })
  } catch { /* 清不掉临时日志不影响判定 */ }
}

function fail(msg) {
  cleanupLogs()
  console.error(`\n❌ 门禁失败：${msg}`)
  process.exit(1)
}

function readBaseline() {
  try {
    return JSON.parse(readFileSync(join(TOOLS, 'gate-baseline.json'), 'utf8'))
  } catch (error) {
    fail(`读不到 tools/gate-baseline.json：${error.message}`)
  }
}

/** 静态扫描：数测试声明数。lower bound = max(基线, 声明数 × 0.98)。 */
function countDeclared() {
  const nodeFiles = readdirSync(TEST_DIR).filter((f) => f.endsWith('.test.mjs'))
  let nodeTests = 0
  const perFile = []
  for (const file of nodeFiles) {
    const src = readFileSync(join(TEST_DIR, file), 'utf8')
    // 只数行首（允许缩进）的 test( 声明，避免把注释里的示例算进去
    const n = (src.match(/^\s*test\(/gm) ?? []).length
    nodeTests += n
    perFile.push(`${file}: ${n}`)
  }
  const pySrc = readFileSync(join(TOOLS, 'test_ingest.py'), 'utf8')
  const pyTests = (pySrc.match(/^\s*def test_/gm) ?? []).length
  return { nodeTests, pyTests, perFile, nodeFiles: nodeFiles.length }
}

function runNode() {
  const r = runCaptured(process.execPath, ['test/run-all.mjs'])
  if (r.error) fail(`跑 node 测试失败：${r.error.message}`)
  const out = r.out
  const pick = (label) => {
    const m = out.match(new RegExp(`ℹ ${label} (\\d+)`))
    return m ? Number(m[1]) : null
  }
  return {
    tests: pick('tests'), pass: pick('pass'), failCount: pick('fail'), skipped: pick('skipped'),
    exitCode: r.status,
    raw: out,
  }
}

function runPython() {
  const exe = process.env.PYTHON || 'python'
  const r = runCaptured(exe, ['tools/test_ingest.py'])
  if (r.error) fail(`跑 python 测试失败（缺 python？可用 PYTHON 环境变量指定）：${r.error.message}`)
  const out = r.out
  const m = out.match(/^Ran (\d+) tests?/m)
  const ok = /^OK\b/m.test(out)
  return {
    tests: m ? Number(m[1]) : null,
    ok,
    exitCode: r.status,
    raw: out,
  }
}

const baseline = readBaseline()
const declared = countDeclared()
console.log('静态扫描（测试声明数）：')
for (const line of declared.perFile) console.log(`  · test/${line}`)
console.log(`  · tools/test_ingest.py: ${declared.pyTests}`)

const nodeFloor = Math.max(baseline.minNodeTests, Math.floor(declared.nodeTests * 0.98))
const pyFloor = Math.max(baseline.minPythonTests, Math.floor(declared.pyTests * 0.98))
console.log(`\n下限：Node ≥ ${nodeFloor}（基线 ${baseline.minNodeTests} / 声明 ${declared.nodeTests}）`)
console.log(`      Python ≥ ${pyFloor}（基线 ${baseline.minPythonTests} / 声明 ${declared.pyTests}）`)

if (noRun) {
  console.log('\n（--no-run：跳过实际执行，只做静态扫描）')
  cleanupLogs()
  process.exit(0)
}

// 子测试进程的临时目录：run-all.mjs 自己会重定向到仓库 .tmp（P3.1 补），
// 但 Python 侧的 TMP 仍由这里保证指向同一处——统一、可预期。
// 之前那段「if (!env.TMP) 才设」被沙箱注入的 TMP 顶掉（runner 总会注入），
// 所以这里无条件指向仓库 .tmp。
process.env.TMP = pickTmpDir()
process.env.TEMP = process.env.TMP

console.log('\n执行 Node 测试…')
const node = runNode()
console.log(`  ℹ tests ${node.tests ?? '?'} / pass ${node.pass ?? '?'} / fail ${node.failCount ?? '?'} / skipped ${node.skipped ?? '?'}`)
if (node.tests === null) {
  console.error(node.raw.split('\n').slice(-25).join('\n'))
  fail('解析不出 Node 测试总数（runner 输出格式变了？）')
}
if ((node.failCount ?? 0) > 0) {
  console.error(node.raw.split('\n').slice(-40).join('\n'))
  fail(`Node 测试有 ${node.failCount} 条失败`)
}
if (node.tests < nodeFloor) {
  fail(`Node 测试数 ${node.tests} < 下限 ${nodeFloor}——有测试被删或没被 runner 收进来`)
}
if ((node.skipped ?? 0) > (baseline.maxSkipped ?? 0)) {
  fail(`Node 跳过 ${node.skipped} 条 > 允许 ${baseline.maxSkipped}——跳过等于没测`)
}

console.log('\n执行 Python 测试…')
const py = runPython()
console.log(`  Ran ${py.tests ?? '?'} tests${py.ok ? ' — OK' : ''}`)
if (py.tests === null) {
  console.error(py.raw.split('\n').slice(-25).join('\n'))
  fail('解析不出 Python 测试总数')
}
if (!py.ok || py.exitCode !== 0) {
  console.error(py.raw.split('\n').slice(-40).join('\n'))
  fail('Python 测试未通过')
}
if (py.tests < pyFloor) {
  fail(`Python 测试数 ${py.tests} < 下限 ${pyFloor}——有测试被删`)
}

console.log(`\n✅ 门禁通过：Node ${node.tests} ≥ ${nodeFloor}，Python ${py.tests} ≥ ${pyFloor}，跳过 0`)
cleanupLogs()