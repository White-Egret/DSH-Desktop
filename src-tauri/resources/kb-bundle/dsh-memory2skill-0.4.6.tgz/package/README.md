# dsh-memory2skill

DSH 插件：**记忆 + 半自动技能进化**。

它逐字记录你对 Agent 的纠正，在限定范围内数出重复模式，按写作规范起草 SKILL.md，用历史轨迹回放验证草稿——最后由你下令才写入技能目录。

发现、起草、验证都可以自动。**写入技能目录只有一个入口**：你明确说出要保存之后，agent 调 `memory2skill_commit` 时宿主还会弹一次审批，你放行才会落盘。没有模型可自报的「用户已确认」参数——那种布尔闸门模型自己就能填 true。

## 四个词

| 词 | 含义 | 在哪个文件 |
|---|---|---|
| **雷达** | 在某个项目/主题里数出重复模式，产出候选 | `src/radar.ts` |
| **宪法** | 起草时强制套用的写作规范（源自 Matt Pocock 的 writing-for-agents） | `assets/constitution.md` + `src/constitution.ts` |
| **门禁** | 草稿在历史逐字记录上回放，通过才递到你面前 | `src/gate.ts` |
| **逐字** | 原始轨迹原样存储、不摘要——门禁的回归测试靠它成立 | `src/store.ts` |

另外两个词贯穿全程：**项目**（project，代码仓库或工作目录）与**主题**（topic，项目里的一个领域）。雷达只在同一项目/主题内找模式，草稿的触发边界也据此收窄。

## 安装

```bash
npm install          # 只为编译期类型检查，不进发布包
npm run build        # tsc → lib/，然后内联宿主依赖到 lib/vendor/
npm run setup        # 自检：模块、数据库、FTS5、技能目录、交互 SKILL
npm pack             # 产出 dsh-memory2skill-0.1.0.tgz
```

然后把插件挂到 profile：

```bash
dsh plugin --profile web add <path-to>/dsh-memory2skill-0.1.0.tgz
```

或手工在 profile 的 `cordis.patch.yml` 里加一层：

```yaml
- insert:
    - id: memory2skill
      name: 'dsh-memory2skill'
      config: {}
```

重启 DSH 后，Agent 会看到 7 个 `memory2skill_*` 工具。

> **为什么构建要内联宿主依赖。** profile 里安装的插件只解析自己的 `dependencies`，dsh 不再把 bundle 携带的包投影进 profile。所以 `import { defineTool } from '@deepseek-ai/dsh-tools'` 在用户机器上会直接 `ERR_MODULE_NOT_FOUND`——尽管它在开发机跑得好好的。`scripts/vendor.mjs` 把 `defineTool` 实际可达的模块链复制进 `lib/vendor/` 并把裸包名改写成相对路径，插件因此零运行时依赖、安装时不碰 registry。
>
> 这个陷阱是 `scripts/verify-pack.mjs` 抓出来的：它在干净目录里 import 发布态产物。开发态永远发现不了它。**改完代码请跑 `node scripts/verify-pack.mjs <tgz>`，不要只看开发机上的测试。**


## 工具

| 工具 | 作用 | 写盘 |
|---|---|---|
| `memory2skill_remember` | 手动写入一条逐字记录（项目/主题 + 原文 + 可选 target/baseline 标签） | 只写库 |
| `memory2skill_scan` | 雷达：扫出候选清单（id、摘要、次数、证据片段） | 只写库 |
| `memory2skill_evidence` | 按 id 取回逐字原文——草稿「依据」小节的回查入口 | 否 |
| `memory2skill_draft` | 宪法：把候选装配成 SKILL.md 草稿 | 否 |
| `memory2skill_validate` | 门禁：回放验证，出「修复 / 回归」报告 | 否 |
| `memory2skill_commit` | **唯一写入口**：写入 `<dshHome>/skills/<name>/SKILL.md`；每次调用先经宿主审批弹窗，拒绝则不执行 | **是** |
| `memory2skill_prune` | 列出低频技能供你决定去留（从不删除） | 否 |
| `memory2skill_status` | 自检：库路径、记录数、FTS5 可用性**与原因**、技能目录 | 否 |

## 日常用法

安装后，交互 SKILL 已经装进技能目录。你只需要说一句人话：

> 扫一下最近有哪些重复的纠正。

Agent 会走这个循环：

```
扫描 → 列出候选（你挑一个）
     → 起草（你看到完整草稿，含待补的 TODO）
     → 补齐做法与反例（用你和证据的原话）
     → 过门禁（你看到「修复 N 条 / 回归 0 条」）
     → 问你保不保存
     → 你说「确认保存为 xxx」
     → commit 弹审批 → 你放行
     → 写入技能目录，下一步生效
```

任一步你说「先不做了」，就停在那里。草稿留在会话里，不会落盘。审批弹窗拒绝（或直接关掉）同样不落盘。

## 一次真实运行的记录

下面是 `node scripts/demo.mjs` 的实际输出（临时目录，不碰你的库）。场景：用户在两天里 3 次纠正同一类问题，同期有 2 条「当初正常」的记录。

**1. 雷达扫出候选**

```
1. [pat_bd850eedd2b5] my-nextjs-app / react-hooks
   出现 3 次  分数 5.538
   摘要：写 useEffect 订阅事件时要 return 一个清理函数，卸载时取消订阅
   证据：
     #1 useEffect 里的订阅必须在 return 里写清理函数，否则组件卸载后还在监听
     #2 useEffect 加订阅时忘了写 return 清理函数，导致内存泄漏
     #3 写 useEffect 订阅事件时要 return 一个清理函数，卸载时取消订阅
```

**2. 起草（不写盘）**

```
建议技能名：react-effect-cleanup
结构校验：通过
待办：仍有 5 处 TODO 待补（结构合格 ≠ 内容合格，commit 前需人工补齐）

此时技能目录内容：（空）——起草不写盘
```

**3. 人补齐两节后过门禁**

```
门禁结论：通过

修复的失败案例：3/3
  ✓ #1 useEffect 里的订阅必须在 return 里写清理函数，否则组件卸载后还在监听
  ✓ #2 useEffect 加订阅时忘了写 return 清理函数，导致内存泄漏
  ✓ #3 写 useEffect 订阅事件时要 return 一个清理函数，卸载时取消订阅

受影响的既有案例：0/2（应为 0）
  ✓ #4 这个 CSS 变量的命名要改成 kebab-case
  ✓ #5 数据库迁移执行前必须先备份
```

**4. 人下令 commit，落盘**

```
写入：true
路径：<skillsDir>/react-effect-cleanup/SKILL.md
落盘内容与定稿一致：是
```

**5. 自检**

```
记录 5 条 / 候选 1 个 / 技能 1 个
技能目录：react-effect-cleanup
```

**反面对照**——门禁拦下一份空泛草稿：

```
门禁结论：未通过
修复的失败案例：0/3
修改建议：
  - 改 `## 触发条件`：草稿与所有 target 案例都不重合……当前条件只写了作用域或
    「写任何代码时」这类空泛表述，没有可判定的具体现象——把证据里的报错文本、
    字段名、函数名写进去。
```

## 设计取舍（为什么是这样）

### 为什么按项目/主题分组，而不是语义聚类

最初的实现按 bigram-Jaccard 做聚类，阈值 0.32。在本机真实的 77 条记忆上实测：

```
同主题记录的相似度分布：p50=0.023  p90=0.113  最高=0.202
```

**人描述同一件事的两次纠正，字面重合度往往不到 0.2。** 语义相近不等于字面相近，任何靠字面阈值聚类的做法在这个分布上都会失效。

所以改成「项目/主题分组 + 条数阈值」：分组键是人在记录时就给好的语义标签，比模型自动打 tag 更可靠、可解释、可复现。这跟 dsh-evolve 用 tag 分组、用次数触发是同一个思路。

### 为什么草稿是装配的，不是模型自由发挥

同一批证据每次生成不同文本，人无法比对，门禁也无法回归。装配式生成保证同一候选两次生成结果一致（除时间戳），**你审的是内容，不是随机性**。

需要人判断的部分（`## 做法` 与 `## 反例`）留成显式 TODO——生成器不臆造规则。

### 门禁为什么只看「触发条件」一节

看整篇会自伤：`## 反例` 里写的就是「不该触发」的输入，把它算进触发面，那些词反而让反例案例被误判为命中。实测：一份好草稿因此永远过不了门禁。

判定用**覆盖率**而非 Jaccard：草稿必然比案例长，Jaccard 会被草稿长度稀释，导致「什么都判不触发」——那是一个假装能失败的闸门。

阈值 0.25 由夹具实测确定：紧扣主题的触发条件对三条 target 覆盖率 0.304 / 0.375 / 0.412，对无关 baseline 是 0.000。

### 门禁能抓两类不同的失败

- **覆盖不足**：触发条件没抓住当初出错的现象，一条 target 都命中不了。
- **判定空泛**：条件只写了作用域或「写任何代码时」，宽到连 target 都覆盖不了，baseline 自然也命中不了——两边都是 0，看起来像「什么都没影响」，其实是份什么都没说的技能。门禁靠「空泛」这条正面特征把它认出来。

### 存储用 node:sqlite，不用 better-sqlite3

插件因此零运行时依赖，`npm i` 不编译 C++。FTS5 是**派生索引**，打开时按缺口对账——一致的零成本直通，缺行补、孤儿删，只有计数对不上（对账本身失败）才全量重建；不可用时自动退化为纯 bigram 召回——功能照常。

> 踩过的坑：FTS5 用 `content=''` 的外部内容表时，跨连接复用的建表会静默失败,导致重开数据库后索引全空。已改为普通 FTS5 表 + 自管 rowid，并有回归测试。

**降级要带原因。** `memory2skill_status` 不只报 `ftsAvailable: false`，还报 `ftsError`——因为「降级了」和「为什么降级」是两件事：数据库被宿主进程占成只读、FTS5 没编译进 node、主动配置关闭，三种情况的处置方式完全不同。只报 false 会让人对着错误的方向查。实测就撞过一次只读库，当时工具只说「不可用」，花了几个来回才定位。

### 技能状态没有假值

`skills.status` 只允许两个值：`committed`（写入技能目录时）与 `archived`（人归档时）。两者都有真实的写入路径。

schema 注释里曾经写着 `draft / validated / committed / pruned` 四态，但草稿只返回文本、不落库，`prune` 是只读的——后两个状态**从来没有任何代码写过**。那正是「文档说有、代码永远不写」的假状态：看的人以为有历史可查，实际查不到。现在写入第三个值会被当场拒绝，并有测试守着。

判据是：**加状态之前先问一句「谁在写它」**。没有写入路径的状态不是预留，是谎言。

### 技能带得回原文（「依据」小节）

草稿的最后一节是 `## 依据`，列出候选 id 和每条逐字记录的 `ref: #<id>`：

```markdown
## 依据

本技能由 dsh-memory2skill 从下列逐字记录派生（候选 `pat_bd85...`，3 条证据）。
技能是索引，这些记录才是本体——怀疑这条规则时，按 id 回查原文：

- `ref: #11` · 2026-09-27 · correction
- `ref: #12` · 2026-09-27 · correction
- `ref: #13` · 2026-09-28 · failure
```

回查用 `memory2skill_evidence id=11`，返回那条记录的**逐字原文**，不截断不改写。

为什么要有这一节：技能是从逐字记录**派生**的，但技能落盘之后，人和 agent 看到「用户在这个主题上纠正过 5 次」，没有任何办法核实是哪 5 次。门禁验的是「能不能修好历史案例」，验不了「这条规则凭什么存在」。

依据一节只放 id，不复制原文——技能每轮都可能被读进上下文，而原文在库里，一条命令就能取回。

这个模式借自 [dsh-agent-soul](https://github.com/cyanwell/dsh-agent-soul) 的「门牌」纪律：派生物必须带得回一手材料，且**拿不到精确位置时宁可说「未知」也不要猜**——「一个错的指针会让你以为能找到，于是不去找」。

### WAL/synchronous 设置不做静默降级

打开数据库时 `journal_mode=WAL`、`synchronous=NORMAL` 设置后会立刻读回校验。SQLite 会**静默忽略**它执行不了的 pragma（网络盘、FAT/exFAT、只读目录上 WAL 不生效），同步写会退回全量 fsync——所以读回的值不对就直接抛错，数据库打不开比跑在错误模式上好修。`:memory:` 库不校验（没有持久化可言）。

### 后台捕获只记人类输入，且挡掉噪声

`user/message` 事件里混着插件自己注入的合成消息。不过滤 `source.kind === 'user'` 就会把本插件注入的文本再记一遍，形成自激。有测试覆盖。

即使过滤了合成消息，会话里仍有大量**元指令**——「扫一下最近有哪些重复的纠正」「确认保存」——它们指挥的是本插件，不是对代码的纠正。记进去会做两件坏事：稀释雷达的信噪比（雷达按条数触发，废话会凑成「重复」），污染草稿的证据节。

`src/capture.ts` 挡掉三类，策略是**只挡确定的噪声**：

| 挡掉 | 例子 |
|---|---|
| 纯元指令 | 「扫一下最近有哪些重复的纠正」「确认保存」 |
| 纯确认/寒暄 | 「好」「可以」「继续」「ok」 |
| 太短 | 少于 12 字符（可配 `minCaptureChars`） |

关键在「纯」：`「扫一下 useEffect 清理函数的问题，我怀疑还有别的坑」` 带了实质内容，照常记录。这条规则有 8 个用例，其中一组专门测**不许误挡真实纠正**——一条真纠正被挡掉就永远失去被结晶的机会，而一条元指令混进去最多是人手动跳过。

### 会话捕获有上限，不无限攒

即使挡掉了噪声，会话捕获仍会随时间无界增长——逐字记录是整段原文，「无限攒日志」对一个每条都要参与相似度比对的库不是小代价。单个（project, topic）范围内的捕获行数由 `captureMaxRecords`（默认 500）封顶：满了以后最老的未回填捕获行先删，腾位再记；雷达的触发窗口本来就只有 `days`（默认 30 天），更老的闲聊留着的唯一效果是稀释候选和膨胀数据库文件。

两类记录**不**受这个上限影响：手动 `remember` 写入的纠正（你明确下的指令），以及已经回填成 pattern 证据的行（删了等于悄悄改门禁的回归集——宁可超额也不丢证据）。设为 `0` 可以关闭上限（不建议）。

## 配置

```yaml
- id: memory2skill
  name: 'dsh-memory2skill'
  config:
    dbPath: 'D:/DSH/Home/memory2skill/memory2skill.db'  # 默认 <dshHome>/memory2skill/
    skillsDir: 'D:/DSH/Home/skills'                      # 默认 <dshHome>/skills
    capture: true                                        # 后台记录人类输入
    minCaptureChars: 12                                  # 短于这个字数不记
    captureMaxRecords: 500                               # 单范围捕获行数上限；弄满删最老的未回填行，0 关闭
    fts: true                                            # FTS5 派生索引
    defaultProject: 'default'                            # 手动记录的默认项目
    minObservations: 3                                   # 雷达：几条算候选
    similarity: 0.15                                     # 雷达：子簇拆分门槛
    days: 30                                             # 雷达：看最近几天
```

### 从 v0.2 升级

v0.3 把 `wing` / `room` 改名为 `project` / `topic`。插件打开旧库时会自动迁移列名（`ALTER TABLE ... RENAME COLUMN`），**已有记录一条都不会丢**，包括 `verdict` 标签和 `pattern_id` 关联。

旧索引会先删掉再用新列名重建——不这么做的话，`CREATE INDEX IF NOT EXISTS` 会因同名索引已存在而跳过，留下一个引用旧列名的索引，后续查询直接报 `no such column`。这个坑是迁移测试抓到的。

配置项 `defaultWing` 一并改名为 `defaultProject`。如果你在 profile 里手写过旧键名，改一下即可。

## 数据与隐私

- 记忆库：`<dshHome>/memory2skill/memory2skill.db`（SQLite，本地）
- 记录内容：**你发出的消息原文**，逐字保存，不做摘要
- 会话捕获的原文按 `captureMaxRecords`（默认 500）滚动淘汰；只有手动写入的纠正与门禁证据不受影响
- 不记录模型的输出
- 不联网，不调 LLM

清理：删掉那个 `.db` 文件即可，插件下次启动会重建。

## 开发

```bash
npm run typecheck      # tsc --noEmit
npm run build          # tsc → lib/，再内联宿主依赖
npm test               # 66 个测试，同进程运行
npm run host-check     # 用真 Cordis 上下文加载插件，验证装得进去
npm run verify-skills  # 按 DSH 加载器规则校验产出的 SKILL.md
npm run demo           # 完整跑一遍 README 的 Usage，输出可粘贴的记录
npm run check          # 以上五项串起来
```

`npm test` 用 `test/run-all.mjs` 在当前进程里按顺序 import 各测试文件，而不是 `node --test`：后者每个文件起子进程，在受限沙箱里会以 `EPERM` 失败，失败原因跟被测代码无关。

**改动后必跑 `npm run check`。** 实际被加载的是编译产物 `lib/`（`package.json` 的 main 指向它），而它不进 Git：审阅差异看的是 `src/`，运行生效的是 `lib/`，两者只在 build 后一致。改完忘跑 tsc，就会出现「源码已修、生效的还是旧逻辑」——对 commit 写盘这类安全关键函数尤其如此。

### 三道「开发机看不见」的检查

写完代码、测试全绿，仍然可能装不上或不被加载。这三道各自守一个盲区：

| 命令 | 守什么盲区 | 它抓到过什么 |
|---|---|---|
| `npm run host-check` | 用真 Cordis 加载，而不是假 ctx | `ctx.set('tools')` 在 cordis 4.x 会抛 "cannot set property without provide"，得先 `provide` |
| `npm run verify-skills` | 文件写出去了，但加载器会不会认 | frontmatter 的 `name` 必须 kebab-case、`description` 必填；发现深度只有一层 |
| `node scripts/verify-pack.mjs <tgz>` | 打包后能不能独立跑 | `import '@deepseek-ai/dsh-tools'` 在用户机器上 `ERR_MODULE_NOT_FOUND`——开发机有 node_modules，永远正常 |

打完包记得跑最后一条：

```bash
node scripts/verify-pack.mjs ../dsh-memory2skill-0.1.0.tgz
```

它解开 tgz，在干净目录里 import 发布态产物并跑一遍端到端。

## 许可

插件代码 MIT（见 `LICENSE`）。

`assets/constitution.md` 改写自 Matt Pocock 的 [writing-for-agents](https://github.com/mattpocock/skills/tree/main/skills/productivity/writing-for-agents)（MIT，Copyright (c) 2026 Matt Pocock），顶部保留署名与出处。

设计思路参考了：

- [dsh-evolve](https://github.com/chenzheshushi-commits/dsh-evolve)（MIT）——记忆条目、tag 分组、结晶流程。本项目独立实现，未复制其代码。
- Microsoft SkillOpt 的 *validation-gated updates* 思想——更新前必须在验证集上跑一遍，且不能破坏既有能力。本项目把它落成可复现的静态判定，不训练模型。
- MemPalace 的逐字存储与空间分层隐喻——本项目的 `verbatim` 列与项目/主题两层作用域。
