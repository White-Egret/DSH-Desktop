<!--
  Attribution: derived from Matt Pocock's "writing-for-agents" skill.
  Original: https://github.com/mattpocock/skills (skills/productivity/writing-for-agents/SKILL.md)
  License: MIT, Copyright (c) 2026 Matt Pocock.
  This file is a condensed restatement for the draft generator's use, not a verbatim copy.
-->

# 技能起草宪法（Skill Drafting Constitution）

生成 SKILL.md 草稿时，以下每条都是硬约束。草稿的验收尺子就是这五条，缺一条即不合格。

## 1. 触发边界（pointer 的措辞决定它何时被唤起）

`description` 是模型唯一always-loaded 的指针，措辞而非目标决定它是否被唤起。

- 首词前置：把最能触发联想的词放在 `description` 最前面。
- 一个分支一个触发词：同义改写是同一分支写两遍，合并掉。
- 身份信息交给正文，`description` 只写「这是什么」+「什么时候用」。

## 2. 正例与反例成对（no-op test）

每个技能必须给出：

- 一个**正例**：技能应当生效的具体输入。
- 一个**反例**（no-op test）：看起来像、但不该触发的具体输入。

反例是这道门禁能失败的唯一原因。没有反例的技能无法验证，视同未验证。

## 3. 可预测性

同一输入在同一作用域内产生同一行为。规则写成可判定的条件，不留给模型临场发挥。

- 写「当 X 且 Y 时，做 Z」，不写「尽量注意 Z」。
- 禁止只写禁止项：把「不要做 A」改写成「做 B」。否定式提示会把 A 拉进上下文，反而更容易发生。

## 4. 渐进披露

主文件只放每次都会用到的步骤与判据；细则、长表格、边缘案例推到同目录的附属文件，由正文里一句指针唤起。主文件短，细则深。

## 5. 精简与单一真源

- 每句话只承担一个意思，同一意思只出现一次。
- 不写模型默认就会做的事（no-op 句子）；发现就整句删掉，而不是删字。
- 不复述环境已经声明的事实（脚本命令、目录结构），只记录环境里查不到的约定、原因与坑。

## 输出格式（generator 必须满足）

```markdown
---
name: <kebab-case>
description: <首词前置的触发边界，一句话>
---

# <标题>

## 触发条件
<含 project/topic 限定的可判定条件>

## 做法
<有序步骤>

## 正例
<具体输入 + 期望行为>

## 反例（no-op test）
<看起来像但不应触发的输入 + 期望的「不动作」>
```

缺少 `## 触发条件`、`## 正例`、`## 反例（no-op test）` 任一节的草稿不合格。
