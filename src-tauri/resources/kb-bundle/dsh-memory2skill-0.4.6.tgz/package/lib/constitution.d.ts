/**
 * 宪法约束的草稿生成器。
 *
 * 关键取舍：**不调用 LLM**。生成器是确定性的模板装配 —— 把候选模式的逐字证据
 * 按宪法要求的骨架装成 SKILL.md，并把「需要人来判断」的部分留成显式占位符。
 *
 * 为什么不让模型直接写：草稿要能被人快速审查，而模型自由发挥会让同一批证据每次
 * 生成不同文本，人无法比对、门禁也无法回归。装配式生成保证同一候选两次生成结果
 * 一致（除了时间戳），人审的是内容而不是随机性。
 *
 * 模型仍然参与——在「调用本插件的那个会话」里：Agent 读到草稿后可以按用户的反馈
 * 改写，再交回 commit。生成器负责给出合格的骨架与判据，不假装自己能写出好规则。
 */
import type { Candidate } from './radar.js';
/**
 * 草稿的结构校验结果。
 *
 * 用 `type` 而非 `interface`：它要作为工具返回值穿过 JSON 边界，
 * 而 interface 没有隐式索引签名，会卡在 `JsonValue` 的约束上。
 */
export type DraftCheck = {
    ok: boolean;
    /** 缺失或不合格的条目，每条都是可执行的修改指令。 */
    problems: string[];
};
/** 生成的草稿。 */
export interface Draft {
    /** 建议的技能名（kebab-case）。 */
    name: string;
    /** SKILL.md 全文。 */
    markdown: string;
    /** 结构校验结果。 */
    check: DraftCheck;
}
/**
 * 读取内置宪法。开发态（src/）与发布态（lib/）都要能找到 assets/：
 * 两种情况下 assets 都在包的根目录，与 src|lib 同级。
 */
export declare function loadConstitution(): Promise<string>;
/** 把候选的 project/topic 与高频词拼成 kebab-case 技能名。 */
export declare function suggestName(candidate: Candidate): string;
/** 把中文高频词翻成英文占位，便于 kebab-case 命名；翻不出就返回空。 */
export declare function isAsciiName(name: string): boolean;
/**
 * 装配草稿。
 *
 * 宪法要求的三节（触发条件 / 正例 / 反例）在这里全部生成，但**做法**与**反例**
 * 留成显式的待补占位：这两处必须由人从证据里读出真实规则，装配器不臆造。
 */
export declare function buildDraft(candidate: Candidate, skillName?: string): Draft;
/** 结构校验：宪法要求的节与小节是否齐全，frontmatter 是否合规。 */
export declare function checkDraft(markdown: string): DraftCheck;
/** 草稿里是否还有未补完的 TODO。commit 工具据此要求显式确认。 */
export declare function hasUnfinishedTodos(markdown: string): boolean;
