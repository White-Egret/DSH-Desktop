/**
 * 情景记忆的派生 FTS5 索引。
 *
 * 表里没有正文列：只有摘要（goal / outcome）、指纹（id / workspace / ended_at /
 * ended_kind / chars）、检索 token（toks）与回指权威 JSON 的 body_path。
 * 因此 index.db 可以随时删掉从 JSON 全量重建，detail 与 snippet 都按 body_path
 * 回表读正文。epi.toks 与 epi_fts.toks 是同一份编码 token，前者留作对账。
 *
 * 写 token 与拼 MATCH 查询都必须走 store.ts 导出的 encodeToken/encodeText：
 * 非 ASCII token 会变成 z<hex>，两份转义规则一旦漂移，症状是「表里有数据、
 * 查询不报错、就是零命中」。
 */
import type { SqliteDb } from './store.js';
import type { Episode } from './episodic.js';
export interface EpiSummary {
    id: string;
    workspace: string;
    endedAt: string;
    endedKind: string;
    goal: string;
    outcome: string;
    chars: number;
    toks: string;
    bodyPath: string;
}
export interface RecallHit extends EpiSummary {
    score: number;
    snippet?: string;
}
/** 打开一个 node:sqlite 句柄，类型收窄到 SqliteDb 抽象层。 */
export declare function openSqlite(dbPath: string): Promise<SqliteDb>;
export declare class EpisodicIndex {
    private readonly db;
    readonly root: string;
    readonly dbPath: string;
    private constructor();
    /** 打开（或创建）索引并对账；db 文件缺失时自然走一次全量重建。 */
    static open(root: string): Promise<EpisodicIndex>;
    /**
     * JSON 与索引对账：数目或 id 集合不一致（含孤儿）就全量重建。
     * JSON 永远是真相；索引服从它，绝不反过来用索引补 JSON。
     */
    reconcile(truth: Episode[]): {
        rebuilt: boolean;
        episodes: number;
    };
    /** rowid 由我们指定，epi 与 epi_fts 共用它，避免跨连接复用时影子表失配。 */
    private upsert;
    private nextRowid;
    /** 追加一条（JSON 已经写好后调用），并同步删掉容量上限挤掉的最旧条目。 */
    syncAppend(episode: Episode, removedIds?: string[]): void;
    remove(id: string): void;
    /** 目录层：按 ended_at 倒序，最多 50 条；总数单独回，不把全量塞回上下文。 */
    listIndex(workspace?: string, limit?: number): {
        rows: EpiSummary[];
        total: number;
    };
    /** BM25 召回；MATCH 的 token 与写入共用 encodeToken。 */
    search(query: string, workspace?: string, limit?: number): RecallHit[];
    /** 按 id 取摘要行，detail 据此拿 body_path。 */
    get(id: string): EpiSummary | null;
    /**
     * 从权威 JSON 里找命中词前后各 40 字。
     *
     * 不用 FTS5 的 snippet()：epi_fts 里是 z<hex> 编码 token，截出来是一串
     * 不可读的十六进制；正文只在 JSON，回表是唯一正确的来源。
     */
    snippet(pointer: string, query: string): Promise<string | null>;
    close(): void;
}
