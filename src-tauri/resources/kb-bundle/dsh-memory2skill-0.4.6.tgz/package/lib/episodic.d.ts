/**
 * 情景记忆：一个 turn 的完整快照，权威存储是人可读的 JSON。
 *
 * 为什么 JSON 是真相而 SQLite 是派生的：情景正文会被卸载、移动、Git 跟踪，
 * 用户也应该能用文本编辑器直接翻。索引只放摘要与 token，任何时刻删掉
 * index.db 都必须能从这些 JSON 完整重建。
 *
 * 落盘路径上的每一步都不抛给会话：后台记录失败只让调用方 warn。
 */
/** 一条情景记忆 = 一个 turn 的完整快照。 */
export interface Episode {
    /** 稳定 id：`ep_<入盘时间戳>-<4 位随机>` */
    id: string;
    /** 工作区身份锚点（见 workspaceKey），路径改名后不变 */
    workspace: string;
    /** 记录发生时的绝对路径（路径可能已变，留作参考） */
    workspacePath: string;
    sessionId: string;
    turn: number;
    /** ISO 8601，带本地时区偏移；不要用 toISOString()（那是 UTC） */
    endedAt: string;
    /** completed / aborted / blocked，来自 turn/end 的 reason.kind */
    endedKind: string;
    /** 本 turn 第一条人类消息，截断 300 字 */
    goal: string;
    /** 本 turn 最后一条助手消息，截断 600 字 */
    outcome: string;
    /** 完整正文：user 与 assistant 交替拼接，截断 8000 字 */
    body: string;
    /** body 脱敏前的原始长度，超长截断时供目录层察觉 */
    chars: number;
}
export interface EpisodeFile {
    version: 1;
    workspace: string;
    episodes: Episode[];
}
export declare const MAX_EPISODES = 500;
export declare const MAX_BODY_CHARS = 8000;
export declare const INJECTION_PREFIX = "[\u4E0A\u4E0B\u6587\u63D0\u793A";
/** 从消息 content 块里取纯文本。user 与 assistant 的 content 都是 ContentBlock[]。 */
export declare function contentText(content: unknown): string;
/**
 * 本地时区偏移的 ISO 8601。
 *
 * `toISOString()` 会把本地 8 月 1 日 07:00（UTC+8）记成 7 月 31 日 23:00，
 * 目录层按日期分组时整条记忆就落到前一天。
 */
export declare function localIsoNow(date?: Date): string;
/**
 * 与路径无关的工作区身份。
 *
 * 用 package.json 的 name / git remote 而不是绝对路径：用户改一次文件夹名，
 * 以路径为键会把攒下来的历史全部断开。解析 .git/config 而不跑 git 命令，
 * 是因为宿主不保证装了 git 可执行文件，也不该为一个纯读操作起子进程。
 */
export declare function workspaceKey(dir: string): Promise<string>;
/** 从 INI 风格的 .git/config 里取 [remote "origin"] 的 url。 */
export declare function parseOriginUrl(config: string): string | null;
/** 只留 host/owner/repo，令 git@github.com:a/b.git 与 https://github.com/a/b 归一。 */
export declare function normalizeGitUrl(url: string): string;
export declare function safeWorkspace(workspace: string): string;
export declare function episodeFilePath(root: string, workspace: string): string;
export declare function bodyPath(workspace: string, id: string): string;
/** 列出全部权威 JSON 文件，供打开索引时对账。 */
export declare function listEpisodeFiles(root: string): Promise<string[]>;
export declare function readEpisodeFile(path: string): Promise<EpisodeFile | null>;
/**
 * 人类一句话、助手一句话是否值得成为一轮记忆。
 *
 * 「继续」「好」这类消息没有结论，记进去只会把真正的工作记录挤出 500 条上限。
 * 注入消息另有一道前缀过滤（见 index.ts 的 buffer 累积）：source.kind 的形状
 * 没有跨版本保证，只靠它挡不住「注入 → 记成记忆 → 被召回 → 再注入」的自激。
 */
export declare function shouldRecordEpisode(users: string[], assistants: string[]): boolean;
/** 从 buffer 装配一条 episode；goal / outcome / body 在落盘前统一脱敏。 */
export declare function buildEpisode(input: {
    workspace: string;
    workspacePath: string;
    sessionId: string;
    turn: number;
    endedKind: string;
    users: string[];
    assistants: string[];
    at?: Date;
}): Episode;
/** DSH_HOME 解析与 store.ts::defaultPaths 保持同一约定。 */
export declare function dshHome(env?: NodeJS.ProcessEnv): string;
/**
 * 追加一条 episode，超限时先删权威 JSON 里最旧的，再让调用方同步删索引。
 *
 * 顺序不能反：索引是 JSON 的派生，反向删会在下次重建时把已删条目带回来。
 */
export declare function appendEpisode(root: string, episode: Episode): Promise<{
    file: EpisodeFile;
    removedIds: string[];
    path: string;
}>;
/** 按 body_path 的 `<file>#<id>` 回权威 JSON 读正文。 */
export declare function readEpisodeBody(root: string, pointer: string): Promise<{
    body: string;
    episode: Episode;
} | null>;
