/**
 * 门禁：草稿先在历史轨迹上回放，通过才递到人面前。
 *
 * 借鉴 Microsoft SkillOpt 的核心思想（validation-gated updates：更新前必须在验证集
 * 上跑一遍，且不能破坏既有能力），但落地方式是**文本可判定的**，不训练、不调模型：
 *
 * - **回归集**来自逐字记录本身：`verdict='target'` 的记录是「当初失败、这条技能本该
 *   拦住」的案例；`verdict='baseline'` 是「当初正常、这条技能不该改变」的案例。
 * - **回放**是对草稿做静态判定：草稿的触发条件能否覆盖 target 案例（修复），
 *   以及会不会误命中 baseline 案例（回归）。
 * - **反馈**落到具体小节：触发条件太宽就指 `## 触发条件`，缺反例就指 `## 反例`。
 *
 * 这不是「跑一遍 Agent 看结果」的强验证——那需要调用模型、不可复现、也无法在
 * 一个工具调用里完成。它是**可复现的下界**：能拦住结构不全、边界过宽的草稿，
 * 拦不住语义微妙的错误，所以最终仍由人把关。
 */
import type { Candidate } from './radar.js';
import type { MemoryStore } from './store.js';
/** 一条回放结果。 */
export interface CaseResult {
    id: number;
    /** target：当初失败的案例；baseline：当初正常的案例。 */
    verdict: 'target' | 'baseline';
    /** 草稿是否会在此案例上触发。 */
    triggers: boolean;
    /** 判定是否正确：target 应触发，baseline 不应触发。 */
    pass: boolean;
    snippet: string;
}
/** 门禁报告。 */
export interface GateReport {
    verdict: 'pass' | 'fail';
    /** 修复了哪些失败案例（target 命中数 / 总数）。 */
    fixed: {
        hit: number;
        total: number;
        cases: CaseResult[];
    };
    /** 动了哪些既有案例（baseline 误命中，必须为 0）。 */
    regressions: {
        hit: number;
        total: number;
        cases: CaseResult[];
    };
    /** 结构校验问题。 */
    structural: string[];
    /** 该改草稿的哪一节，逐条可执行。 */
    feedback: string[];
}
export interface GateOptions {
    /**
     * 判定阈值：触发条件一节的 token 覆盖案例 token 的比例超过它，就算「会触发」。
     *
     * 默认 0.25，由夹具实测确定：一份紧扣 useEffect 的触发条件对三条 target 的覆盖率是
     * 0.304 / 0.375 / 0.412，对两条无关 baseline 是 0.000 / 0.000。取 0.25 留出余量，
     * 既能覆盖全部 target，又不会把无关案例拉进来。门禁宁严勿宽：漏放一条比误放一条
     * 代价小，所以阈值贴着实测下界取，而不是取中位数。
     */
    threshold?: number;
}
/**
 * 判定草稿是否会在某个案例上触发。
 *
 * 只看草稿的**触发条件**（`## 触发条件` 一节），不看整篇：
 * - 看整篇会自伤：`## 反例` 一节里写的就是「不该触发」的输入，把它算进触发面，
 *   那些词反而让反例案例被误判为命中（实测：好草稿因此永远过不了门禁）。
 * - 看整篇会虚胖：`## 做法`、`## 正例` 里的通用词会把覆盖率抬上去。
 *
 * 打分用覆盖率而不是 Jaccard：草稿必然比案例长得多，Jaccard 会被草稿长度稀释，
 * 导致「什么都判不触发」，门禁就永远绿——那是一个假装能失败的闸门。
 */
export declare function triggersOn(draft: string, caseText: string, threshold: number): boolean;
/**
 * 跑门禁。
 *
 * 回归集来源优先级：
 * 1. 显式标了 `verdict` 的记录（人工标注，最可靠）。
 * 2. 没有标注时，退化用候选自身的证据当 target（它们正是「当初出问题」的记录），
 *    并从同作用域里抽同数量的**非证据**记录当 baseline（它们当初没出问题）。
 */
export declare function runGate(store: MemoryStore, candidate: Candidate, draft: string, options?: GateOptions): GateReport;
/** 把门禁报告渲染成给人看的中文段落。 */
export declare function renderReport(report: GateReport): string;
