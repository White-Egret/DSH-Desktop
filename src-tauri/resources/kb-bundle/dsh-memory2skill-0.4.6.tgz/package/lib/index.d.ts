/**
 * dsh-memory2skill —— DSH 记忆与半自动技能进化插件。
 *
 * 四个词就是架构本身：
 *   - 雷达（radar.ts）：在 project/topic 范围内找重复模式，产出候选建议。
 *   - 宪法（constitution.ts + assets/constitution.md）：起草时强制套用的写作规范。
 *   - 门禁（gate.ts）：草稿先在历史轨迹上回放，通过才递到人面前。
 *   - 逐字（store.ts）：原始轨迹原样存储、不摘要，门禁的回归测试靠它成立。
 *
 * 硬边界：发现、起草、验证都可以自动；写入技能目录只有 `memory2skill_commit`
 * 一个入口，且只在用户明确发出 commit 指令后调用。
 *
 * 实现约束（与 dsh-multimedia / dsh-github / dsh-evolve 对齐）：
 *   - 导出 `{ name, inject, apply }`；`inject` 声明必需服务。
 *   - 包级导入只做 `import type`（编译后零运行时依赖）；`node:fs` / `node:sqlite`
 *     走函数内动态 `import()`，插件可被 loader 直接 import，不必自带 node_modules。
 *   - 所有事件回调包 try/catch：后台记录失败永远不能拖垮会话。
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis 插件名（loader 诊断用）。 */
declare const name = "memory2skill";
/** 该插件必需的宿主服务。 */
declare const inject: string[];
/** 插件配置。 */
export interface Config {
    /** 数据库文件路径。留空则用 <dshHome>/memory2skill/memory2skill.db。 */
    dbPath?: string;
    /** 技能目录。留空则用 <dshHome>/skills。 */
    skillsDir?: string;
    /** 后台静默记录用户消息。默认 true。 */
    capture?: boolean;
    /**
     * 捕获的最短字数：短于这个字符数的消息不记（默认 12）。
     * 太短的话承载不了一条可判定的规则，只会稀释雷达的信噪比。
     */
    minCaptureChars?: number;
    /**
     * 单个 (project, topic) 范围内会话捕获（kind='utterance'）记录数的上限，
     * 默认 500。超过时最老的 captured 行（未回填 pattern_id 的）先删。
     *
     * 与 minCaptureChars 同理：无限攒逐字记录只会稀释雷达的信噪比（雷达按条数
     * 触发，最老的会话闲聊永远排在候选证据前面），还会无上限地增长数据库文件。
     * 该上限只约束会话捕获；手动记录与 target/baseline 标签不受它影响。
     */
    captureMaxRecords?: number;
    /** 是否启用 FTS5 派生索引。默认 true，不可用时自动退化。 */
    fts?: boolean;
    /** 默认项目名（未指定时用于手动记录的落点）。 */
    defaultProject?: string;
    /** 雷达默认：至少几条记录才算候选。 */
    minObservations?: number;
    /** 雷达默认：聚类相似度阈值。 */
    similarity?: number;
    /** 雷达默认：只看最近几天。 */
    days?: number;
    /** 上下文注入总开关。默认 true；出问题时可一键关掉而不必卸载插件。 */
    injectEnabled?: boolean;
    /** 注入死线（毫秒）：超时就砍掉慢项，不能让用户等注入。默认 1200。 */
    injectDeadlineMs?: number;
    /** 注入预算（字符，不是 token）。默认 640。 */
    injectBudget?: number;
}
/**
 * 插件入口。
 *
 * @param ctx Cordis 上下文（"tools" 已在 inject 中声明）
 * @param config 插件配置（cordis.patch.yml 的 config 段）
 */
declare function apply(ctx: Context, config?: Config): Promise<void>;
export { apply, inject, name };
export { MemoryStore, defaultPaths } from './store.js';
export { scan, hydrate, RADAR_DEFAULTS } from './radar.js';
export { buildDraft, checkDraft, hasUnfinishedTodos, loadConstitution, suggestName } from './constitution.js';
export { runGate, renderReport, triggersOn } from './gate.js';
export { tokenize, fold, redact, jaccard, summarize, evidenceSnippet } from './text.js';
export { encodeToken, encodeText } from './store.js';
export { renderJson } from './tool.js';
export * from './episodic.js';
export { EpisodicIndex } from './episodic-index.js';
