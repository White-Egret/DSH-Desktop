/**
 * 用户画像（#20–#23）：从已有观察里确定性聚合，绝不调 LLM。
 *
 * 画像的问题不在生成、在更新时机：它是慢变量，一天内不会变；但注入的文本
 * 是 apply() 时固化的常量（硬约束 7/12），会话中途改它等于破坏 prompt cache。
 * 所以这里的全部产出都只是写文件——生效时点永远是下一次插件启动。
 */
import type { MemoryStore } from './store.js';
/** 攒够多少条新 observation 才提示再聚合（B1）。 */
export declare const PERSONA_THRESHOLD = 20;
/** 画像正文上限（硬约束 11）：超了截断并标注。 */
export declare const PERSONA_MAX_CHARS = 600;
/** 聚合起点：persona.md frontmatter 里的最大 observation id；没有文件从 0 起算。 */
export declare function personaAnchor(root: string): Promise<number>;
/** anchor 之后新增的 correction/note 数；到阈值时 status 与 prune 都会提示。 */
export declare function countPendingPersona(store: MemoryStore, anchor?: number): number;
export interface PersonaResult {
    markdown: string;
    aggregatedFrom: number;
    sections: Record<string, string>;
}
/**
 * 聚合一份画像：四节固定结构，没有内容的节整行不写。
 *
 * 每一节都是「先取数、再排序、再截断」的确定性流水线；同一个库两次聚合
 * 得到同一份文本（除时间戳），人可以 diff 复核。
 */
export declare function aggregatePersona(store: MemoryStore, anchor?: number): PersonaResult;
export declare function personaFilePath(root: string): string;
/** 生成并落盘 persona.md；返回给调用方的 markdown 已含 frontmatter。 */
export declare function buildPersona(store: MemoryStore, root: string): Promise<{
    markdown: string;
    aggregatedFrom: number;
}>;
/** 读出注入用画像正文（frontmatter 之后的四节）；文件不存在返回 null。 */
export declare function readPersona(root: string): Promise<string | null>;
