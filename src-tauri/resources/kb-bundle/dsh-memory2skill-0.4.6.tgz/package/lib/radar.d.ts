/**
 * 雷达：在限定范围内发现重复模式，产出候选清单。
 *
 * ## 为什么不是「聚类」
 *
 * 最初的实现按 bigram-Jaccard 做单链聚类，阈值 0.32。在本机真实的 77 条记忆
 * （dsh-evolve 的 MEMORY.md）上实测：同主题记录的相似度 p50=0.023、p90=0.113、
 * 最高仅 0.202。也就是说，**人类描述同一件事的两次纠正，字面重合度往往不到 0.2**
 * —— 语义相近不等于字面相近。任何靠字面阈值做聚类的做法，在这个分布上要么全不合并、
 * 要么把无关记录硬拉在一起。
 *
 * dsh-evolve 的答案是「tag 分组 + 条数阈值」：不猜语义，只数次数。本插件采用同样的
 * 骨架，但分组键换成**项目/主题**（project/topic）——这是人在记录时就已给定的语义标签，
 * 比模型自动打 tag 更可靠、可解释、可复现。
 *
 * ## 三步
 *
 * 1. **分组**：按 (project, topic) 分桶。同一桶内的记录天然同主题。
 * 2. **再按共享 token 细分**：桶内若明显分成几组（互相不共享核心 token），拆成子簇，
 *    避免「一个主题里的三件事」被算成一件事。拆分只用一个很低的门槛，不做精细聚类。
 * 3. **打分**：条数是主导项，共享 token 数与平均长度做温和修正。达到
 *    `minObservations` 才成为候选。
 *
 * 结果写进 `patterns` 表，证据记录回填 `pattern_id`，门禁与草稿都靠这个关联。
 * 全流程确定性、零 LLM：同一批数据两次扫描得到相同的 id 与分数。
 */
import type { MemoryStore, Pattern } from './store.js';
/** 雷达参数。 */
export interface RadarOptions {
    /** 至少几条记录才算一个候选。 */
    minObservations: number;
    /**
     * 子簇拆分门槛：桶内两条记录共享的 token 占较短一方 token 的比例。
     * 只用来把「同一个主题里明显不相干的两件事」拆开，不做精细语义聚类，
     * 所以取值很低（0.15），宁可少拆也不要漏记。
     */
    similarity: number;
    /** 最多返回几个候选。 */
    maxCandidates: number;
    /** 只看最近几天。 */
    days: number;
    /** 只看某个项目。 */
    project?: string;
    /** 只看某个主题。 */
    topic?: string;
}
export declare const RADAR_DEFAULTS: RadarOptions;
/** 一个候选在库里的形状 + 给人看的证据片段。 */
export interface Candidate extends Pattern {
    observationCount: number;
    /** 桶内共享的核心 token，供人一眼看出这组在讲什么。 */
    coreTokens: string[];
    /** 每条证据的逐字片段，供人核对（不是摘要，是原文窗口）。 */
    evidence: Array<{
        id: number;
        ts: string;
        kind: string;
        snippet: string;
    }>;
}
/**
 * 扫描，返回排序后的候选清单。结果同时写入 patterns 表。
 *
 * `project`/`topic` 省略时，按记录数从多到少遍历所有作用域。
 */
export declare function scan(store: MemoryStore, options?: Partial<RadarOptions>): Candidate[];
/** 把候选重新读成带证据的形状（供 draft/validate 用）。 */
export declare function hydrate(store: MemoryStore, pattern: Pattern): Candidate;
