/**
 * memory2skill_recall：一个工具、三个 mode。
 *
 * 拆成三个工具会让每次 API 调用都多发两份 schema；参数分派没有这个成本。
 * 三层视图的边界比「少发 schema」更重要：index / recall 只回目录与要点，
 * 正文只在 detail 里按 offset + maxChars 分页，避免一个大文件直接进上下文。
 */
import type { Context } from '@deepseek-ai/cordis';
export interface RecallRuntime {
    /** 权威 JSON 与 index.db 的根目录（默认 <DSH_HOME>/）。 */
    root: string;
    /** 省略 workspace 参数时算出来的锚点。 */
    defaultWorkspace: string;
}
/** 一轮内的调用计数；user/message 到来时清零。 */
export declare function createRecallCounter(): {
    take: (sessionId: string) => boolean;
    reset: (sessionId: string) => void;
};
export declare function registerRecall(ctx: Context, runtime: RecallRuntime, counter: ReturnType<typeof createRecallCounter>): void;
