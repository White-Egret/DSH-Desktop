/**
 * 文本处理：CJK bigram 分词、相似度、证据摘取。
 *
 * 参考 dsh-evolve v0.8.0 的 `lib/search.js` 思路（CJK 双字切分 + ASCII 词切分），
 * 独立实现，未复制其代码；致谢见 README。
 *
 * 为什么不用 FTS5 的默认分词器：unicode61 会把「苹果公司」当成一个不可查询的整词，
 * trigram 又要求 >= 3 字符，两字查询（如「客户」）会落空。所以本项目自己切好 token，
 * 只把切好的 token 交给 FTS5 建索引，BM25 就只负责排序。
 */
/**
 * 去掉变音符，让「café」与「cafe」落成同一个 token。
 *
 * `ß / æ / œ` 不是 NFD 可分解的组合字符，必须显式映射；漏掉它们时
 * 「Straße」会被正则切在 ß 处，雷达据此把同一条纠正判成两件不同的事。
 */
export declare function fold(text: string): string;
/**
 * 把一段文本切成检索 token。
 *
 * - 字母数字：按词切，保留 `dsh-memory2skill` 这类带连接符的标识符整体。
 *   `u` flag 不可省：非 BMP 汉字（CJK 扩展 B）落在 BMP 代理对区间里，
 *   没有它会被按半个码点切断，产生孤立代理串并污染 FTS5 的索引。
 * - CJK：先按标点/空白断成**小句**，再在小句内切**双字组**（bigram）。
 *   断句是关键：不断句的话「…订阅，否则组件…」会切出「阅否」这种跨词组合，
 *   它们不承载语义，只会稀释相似度、把两条同义纠正判成不相似（实测 0.18 vs 0.35）。
 * - 单个孤字保留原字。
 *
 * 返回去重后的 token 数组，顺序保持首次出现顺序，便于结果复现。
 */
export declare function tokenize(text: string): string[];
/** Jaccard 相似度：两段文本的 token 集合交集 / 并集。 */
export declare function jaccard(a: string, b: string): number;
/**
 * 覆盖率相似度：较短一方的 token 有多少落在较长一方里。
 *
 * 为什么聚类用覆盖率而不是 Jaccard：同义纠正文的长度差很大（一句 20 字、一句 40 字），
 * Jaccard 的分母被长的那条撑大，两条讲同一件事的纠正会拿到 0.2 这种「不相似」的分数。
 * 覆盖率只看「短的被长的覆盖了多少」，对长度差不敏感。
 *
 * 上限设 1：一条短句完全被长句包含时得 1.0，这是真实信号而非异常。
 */
export declare function coverage(a: string, b: string): number;
/**
 * 两条记录的相似度：覆盖率与 Jaccard 的加权混合。
 *
 * 覆盖率抓「讲同一件事」，Jaccard 抓「用词重合度」，两者一起用可以挡住
 * 「短句被长句吞掉但其实是别的事」这类误合并。权重 0.7/0.3 由夹具实测确定。
 */
export declare function similarity(a: string, b: string): number;
/**
 * 把一段逐字文本压成一句可读的摘要，用于候选清单里的 `summary`。
 *
 * 这里是**展示用**的机械压缩（按句切、取首句、截断），不是 LLM 摘要：
 * 原始文本仍然逐字存在 `observations.verbatim` 里，门禁回放用的永远是原文。
 */
export declare function summarize(text: string, maxChars?: number): string;
/**
 * 脱敏：情景记忆是逐字明文长存的正文，一次粘贴的密钥会永久入库并进 FTS。
 *
 * 只做确定性的正则替换，不调模型、不猜语义：宁可多脱掉一段高熵串，也不能把
 * 原文留在权威 JSON 里。代价是脱敏后原文不可逆——这正是这里要的单向效果。
 * 次序必须是「先脱敏 → 再 tokenize」，否则 FTS 的 token 里仍会残留密钥。
 */
export declare function redact(text: string): string;
/** 取一段文本里与给定 token 重合最多的连续片段，作为「证据片段」。 */
export declare function evidenceSnippet(text: string, tokens: string[], maxChars?: number): string;
