/**
 * 工具定义辅助。
 *
 * 直接用 `@deepseek-ai/dsh-tools` 自带的 `defineTool`：它的参数用属性 map DSL
 * （`{ key: { type: 'string', required: true } }`），比裸 JSON Schema 短，而且参数
 * 校验由宿主内建完成。
 *
 * 这里只补一件事：`output.render` 的默认实现。这些工具的返回值本来就是给人读的
 * 结构化报告，直接序列化成文本比二次渲染文案更准；有 `report` 字段时优先输出它。
 */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
/** 把工具返回值渲染成模型可读的文本块。 */
export declare function renderJson(value: unknown): ContentBlock[];
