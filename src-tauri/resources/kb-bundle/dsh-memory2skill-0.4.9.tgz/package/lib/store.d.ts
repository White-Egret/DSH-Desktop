/**
 * 数据层：逐字记录 + 项目/主题分层 + FTS5 派生索引。
 *
 * 三条设计约束，全部来自本项目的四个词：
 *
 * 1. **逐字**：`observations.verbatim` 存原始文本，不截断、不摘要。摘要是展示层
 *    的事（`text.ts::summarize`），永远不写回库。门禁回放读的也是原文。
 * 2. **项目/主题**：每条记录带 `project`（项目或仓库名）与 `topic`（主题或领域）。
 *    雷达只在一个范围内找模式，草稿的触发边界也据此收窄，避免「Next.js 项目的规范
 *    被应用到 Python 脚本」这类跨域污染。
 * 3. **派生索引**：FTS5 表是**派生的**，可以在任意时刻由 observations 重建；
 *    FTS5 不可用时退化为纯 bigram 召回，插件照常工作。
 *
 * 存储用 `node:sqlite`（Node >= 22.5 内置），不引入 better-sqlite3 这类原生依赖：
 * 插件包因此零运行时依赖，`npm i` 不会编译 C++。
 */
/** 技能降级的门槛：90 天无活动（#24）。注入的 staleHint 与 prune 共用这个数。 */
export declare const STALE_DAYS = 90;
/** 一条逐字观察记录。`verbatim` 永不改写。 */
export interface Observation {
    id: number;
    ts: string;
    /** 项目：这条记录属于哪个项目或仓库。 */
    project: string;
    /** 主题：在这个项目里属于哪个主题或领域。 */
    topic: string;
    /** 记录类型：correction（用户纠正）/ failure（一次失败）/ success（一次成功）/ note / utterance / error。 */
    kind: string;
    verbatim: string;
    /** 来源标记，例如 `session:<id>` 或 `manual`。 */
    source: string;
    /** 关联的模式 id；雷达把记录归到某个候选后回填。 */
    patternId: string | null;
    /** 门禁用的标签：target（当初失败的案例）/ baseline（当初成功的案例）。 */
    verdict: string | null;
    /**
     * 谁说的（#33）：user / tool / agent。
     *
     * 与 kind 正交——kind 分类内容，origin 分类说话者。学习路径（雷达/画像/
     * 门禁退化模式）只吃 'user'：5 条同款工具失败凑成的「模式」不是人的纠正，
     * 它的正例节会引用错误堆栈，门禁回放的 verdict 全靠猜。
     */
    origin: string;
    /**
     * 撤回指针（#34）：指向取代它的那条 observation id；null = 仍是当前真相。
     *
     * 不删原行——被取代的记录是「曾经这么认为」的历史，门禁回归集与证据链
     * 还要引用它；查询面默认排除（listObservations 的 includeSuperseded），
     * 排除是读取时的视角选择，不是存储里的销毁。
     */
    supersededBy: number | null;
}
/** 雷达产出的一个候选模式。 */
export interface Pattern {
    id: string;
    project: string;
    topic: string;
    summary: string;
    score: number;
    evidenceIds: number[];
    createdAt: string;
}
/** 一条观察的写入形状。 */
export interface ObservationInput {
    project: string;
    topic: string;
    kind?: string;
    verbatim: string;
    source?: string;
    verdict?: string | null;
    ts?: string;
    /** 谁说的：user（默认）/ tool / agent。缺省 user——现有调用方全是人的输入。 */
    origin?: string;
}
/**
 * 技能状态。只有两个值，因为只有这两条写入路径。
 *
 * 加新值之前先问一句「谁在写它」——没有写入路径的状态是假状态，
 * 它会让人以为有历史可查。
 */
export declare const SKILL_STATUSES: readonly ["committed", "archived"];
export type SkillStatus = typeof SKILL_STATUSES[number];
/**
 * 最小化的 sqlite 接口，便于在没有 FTS5 的宿主上退化为 null 实现。
 * 导出给情景索引复用：将来换 sqlite-vec / libSQL 只改这一层的实例化代码，
 * 上层两处索引都不必改。裸调 DatabaseSync 会留下两个要同时迁移的地方。
 */
export interface SqliteDb {
    exec(sql: string): void;
    prepare(sql: string): SqliteStatement;
    close(): void;
}
export interface SqliteStatement {
    run(...params: unknown[]): {
        changes: number;
        lastInsertRowid: number | bigint;
    };
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
}
/**
 * 把本项目切好的 token 转成 FTS5 能安全吞下的字符串。
 *
 * 非 ASCII token（中文 bigram、西里尔字母）会变成 `z<hex>`：unicode61 不会
 * 再把它拆开，查询语法也不会被特殊字符破坏。写入与查询必须共用这一份实现，
 * 否则「库里有行、MATCH 不报错、就是零命中」——两套转义迟早漂移。
 */
export declare function encodeToken(tok: string): string;
/** 原文 → 编码后的空格分隔 token，供 FTS5 索引与 MATCH 查询共用。 */
export declare function encodeText(text: string): string;
export interface StoreOptions {
    /** 数据库文件绝对路径；传 ':memory:' 用于测试。 */
    dbPath: string;
    /** 是否尝试启用 FTS5 派生索引。 */
    fts?: boolean;
}
/**
 * 记忆库。所有写入都是同步的（node:sqlite 是同步 API），因此不存在「写一半被读到」
 * 的中间态；跨进程并发由 SQLite 自身的锁处理。
 */
export declare class MemoryStore {
    private readonly db;
    private readonly fts;
    readonly dbPath: string;
    /**
     * FTS 不可用时的原因；可用时为 null。
     *
     * 存在的理由：`ftsAvailable: false` 只说「降级了」，说不出「为什么降级」。
     * 实测最常见的两种情况——数据库被宿主进程占成只读、FTS5 未编译进 node——
     * 处置方式完全不同，混在一起报会让人对着错误的方向查。
     */
    ftsError: string | null;
    private constructor();
    /**
     * 打开（或创建）记忆库。目录不存在时自动创建。
     *
     * FTS5 建表失败不抛错：降级为纯 bigram 召回，`ftsAvailable` 报 false。
     */
    static open(options: StoreOptions): Promise<MemoryStore>;
    /** FTS5 派生索引是否可用。 */
    get ftsAvailable(): boolean;
    /**
     * 打开时必须落定的 PRAGMA。每条设置后立刻读回：SQLite 会**静默忽略**它
     * 无法执行的 pragma（比如 WAL 在网络盘/只读目录上），让同步写退化成每次
     * 全量 fsync。读回来的值不对就当场抛错——数据库打不开比跑在错误的模式上
     * 好修。
     */
    private static applyCorePragmas;
    /** 写入一条逐字观察，返回带 id 的完整记录。 */
    addObservation(input: ObservationInput): Observation;
    /** 取单条观察。 */
    getObservation(id: number): Observation | null;
    /**
     * 按项目删除观察（连同 FTS 索引里的对应行）。
     *
     * 只给自检探针这类「确定是自己写进去的临时数据」用；正常使用不走删除，
     * 记忆库的价值就在于逐字留存。
     */
    deleteObservations(filter: {
        project: string;
        topic?: string;
    }): number;
    /**
     * 单个 (project, topic) 范围内的捕获预算扣减（滚动窗口）。
     *
     * 会话捕获（kind='utterance'）写入前调用。范围已满（行数 ≥ max）时，
     * 最老的一行被立即删除腾位——即先挤掉最老的闲聊再写入新的一条，范围
     * 于是长期稳定在 max 上限内，新内容持续轮换。
     *
     * 绝对不删的两类：verdict 有标签的行（target/baseline 是门禁的回归集），
     * 以及已回填 pattern_id 的行（雷达/门禁的证据）——宁可让总数暂时超过
     * max，也不能失去已结晶的证据。计数与驱逐都只统计未保护的行。
     *
     * node:sqlite 没有 .transaction() 包装，所以用 BEGIN IMMEDIATE / COMMIT：
     * 「数条数 → 删最老」这两步必须原子，否则并发捕获会同时各删一条各插一条。
     *
     * 返回 evicted（本次为腾位删掉的行数）、count（腾位后的行数，随后的一次
     * 写入会使它 +1）、max（上限）。
     */
    trimBudget(project: string, topic: string, max: number, kind?: string): {
        evicted: 0 | 1;
        count: number;
        max: number;
    };
    /**
     * 按项目/主题取记录。`topic` 省略表示整个项目。
     *
     * 这是雷达的作用域：模式只在同一 (project, topic) 内被发现。
     * `origin` 过滤（#33）：学习路径必须传 'user'——工具失败与 harness 错误
     * 也存在这张表里（origin='tool'/'agent'），混进聚类会把错误堆栈凑成「模式」。
     *
     * 默认排除被取代的记录（#34）：`includeSuperseded: true` 才返回全量。
     * 默认排除是「当前真相」的视角——撤回后的旧说法不该再被雷达当证据。
     * 老库此列全 NULL，行为与改前一致。
     */
    listObservations(filter?: {
        project?: string;
        topic?: string;
        days?: number;
        kind?: string;
        verdict?: string | null;
        origin?: string;
        includeSuperseded?: boolean;
        limit?: number;
    }): Observation[];
    /** 全部项目/主题组合及其记录数，供 scan 在未指定作用域时挑出「有东西可看」的范围。 */
    listScopes(days?: number): Array<{
        project: string;
        topic: string;
        count: number;
    }>;
    /** FTS5 BM25 召回：返回按相关度排序的记录 id。FTS 不可用时返回空数组。 */
    searchIds(query: string, limit?: number): number[];
    /** 保存雷达产出的候选模式。 */
    savePattern(pattern: Pattern): void;
    /** 取一个候选模式。 */
    getPattern(id: string): Pattern | null;
    /** 取候选模式关联的逐字证据（门禁回放与草稿生成都用它）。 */
    evidenceFor(patternId: string): Observation[];
    /**
     * 记录一条技能的状态。
     *
     * `status` 只允许两个值，因为**只有这两个状态真的有写入路径**：
     *
     * - `committed`：`memory2skill_commit` 写进技能目录时。
     * - `archived`：人手动归档后由 `memory2skill_archive` 记录。
     *
     * 曾经这里写着 `draft / validated / committed / pruned` 四态，但草稿只返回文本、
     * 不落库，`prune` 是只读的——后两个状态从来没有任何代码写过。那正是
     * 「文档说有、代码永远不写」的假状态：看的人以为有历史可查，实际查不到。
     * 现在用 `SKILL_STATUSES` 在写入处就挡住第三个值。
     */
    upsertSkill(entry: {
        name: string;
        patternId?: string | null;
        status: SkillStatus;
        draftPath?: string | null;
        committedAt?: string | null;
        project?: string | null;
        topic?: string | null;
    }): void;
    /** 删除一条技能登记（归档到别处之后调用）。 */
    deleteSkill(name: string): boolean;
    /** 列出已登记技能。 */
    listSkills(status?: string): Array<{
        name: string;
        patternId: string | null;
        status: string;
        draftPath: string | null;
        committedAt: string | null;
        project: string | null;
        topic: string | null;
    }>;
    /**
     * 技能被 Agent 加载一次：use_count +1 并记本地时区时间戳。
     *
     * 找不到行时静默返回 false——技能目录里可能有不是本插件登记的技能
     * （手工放的），它们的加载不该在这里报错，也不该凭空造出行。
     */
    recordSkillUsage(name: string, at?: string): boolean;
    /** pinned 是人的决定，只有迁移回填与未来的人工入口会写 1；Agent 无权改动。 */
    setSkillPinned(name: string, pinned: boolean): boolean;
    /**
     * 撤回（#34）：把旧观察标成「被新观察取代」。
     *
     * 只标记、不删除——旧说法是「曾经这么认为」的历史，回归集还要引用它。
     * 返回 false = 那条观察不存在或已是被取代状态（重复撤回是调用方 bug，
     * 但重复 UPDATE 是幂等的，静默即可）。
     */
    markSuperseded(oldId: number, newId: number): boolean;
    /**
     * 在撤回语所在的 scope 里找「最像被撤回对象」的旧观察（#34）。
     *
     * 匹配是模糊的：「改主意了，用 B 方案」和「用 A 方案」的 jaccard 可能只有
     * 0.3——匹配不上是常态而不是异常，调用方必须诚实地报告 unresolved，
     * 绝不能按「最近一条」强行标。只比同 (project, topic) 的新近 50 条：
     * 跨主题的旧说法不是撤回对象，那是另一条规则的更正。
     *
     * `excludeId`：新观察自身的 id。撤回识别在入库**之后**跑，若不排除，
     * 新条目与自己的 jaccard = 1.0，「撤回自己」——标完旧条目没标、新条目
     * 反而成了别人的取代者，整个语义颠倒。
     */
    findRetractionTarget(input: {
        project: string;
        topic: string;
        verbatim: string;
        excludeId?: number;
        threshold?: number;
        window?: number;
    }): {
        id: number;
        similarity: number;
    } | null;
    /**
     * 带生命周期字段的完整清单，供 prune 分级与 status 报告。
     *
     * stale 在读的时候即时判定而不是存一列：stale 是「当前时间 − 最后活动」
     * 的函数，落库就变成需要定时刷新的缓存，而本插件没有任何定时器。
     */
    listSkillsWithLifecycle(): Array<{
        name: string;
        patternId: string | null;
        status: string;
        useCount: number;
        lastActivityAt: string | null;
        pinned: boolean;
        committedAt: string | null;
        stale: boolean;
    }>;
    /** 统计信息，供 status 工具与 README 演示使用。 */
    stats(): {
        observations: number;
        patterns: number;
        skills: number;
        scopes: number;
    };
    /** 关闭数据库句柄。 */
    close(): void;
}
/** 技能目录与数据库的默认位置，按 DSH 的 home 约定解析。 */
export declare function defaultPaths(env?: NodeJS.ProcessEnv): {
    dshHome: string;
    dbPath: string;
    skillsDir: string;
};
