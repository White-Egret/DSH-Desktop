/**
 * 上下文注入：在 agent/pre-step 瀑布里，往**末尾追加一条**合成 user message。
 *
 * 三条纪律决定了这里的形状：
 *   · 绝不改动已有 messages——哪怕给早先一条补句话，也会让那一步之后的
 *     prompt cache 全部失效，症状是「对话能用但账单翻倍」；
 *   · 注入永不阻塞——死线是「等多久」，预算是「发多少」，两件事；
 *   · 没有内容就不注入——「（无相关内容）」比什么都不发更糟，模型会以为
 *     查过了、确实没有。
 *
 * 各档相互隔离：索引坏了不该连带把「技能提醒」也吞掉。
 */
import type { PreStepDecision } from '@deepseek-ai/dsh-agent';
import type { UserMessage } from '@deepseek-ai/dsh-llm';
export declare const INJECTION_MARKER = "[\u4E0A\u4E0B\u6587\u63D0\u793A \u2014 \u81EA\u52A8\u6CE8\u5165\uFF0C\u975E\u7528\u6237\u8F93\u5165]";
export interface InjectConfig {
    enabled: boolean;
    deadlineMs: number;
    /** 字符，不是 token。 */
    budget: number;
}
export interface InjectContext {
    root: string;
    workspace: string;
    skillsDir: string;
    config: InjectConfig;
    logger?: {
        warn?: (message: string) => void;
        info?: (message: string) => void;
    };
}
/** 一条注入内容：source 用于留痕排查，chars 是该条实际字符数。 */
export interface InjectItem {
    id: string;
    source: 'episodic' | 'pinned' | 'stale-hint' | 'persona';
    text: string;
    chars: number;
}
export interface InjectLog {
    at: string;
    sessionId: string;
    turn: number;
    step: number;
    items: Array<{
        id: string;
        source: string;
        chars: number;
    }>;
    totalChars: number;
    estimateChars: number;
    actualChars: number;
    budget: number;
    deadlineMs: number;
    elapsedMs: number;
    trimmed: boolean;
    skipped: boolean;
    reason: string | null;
}
export declare function hasHumanInput(messages: readonly UserMessage[]): boolean;
/** 只取真实人类输入的正文，工具结果与合成消息都不拿去检索。 */
export declare function humanQuery(messages: readonly UserMessage[]): string;
/**
 * 合成消息工厂：注入与守卫介入共用同一个 source 形状。
 *
 * `source.kind = 'plugin'` + `form = 'notice'` 是 B4 两条过滤（前缀、来源）的依据，
 * 两处各写一份迟早漂移，所以只在这里造。
 */
export declare function syntheticMessage(text: string, summary?: string): UserMessage;
/** 同会话去重：已注入过的 episode id 不再注入；压缩/清空信号到来时重置。 */
export declare class InjectionState {
    private readonly seen;
    private readonly sessions;
    /**
     * 守卫已经介入的步：`session:turn:step`。
     *
     * 失败循环守卫的重定向消息与「近期相关记录」同一步都追加的话，模型会一次收到
     * 两段合成提示，前缀变长、指令还可能互相打架。守卫先登记、注入后让位——两者
     * 都在 pre-step，守卫的监听器在外层，登记发生在 `next()` 之前，所以这里的判断
     * 一定看得见。
     *
     * 让位的那一步不写 inject.log：这次介入在 loopguard.log.jsonl 里有同 turn/step
     * 的记录，两份日志都写反而会让人以为注入了两段内容。
     */
    private readonly guardSteps;
    reset(sessionId: string): void;
    /** 新会话（或 clear/compact 之后）清空去重记录。 */
    sessionStart(sessionId: string, source?: string): void;
    /** 守卫在这一步介入过：本步不再追加常规定期注入。 */
    suppress(sessionId: string, turn: number, step: number): void;
    isSuppressed(sessionId: string, turn: number, step: number): boolean;
    filter(sessionId: string, items: InjectItem[]): InjectItem[];
}
/**
 * 注册 agent/pre-step 监听器。
 *
 * 先 next() 拿当前决策，再判断要不要加东西：纯工具轮、reject、开关关闭都
 * 直接原样返回。返回 { ...decision, messages: [...decision.messages, injected] }
 * 是唯一允许的改动，已有消息逐字节不动。
 */
export declare function registerInjection(on: (name: string, handler: (payload: unknown, next: () => Promise<PreStepDecision>) => Promise<PreStepDecision>, options?: {
    global?: boolean;
}) => unknown, ctx: InjectContext, state: InjectionState): void;
