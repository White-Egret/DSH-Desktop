/**
 * 失败循环守卫（P1）：用本工作区的成功经验定标回合长度，规则检测无效失败循环，
 * **分级**介入——先重定向、再终止。
 *
 * 三条底线决定这里的形状：
 *
 * 1. **重复 ≠ 失败**。论文实测成功 run 也常重复错误签名，所以「重复」只是触发
 *    线索；终止必须同时满足「编辑空转 + 密集报错 + 重复签名」三条件，**并且**
 *    已经走过重定向与升级两次警告、步数还超过 κ·B_i。宁可漏杀，不可误杀。
 * 2. **先观察再介入**。`enabled` 默认关；`redirect` / `terminate` 各自独立。
 *    只开 `enabled`、两个子开关都关时，守卫只写 `action: 'observe'` 的日志，
 *    不动消息、不终止回合——这是「看分布合不合理」的那一档。
 * 3. **插件不调 LLM**。定标、触发、文案拼接全是确定性规则；「换个思路」的具体
 *    判断交给 agent 自反思。介入走 `agent/pre-step` 追加合成消息，
 *    systemPrompt 与已有 messages 一个字都不动（决策 6）。
 *
 * 单位换算（方案 §一）：论文的「一个 task 的轨迹回合数」≈ DSH 的「一个 turn 内的
 * step 数」。所以 B_i 用 **turn 内最大 step 号**定标，不是 turn 数——episodic 不记
 * step，守卫自己按 pre-step payload 的 `step` 计。
 *
 * 终止原语（方案 §一 事实 1）：调用方拿到 `action:'terminate'` 后在 pre-step 返回
 * `{kind:'reject'}`，回合干净结束为 `blocked`（`dsh-agent-loop/lib/index.js` 里
 * `if (decision.kind === 'reject') { turnEnds = {kind:'blocked'}; return false }`）。
 * 不需要调 `agent.cancel`，也不该调——cancel 会把回合记成 aborted，那是另一件事。
 */
import type { TurnStatInput } from './store.js';
/** 介入消息标记：与 inject.ts 的 `INJECTION_PREFIX` 同前缀。 */
export declare const INTERVENTION_MARKER = "[\u4E0A\u4E0B\u6587\u63D0\u793A \u2014 \u81EA\u52A8\u4ECB\u5165\uFF0C\u975E\u7528\u6237\u8F93\u5165]";
/** 守卫的可调参数。全部进 config，不硬编码在调用点。 */
export interface LoopGuardSettings {
    /** 总开关。P1 交付默认 **false**：先观察，不介入。 */
    enabled: boolean;
    /** 子开关：是否允许重定向 / 升级警告。关掉它守卫就只观察。 */
    redirect: boolean;
    /** 子开关：是否允许终止。关掉它守卫最多劝退。 */
    terminate: boolean;
    /** B_i 的余量倍数 β（方案默认 1.5）。 */
    beta: number;
    /** 定标用的分位 p（方案默认 0.9）。 */
    quantile: number;
    /** 终止线 = κ·B_i（方案默认 2）。 */
    kappa: number;
    /** 重复失败签名达到几次算触发（R，默认 3）。 */
    repeatThreshold: number;
    /** 定标样本少于几个不启用守卫（M，默认 5，避免冷启动误杀）。 */
    minSamples: number;
    /** 密集报错的滑窗长度：最近多少个工具结果。 */
    densityWindow: number;
    /** 密集报错的窗口内失败占比阈值。 */
    densityThreshold: number;
    /** 定标最多取最近几个 completed turn。 */
    maxSamples: number;
}
/** 默认值：与方案 §四 一致，除 `enabled` 按「先观察」落在 false。 */
export declare const LOOPGUARD_DEFAULTS: LoopGuardSettings;
/** 配置清洗：范围外的一律夹到边界，而不是抛错——守卫是旁路功能，不能拦住插件启动。 */
export declare function resolveSettings(raw?: Partial<LoopGuardSettings>): LoopGuardSettings;
export interface Calibration {
    /** completed turn 的样本数（blocked / aborted 不在内）。 */
    samples: number;
    /** Q_p(step 数)；样本为空时 null。 */
    quantile: number | null;
    /** B_i = ceil(β·Q_p)；样本为空时 null。 */
    budget: number | null;
    /** 样本 ≥ M 才启用守卫——冷启动没有参照，任何阈值都是瞎猜。 */
    active: boolean;
}
/** 线性插值分位数。样本少时不插值更好，但插值至少是单调的，且不会凭空放大。 */
export declare function quantileOf(values: readonly number[], p: number): number | null;
export declare function calibrate(stepCounts: readonly number[], settings: LoopGuardSettings): Calibration;
/**
 * 把一条工具失败输出压成可比较的签名：取首行，去掉路径、时间戳、数字。
 *
 * 「同一个错」在不同次调用里几乎总带不同的绝对路径与行号/耗时，不归一化的话
 * 重复签名永远不会累加，守卫就等于没开。只取首行是刻意的：错误堆栈的第二行
 * 开始是「同一类错误的细节」，把它算进签名会让两个本质相同的失败被判成不同。
 */
export declare function normalizeSignature(message: string): string;
export interface TurnState {
    sessionId: string;
    turn: number;
    /** 本 turn 见过的最大 step 号（含即将进入的那一步）。 */
    step: number;
    /** 本 turn 观察到的工具结果数与失败数。 */
    results: number;
    errors: number;
    /** 最近 `densityWindow` 个工具结果是否失败。 */
    recentErrors: boolean[];
    /** 归一化失败签名 → 次数。 */
    signatures: Map<string, number>;
    /** 编辑过的文件 → 编辑次数（同一文件改两次是「编辑空转」的原料）。 */
    edits: Map<string, number>;
    /** 最近几步的动作摘要，给重定向文案用（确定性拼接，只留最后 4 条）。 */
    actions: string[];
    /** 已经发过几次重定向 / 升级警告。它们同时是「终止的前置条件」。 */
    redirects: number;
    escalations: number;
    /** 上一次发警告时的 step，用来避免同一 step 连发两条。 */
    lastWarnStep: number;
    /** 观测模式下每个 turn 只记一条 observe 日志，避免日志膨胀。 */
    observed: boolean;
}
export declare function createTurnState(sessionId: string, turn: number): TurnState;
export declare function isEditTool(name: string): boolean;
/**
 * 从工具参数里取被改动的文件。
 *
 * `apply_patch` 没有单一文件参数，路径在补丁正文的 `*** Add/Update/Delete File:` 行里；
 * 不解析它就会漏掉最主要的一种改法。其余工具用 `file_path`（dsh 的惯例）或 `path`。
 */
export declare function editedFileOf(toolName: string, args: unknown): string | null;
export interface StallTriad {
    /** 编辑空转：反复改同一个文件（≥2 次且只碰过 1 个文件）。 */
    editStall: boolean;
    /** 密集报错：窗口内失败占比达到阈值。 */
    denseErrors: boolean;
    /** 重复签名：同一失败签名出现 ≥ R 次。 */
    repeatedSignature: boolean;
}
export interface TriggerReport {
    /** 三个廉价触发里命中任意一个。 */
    any: boolean;
    repeated: boolean;
    dense: boolean;
    overBudget: boolean;
    /** 出现次数最多的失败签名与次数。 */
    repeatSignature: string;
    maxRepeat: number;
    errorDensity: number;
    /** 终止用的三条件（与廉价触发分开：终止只看这三条 + 步数）。 */
    stall: StallTriad;
    /** 给人看的触发原因（进日志与文案）。 */
    reasons: string[];
}
export declare function evaluateTriggers(state: TurnState, calibration: Calibration, settings: LoopGuardSettings): TriggerReport;
export type GuardAction = 'none' | 'observe' | 'redirect' | 'escalate' | 'terminate';
export interface GuardDecision {
    action: GuardAction;
    /** 决策理由（进日志，也给文案拼接用）。 */
    reason: string[];
    calibration: Calibration;
    trigger: TriggerReport;
    /** 介入文案；`none` / `observe` / `terminate` 时为 null（终止靠协议，不靠嘴）。 */
    message: string | null;
}
/**
 * 分级决策。纯函数：给定状态与配置就能算——单测覆盖「三根柱子」全靠它。
 *
 * 阶梯（每一级都要**上一级真的发生过**）：
 *   0. 重复/密集/超预算任一命中 → 重定向（`redirect` 关掉则只记 observe）
 *   1. 重定向之后仍命中 → 升级警告（更强，提示「再不行就停下」）
 *   2. 升级之后再命中 → 才考虑终止，且必须「三条件齐备 + step ≥ κ·B_i + terminate 开」
 *
 * 为什么 terminate 的前置是「发过警告」而不是「配置打开」：不给警告就杀回合等于
 * 静默打断 agent，方案 §零 的硬约束 3 明确禁止。所以 `redirect:false` 时
 * `terminate` 不会生效——这是刻意的耦合，不是漏写。
 */
export declare function decide(state: TurnState, calibration: Calibration, settings: LoopGuardSettings): GuardDecision;
export declare function redirectText(state: TurnState, calibration: Calibration, trigger: TriggerReport): string;
export declare function escalateText(state: TurnState, calibration: Calibration, trigger: TriggerReport, settings: LoopGuardSettings): string;
/** turn_stats 的读写面（结构类型，便于单测用假 store）。 */
export interface TurnStatsSink {
    addTurnStat(input: TurnStatInput): unknown;
    completedStepCounts(workspace: string, limit: number): number[];
    turnStatsSummary(workspace: string): {
        turns: number;
        byKind: Record<string, number>;
    };
}
export interface LoopGuardDeps {
    /** 工作区锚点，与 episodic 同口径。定标按工作区隔离。 */
    workspace: string;
    /** `<dshHome>`：日志落在 `<root>/memory2skill/loopguard.log.jsonl`。 */
    root: string;
    store: TurnStatsSink;
    settings?: Partial<LoopGuardSettings>;
    logger?: {
        warn?: (message: string) => void;
        info?: (message: string) => void;
    };
}
export interface InterventionCounts {
    observe: number;
    redirect: number;
    escalate: number;
    terminate: number;
}
export declare class LoopGuard {
    readonly settings: LoopGuardSettings;
    private readonly deps;
    /** sessionId → 本 turn 状态。turn/end 时删掉，不会跨会话泄漏。 */
    private readonly states;
    private readonly counts;
    /**
     * 日志写入串行队列。
     *
     * 留痕必须 fire-and-forget（不能反过来拖住 pre-step），但两次 appendFile 并发
     * 时完成的顺序不保证——实测出现过 escalate 的行排在 redirect 前面，台账就变成
     * 「先升级后重定向」，读的人会被误导。队列只保证**顺序**，不增加等待：
     * 调用方照样不 await。
     */
    private logQueue;
    constructor(deps: LoopGuardDeps);
    get workspace(): string;
    /** `loopguard.log.jsonl`：只追加、不进上下文。 */
    get logPath(): string;
    private warn;
    /** 取（必要时新建）某会话在某 turn 的状态；turn 变化即重置。 */
    private stateFor;
    /**
     * completed turn 的 step 数 → B_i。样本只取最近 `maxSamples` 个。
     *
     * 不做内存缓存：cache 会让「刚落盘的 turn 不参与下一次定标」，也让 status 报出
     * 一个和库里对不上的 B_i。这一步只是一条带索引的 SELECT（≤200 行整数），
     * 相对每步一次模型调用可以忽略。
     */
    calibration(): Calibration;
    /**
     * `tools/result` 之后调用：纯采集，不决定任何动作。
     *
     * 采集永远开着（哪怕 `enabled=false`）：turn_stats 是「先观察」这一档的数据源，
     * 关掉总开关不应该连观察一起关掉，否则开之前没有任何分布可看。
     */
    observeToolResult(input: {
        sessionId: string;
        toolName: string;
        args: unknown;
        isError: boolean;
        message?: string;
    }): void;
    /**
     * 每个 `agent/pre-step` 都调（守卫自己的监听器，不受 `hasHumanInput` 限制）。
     *
     * 返回的动作由调用方落到协议上：`terminate` → `{kind:'reject'}`；
     * `redirect` / `escalate` → 追加一条合成消息；`observe` / `none` → 原样放行。
     */
    beforeStep(sessionId: string, turn: number, step: number): GuardDecision;
    /**
     * `turn/end` 时调用：落一行 turn_stats，再清掉本 turn 的状态。
     *
     * **只统计 completed 进定标**（查询侧过滤，写入侧照记全部）：blocked / aborted
     * 也要留痕——它们正是「守卫介入后发生了什么」的证据。没有 pre-step 状态的回合
     * （输入被清空、空回合）不写行：那不是守卫观察到的回合。
     */
    endTurn(sessionId: string, turn: number, endedKind: string): void;
    /** 会话被销毁：丢掉半截状态（没落盘的 turn 不写行，记日志说明）。 */
    dropSession(sessionId: string): void;
    /** `memory2skill_status` 的守卫统计。 */
    status(): Record<string, unknown>;
    /**
     * 日志只追加、不进上下文；写失败只 warn——留痕不能反过来拦住会话。
     *
     * 返回的 promise 只用于测试与排障，调用方一律 `void`：顺序靠队列保证，
     * 等待不落在 pre-step 上。
     */
    private log;
}
